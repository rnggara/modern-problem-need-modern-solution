<!DOCTYPE html>


    <html class="html__responsive">

    <head>

        <title>Newest &#39;node.js&#39; Questions - Stack Overflow</title>
        <link rel="shortcut icon" href="https://cdn.sstatic.net/Sites/stackoverflow/Img/favicon.ico?v=ec617d715196">
        <link rel="apple-touch-icon" href="https://cdn.sstatic.net/Sites/stackoverflow/Img/apple-touch-icon.png?v=c78bd457575a">
        <link rel="image_src" href="https://cdn.sstatic.net/Sites/stackoverflow/Img/apple-touch-icon.png?v=c78bd457575a"> 
        <link rel="search" type="application/opensearchdescription+xml" title="Stack Overflow" href="/opensearch.xml">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0">
        <meta property="og:type" content= "website" />
        <meta property="og:url" content="https://stackoverflow.com/questions/tagged/node.js"/>
        <meta property="og:site_name" content="Stack Overflow" />
        <meta property="og:image" itemprop="image primaryImageOfPage" content="https://cdn.sstatic.net/Sites/stackoverflow/Img/apple-touch-icon@2.png?v=73d79a89bded" />
        <meta name="twitter:card" content="summary"/>
        <meta name="twitter:domain" content="stackoverflow.com"/>
        <meta name="twitter:title" property="og:title" itemprop="name" content="Newest &#x27;node.js&#x27; Questions" />
        <meta name="twitter:description" property="og:description" itemprop="description" content="Stack Overflow | The World&#x2019;s Largest Online Community for Developers" />

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://cdn.sstatic.net/Js/stub.en.js?v=39ab3f513667"></script>
    
        <link rel="stylesheet" type="text/css" href="https://cdn.sstatic.net/Shared/stacks.css?v=0ee8a05683e7" >
        <link rel="stylesheet" type="text/css" href="https://cdn.sstatic.net/Sites/stackoverflow/primary.css?v=c5fdf309f06b" >
        <link rel="stylesheet" type="text/css" href="https://cdn.sstatic.net/Sites/stackoverflow/secondary.css?v=0ad93e7d5552" >

    
            <link rel="alternate" type="application/atom+xml" title="Newest node.js questions feed" href="/feeds/tag?tagnames=node.js&amp;sort=newest" />

        
        
        
        
        
        
        


    <script>
        StackExchange.init({"locale":"en","serverTime":1594220613,"routeName":"Questions/ListByTag","stackAuthUrl":"https://stackauth.com","networkMetaHostname":"meta.stackexchange.com","site":{"name":"Stack Overflow","description":"Q&A for professional and enthusiast programmers","isNoticesTabEnabled":true,"enableNewTagCreationWarning":true,"insertSpaceAfterNameTabCompletion":false,"id":1,"childUrl":"https://meta.stackoverflow.com","negativeVoteScoreFloor":null,"enableSocialMediaInSharePopup":true,"protocol":"https"},"user":{"fkey":"3617a09d093ab016f84b62babf7378eed871cd3b24839c1012d3021561f38b45","tid":"553ded12-9d1a-dd7d-1d8e-49a99ea50706","rep":0,"isAnonymous":true,"isAnonymousNetworkWide":true,"ab":{"tutorial_tooltips":{"v":"thanks_reaction_icon","g":2}}},"events":{"postType":{"question":1},"postEditionSection":{"title":1,"body":2,"tags":3}},"story":{"minCompleteBodyLength":75,"likedTagsMaxLength":300,"dislikedTagsMaxLength":300},"jobPreferences":{"maxNumDeveloperRoles":2,"maxNumIndustries":4},"svgIconPath":"https://cdn.sstatic.net/Img/svg-icons","svgIconHash":"2816dfc51c0f"}, {"userProfile":{"openGraphAPIKey":"4a307e43-b625-49bb-af15-ffadf2bda017"},"userMessaging":{"showNewFeatureNotice":true},"tags":{},"subscriptions":{"defaultMaxTrueUpSeats":1000},"snippets":{"renderDomain":"stacksnippets.net","snippetsEnabled":true},"slack":{"sidebarAdDismissCookie":"slack-sidebar-ad","sidebarAdDismissCookieExpirationDays":60.0},"site":{"allowImageUploads":true,"enableImgurHttps":true,"enableUserHovercards":true,"forceHttpsImages":true,"styleCode":true},"paths":{},"monitoring":{"clientTimingsAbsoluteTimeout":30000,"clientTimingsDebounceTimeout":1000},"mentions":{"maxNumUsersInDropdown":50},"markdown":{"asteriskIntraWordEmphasis":true,"enableCommonmark":true},"flags":{"allowRetractingCommentFlags":true,"allowRetractingFlags":true},"comments":{},"accounts":{"currentPasswordRequiredForChangingStackIdPassword":true}});
        StackExchange.using.setCacheBreakers({"js/adops.en.js":"22a9bd59b1e9","js/ask.en.js":"1c0a624e1e04","js/begin-edit-event.en.js":"cb9965ad8784","js/events.en.js":"f2d560c0fe3c","js/explore-qlist.en.js":"be3b9d8380ea","js/full-anon.en.js":"0bcf47259372","js/full.en.js":"e44b79cbeab0","js/help.en.js":"76e2886f2122","js/inline-tag-editing.en.js":"25799d8d2d38","js/keyboard-shortcuts.en.js":"c547be604304","js/mobile.en.js":"45f128a33544","js/moderator.en.js":"82f863f6432c","js/postCollections-transpiled.en.js":"137dca7e528b","js/post-validation.en.js":"87800ef436e4","js/prettify-full.en.js":"87db5610dcfb","js/question-editor.en.js":"","js/review.en.js":"7c0ed16699f8","js/revisions.en.js":"fa23b076b70a","js/tageditor.en.js":"1f2a41e0a86e","js/tageditornew.en.js":"d0bb0592d3cb","js/tagsuggestions.en.js":"4d2d70ee1e16","js/third-party/stacks-editor/app.bundle.js":"72999662ddbd","js/third-party/stacks-editor/app.bundle.en.js":"","js/wmd.en.js":"c064f26b531a","js/snippet-javascript-codemirror.en.js":"d47545fd3fa1","js/markdown-it-loader.en.js":"7c8a40bee094"});
        StackExchange.using("gps", function() {
             StackExchange.gps.init(true);
        });
    </script>
    <noscript id="noscript-css"><style>body,.top-bar{margin-top:1.9em}</style></noscript>
    </head>
    <body class="tagged-questions-page unified-theme">
    <div id="notify-container"></div>
    <div id="custom-header"></div>
        
<header class="top-bar js-top-bar top-bar__network _fixed">
    <div class="wmx12 mx-auto grid ai-center h100" role="menubar">
        <div class="-main grid--cell">
                <a href="#" class="left-sidebar-toggle p0 ai-center jc-center js-left-sidebar-toggle" role="menuitem" aria-haspopup="true" aria-controls="left-sidebar" aria-expanded="false"><span class="ps-relative"></span></a>
                <div class="topbar-dialog leftnav-dialog js-leftnav-dialog dno">
                    <div class="left-sidebar js-unpinned-left-sidebar" data-can-be="left-sidebar" data-is-here-when="sm"></div>
                </div>
                    <a href="https://stackoverflow.com" class="-logo js-gps-track"
                        data-gps-track="top_nav.click({is_current:false, location:5, destination:8})">
                        <span class="-img _glyph">Stack Overflow</span>
                    </a>



        </div>

            <ol class="list-reset grid gs4" role="presentation">
                <li class="grid--cell">
                    <a href="#"
                        class="-marketing-link js-gps-track js-products-menu"
                        aria-controls="products-popover"
                        data-controller="s-popover"
                        data-action="s-popover#toggle"
                        data-s-popover-placement="bottom"
                        data-s-popover-toggle-class="is-selected"
                        data-gps-track="top_nav.products.click({location:5, destination:1})"
                        data-ga="[&quot;top navigation&quot;,&quot;products menu click&quot;,null,null,null]">
                        Products
                    </a>
                </li>

                    <li class="grid--cell md:d-none">
                        <a href="/teams/customers" class="-marketing-link js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:7})"
                            data-ga="[&quot;top navigation&quot;,&quot;customers menu click&quot;,null,null,null]">Customers</a>
                    </li>
                    <li class="grid--cell md:d-none">
                        <a href="/teams/use-cases" class="-marketing-link js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:8})"
                           data-ga="[&quot;top navigation&quot;,&quot;use cases menu click&quot;,null,null,null]">Use cases</a>
                    </li>
            </ol>
            <div class="s-popover ws2 p6"
                    id="products-popover"
                    role="menu"
                    aria-hidden="true">
                <div class="s-popover--arrow"></div>
                <ol class="list-reset s-anchors s-anchors__inherit">
                    <li>
                        <a href="/questions" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:2})"
                           data-ga="[&quot;top navigation&quot;,&quot;public qa submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Stack Overflow</span>
                            <span class="fs-caption d-block fc-light">Public questions and answers</span>
                        </a>
                    </li>
                    <li>
                        <a href="/teams" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:3})"
                           data-ga="[&quot;top navigation&quot;,&quot;teams submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Teams</span>
                            <span class="fs-caption d-block fc-light">Private questions and answers for your team</span>
                        </a>
                    </li>
                    <li>
                        <a href="/enterprise" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:4})"
                           data-ga="[&quot;top navigation&quot;,&quot;enterprise submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Enterprise</span>
                            <span class="fs-caption d-block fc-light">Private self-hosted questions and answers for your enterprise</span>
                        </a>
                    </li>
                    <li>
                        <a href="/jobs?so_source=ProductsMenu&so_medium=StackOverflow" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                            data-gps-track="top_nav.products.click({location:5, destination:9})"
                            data-ga="[&quot;top navigation&quot;,&quot;jobs submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Jobs</span>
                            <span class="fs-caption d-block fc-light">Programming and related technical career opportunities</span>
                        </a>
                    </li>
                    <li class="bt bc-black-3 mln6 mrn6 mt6 pt6 px6" >
                        <a href="https://stackoverflow.com/talent" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:5})"
                           data-ga="[&quot;top navigation&quot;,&quot;talent submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Talent</span>
                            <span class="fs-caption d-block fc-light">Hire technical talent</span>
                        </a>
                    </li>
                    <li>
                        <a href="https://stackoverflow.com/advertising" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:6})"
                           data-ga="[&quot;top navigation&quot;,&quot;advertising submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Advertising</span>
                            <span class="fs-caption d-block fc-light">Reach developers worldwide</span>
                        </a>
                    </li>

                </ol>
            </div>

            <form id="search" role="search" action=/search method="get" class="grid--cell fl-grow1 searchbar px12 js-searchbar " autocomplete="off">
                    <div class="ps-relative">
                        <input name="q"
                               type="text"
                               placeholder="Search&#x2026;"
                               value="[node.js]"
                               autocomplete="off"
                               maxlength="240"
                               class="s-input s-input__search js-search-field "
                               aria-label="Search"
                               aria-controls="top-search" 
                               data-controller="s-popover"
                               data-action="focus->s-popover#show"
                               data-s-popover-placement="bottom-start"/>
                        <svg aria-hidden="true" class="s-input-icon s-input-icon__search svg-icon iconSearch" width="18" height="18" viewBox="0 0 18 18"><path d="M18 16.5l-5.14-5.18h-.35a7 7 0 10-1.19 1.19v.35L16.5 18l1.5-1.5zM12 7A5 5 0 112 7a5 5 0 0110 0z"/></svg>
                        <div class="s-popover p0 wmx100 wmn4 sm:wmn-initial js-top-search-popover s-popover--arrow__tl" id="top-search" role="menu">
    <div class="js-spinner p24 grid ai-center jc-center d-none">
        <div class="s-spinner s-spinner__sm fc-orange-400">
            <div class="v-visible-sr">Loading&#x2026;</div>
        </div>
    </div>

    <span class="v-visible-sr js-screen-reader-info"></span>
    <div class="js-ac-results overflow-y-auto hmx3 d-none"></div>

    <div class="js-search-hints" aria-describedby="Tips for searching"></div>
</div>
                    </div>
            </form>
        
        

<ol class="overflow-x-auto ml-auto -secondary grid ai-center list-reset h100 user-logged-out" role="presentation">
        <li class="-item searchbar-trigger"><a href="#" class="-link js-searchbar-trigger" role="button" aria-label="Search" aria-haspopup="true" aria-controls="search" title="Click to show search"><svg aria-hidden="true" class="svg-icon iconSearch" width="18" height="18" viewBox="0 0 18 18"><path d="M18 16.5l-5.14-5.18h-.35a7 7 0 10-1.19 1.19v.35L16.5 18l1.5-1.5zM12 7A5 5 0 112 7a5 5 0 0110 0z"/></svg></a></li>

            <li class="-ctas">
                            <a href="https://stackoverflow.com/users/login?ssrc=head&returnurl=https%3a%2f%2fstackoverflow.com%2fquestions%2ftagged%2fnode.js" class="login-link s-btn s-btn__filled py8 js-gps-track" rel="nofollow"
                               data-gps-track="login.click" data-ga="[&quot;top navigation&quot;,&quot;login button click&quot;,null,null,null]">Log in</a>
                            <a href="https://stackoverflow.com/users/signup?ssrc=head&returnurl=%2fusers%2fstory%2fcurrent" class="login-link s-btn s-btn__primary py8" rel="nofollow" data-ga="[&quot;sign up&quot;,&quot;Sign Up Navigation&quot;,&quot;Header&quot;,null,null]">Sign up</a>

            </li>

    <li class="js-topbar-dialog-corral" role="presentation">
            

    <div class="topbar-dialog siteSwitcher-dialog dno" role="menu">
        <div class="header">
            <h3>
                <a href="https://stackoverflow.com">current community</a>
            </h3>
        </div>
        <div class="modal-content bg-powder-050">
            <ul class="current-site">
                    <li class="grid">
                            <div class="fl1">
                <a href="https://stackoverflow.com"
       class="current-site-link site-link js-gps-track grid gs8 gsx"
       data-id="1"
       data-gps-track="site_switcher.click({ item_type:3 })">
        <div class="favicon favicon-stackoverflow site-icon grid--cell" title="Stack Overflow"></div>
        <span class="grid--cell fl1">
            Stack Overflow
        </span>
    </a>

    </div>
    <div class="related-links">
            <a href="https://stackoverflow.com/help" class="js-gps-track" data-gps-track="site_switcher.click({ item_type:14 })">help</a>
            <a href="https://chat.stackoverflow.com" class="js-gps-track" data-gps-track="site_switcher.click({ item_type:6 })">chat</a>
    </div>

                    </li>
                    <li class="related-site grid">
                            <div class="L-shaped-icon-container">
        <span class="L-shaped-icon"></span>
    </div>

                            <a href="https://meta.stackoverflow.com"
       class=" site-link js-gps-track grid gs8 gsx"
       data-id="552"
       data-gps-track="site.switch({ target_site:552, item_type:3 }),site_switcher.click({ item_type:4 })">
        <div class="favicon favicon-stackoverflowmeta site-icon grid--cell" title="Meta Stack Overflow"></div>
        <span class="grid--cell fl1">
            Meta Stack Overflow
        </span>
    </a>

                    </li>
            </ul>
        </div>

        <div class="header" id="your-communities-header">
            <h3>
your communities            </h3>

        </div>
        <div class="modal-content" id="your-communities-section">

                <div class="call-to-login">
<a href="https://stackoverflow.com/users/signup?ssrc=site_switcher&amp;returnurl=%2fusers%2fstory%2fcurrent" class="login-link js-gps-track" data-gps-track="site_switcher.click({ item_type:10 })">Sign up</a> or <a href="https://stackoverflow.com/users/login?ssrc=site_switcher&amp;returnurl=https%3a%2f%2fstackoverflow.com%2fquestions%2ftagged%2fnode.js" class="login-link js-gps-track" data-gps-track="site_switcher.click({ item_type:11 })">log in</a> to customize your list.                </div>
        </div>

        <div class="header">
            <h3><a href="https://stackexchange.com/sites">more stack exchange communities</a>
            </h3>
            <a href="https://stackoverflow.blog" class="fr">company blog</a>
        </div>
        <div class="modal-content">
                <div class="child-content"></div>
        </div>        
    </div>

    </li>
</ol>
    </div>
</header>
    <div id="js-gdpr-consent-banner" class="p8 ff-sans ps-fixed b0 l0 r0 z-banner" role="banner" aria-hidden="false" style="background-color: #3b4045; color: white;"> 
        <div class="wmx8 mx-auto grid grid__center" role="alertdialog" aria-describedby="notice-message">
            <div class="grid--cell mr12" aria-label="notice-message">
                <p class="mb0 lh-lg">
                    By using our site, you acknowledge that you have read and understand our <a class="s-link s-link__inherit td-underline fc-white" target="_blank" href="https://stackoverflow.com/legal/cookie-policy">Cookie Policy</a>, <a class="s-link s-link__inherit td-underline fc-white" target="_blank" href="https://stackoverflow.com/legal/privacy-policy">Privacy Policy</a>, and our <a class="s-link s-link__inherit td-underline fc-white" target="_blank" href="https://stackoverflow.com/legal/terms-of-service/public">Terms of Service</a>.
                </p>
            </div>
            <div class="grid--cell">
                <a class="s-btn s-btn__muted s-btn__icon js-notice-close" aria-label="notice-dismiss">
                    <svg aria-hidden="true" class="svg-icon iconClear" width="18" height="18" viewBox="0 0 18 18"><path d="M15 4.41L13.59 3 9 7.59 4.41 3 3 4.41 7.59 9 3 13.59 4.41 15 9 10.41 13.59 15 15 13.59 10.41 9 15 4.41z"/></svg>
                </a>
            </div>
        </div>
    </div>

    <script>
        StackExchange.ready(function () { StackExchange.topbar.init(); });
StackExchange.scrollPadding.setPaddingTop(50, 10);    </script>





    <div class="container">
            

<div id="left-sidebar" data-is-here-when="md lg" class="left-sidebar js-pinned-left-sidebar ps-relative">
    <div class="left-sidebar--sticky-container js-sticky-leftnav">
        <nav role="navigation">
            <ol class="nav-links">
        <li class="">
            <a
                href="/"
                class="pl8 js-gps-track nav-links--link"
                
                data-gps-track="top_nav.click({is_current:false, location:5, destination:8})">
Home            </a>
        </li>
                <li>
                    <ol class="nav-links">
                            <li class="fs-fine tt-uppercase ml8 mt16 mb4 fc-light">Public</li>
                                <li class=" youarehere">
            <a id="nav-questions"
                href="/questions"
                class="pl8 js-gps-track nav-links--link -link__with-icon"
                
                data-gps-track="top_nav.click({is_current:true, location:5, destination:1})">
<svg aria-hidden="true" class="svg-icon iconGlobe" width="18" height="18" viewBox="0 0 18 18"><path d="M9 1a8 8 0 100 16A8 8 0 009 1zM8 15.32a6.4 6.4 0 01-5.23-7.75L7 11.68v.8c0 .88.12 1.32 1 1.32v1.52zm5.72-2c-.2-.66-1-1.32-1.72-1.32h-1v-2c0-.44-.56-1-1-1H6V7h1c.44 0 1-.56 1-1V5h2c.88 0 1.4-.72 1.4-1.6v-.33a6.4 6.4 0 012.32 10.24v.01z"/></svg>                    <span class="-link--channel-name">Stack Overflow</span>
            </a>
        </li>

        <li class="">
            <a id="nav-tags"
                href="/tags"
                class=" js-gps-track nav-links--link"
                
                data-gps-track="top_nav.click({is_current:false, location:5, destination:2})">
Tags            </a>
        </li>
        <li class="">
            <a id="nav-users"
                href="/users"
                class=" js-gps-track nav-links--link"
                
                data-gps-track="top_nav.click({is_current:false, location:5, destination:3})">
Users            </a>
        </li>
                            <li class="fs-fine tt-uppercase ml8 mt16 mb4 fc-light">Find a Job</li>
        <li class="">
            <a id="nav-jobs"
                href="/jobs?so_medium=StackOverflow&amp;so_source=SiteNav"
                class=" js-gps-track nav-links--link"
                
                data-gps-track="top_nav.click({is_current:false, location:5, destination:6})">
Jobs            </a>
        </li>
        <li class="">
            <a id="nav-companies"
                href="/jobs/companies?so_medium=StackOverflow&amp;so_source=SiteNav"
                class=" js-gps-track nav-links--link"
                
                data-gps-track="top_nav.click({is_current:false, location:5, destination:12})">
Companies            </a>
        </li>
                    </ol>
                </li>
                    <li>
                        <ol class="nav-links">
                                <li class="grid ai-center jc-space-between ml8 mt24 mb4">
                                    <div class="grid--cell tt-uppercase fs-fine fc-light">Teams</div>
                                    <div class="grid--cell fs-fine fc-light mr4">
                                        <a href="javascript:void(0)" class="s-link s-link__inherit js-gps-track"
                                            role="button"
                                            aria-controls="popover-teams-create-cta"
                                            data-controller="s-popover"
                                            data-action="s-popover#toggle"
                                            data-s-popover-placement="bottom-start"
                                            data-s-popover-toggle-class="is-selected"
                                            data-gps-track="teams.create.left-sidenav.click({ Action: ShowInfo })"
                                            data-ga="[&quot;teams left navigation - anonymous&quot;,&quot;left nav show teams info&quot;,null,null,null]">
                                            What&#x2019;s this?
                                        </a>

                                    </div>
                                </li>
                                <li class="ps-relative">
                                    <a href="https://stackoverflow.com/teams"
                                        class="pl8 js-gps-track nav-links--link"
                                        title="Stack Overflow for Teams is a private, secure spot for your organization's questions and answers."
                                        data-gps-track="teams.create.left-sidenav.click({ Action: TeamsClick })"
                                        data-ga="[&quot;teams left navigation - anonymous&quot;,&quot;left nav team click&quot;,&quot;stackoverflow.com/teams&quot;,null,null]">
                                        <div class="grid ai-center">
                                            <div class="grid--cell s-avatar va-middle bg-orange-400">
                                                <div class="s-avatar--letter mtn1">
                                                    <svg aria-hidden="true" class="svg-icon iconBriefcaseSm" width="14" height="14" viewBox="0 0 14 14"><path d="M4 3a1 1 0 011-1h4a1 1 0 011 1v1h.5c.83 0 1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5h-7A1.5 1.5 0 012 10.5v-5C2 4.67 2.67 4 3.5 4H4V3zm5 1V3H5v1h4z"/></svg>
                                                </div>
                                                <svg aria-hidden="true" class="native s-avatar--badge svg-icon iconShieldXSm" width="9" height="10" viewBox="0 0 9 10"><path d="M0 1.84L4.5 0 9 1.84v3.17C9 7.53 6.3 10 4.5 10 2.7 10 0 7.53 0 5.01V1.84z" fill="var(--white)"/><path d="M1 2.5L4.5 1 8 2.5v2.51C8 7.34 5.34 9 4.5 9 3.65 9 1 7.34 1 5.01V2.5zm2.98 3.02L3.2 7h2.6l-.78-1.48a.4.4 0 01.15-.38c.34-.24.73-.7.73-1.14 0-.71-.5-1.23-1.41-1.23-.92 0-1.39.52-1.39 1.23 0 .44.4.9.73 1.14.12.08.18.23.15.38z" fill="var(--black-500)"/></svg>
                                            </div>
                                            <div class="grid--cell pl6">
Free 30 Day Trial                                            </div>
                                        </div>
                                    </a>
                                </li>
                        </ol>
                    </li>
            </ol>
        </nav>
    </div>


        <div class="s-popover w-auto p16"
             id="popover-teams-create-cta"
             role="menu"
             aria-hidden="true">
            <div class="s-popover--arrow"></div>

            <div class="ps-relative overflow-hidden">
                <p class="mb2"><strong>Teams</strong></p>
                <p class="mb16 fs-caption fc-medium">Q&amp;A for Work</p>
                <p class="mb8 fs-caption fc-medium">

                            Stack Overflow for Teams is a private, secure spot for you and
                            your coworkers to find and share information.
                                        </p>
                <a href="https://stackoverflow.com/teams"
                   class="js-gps-track ws-nowrap d-block"
                   data-gps-track="teams.create.left-sidenav.click({ Action: CtaClick })"
                   data-ga="[&quot;teams left navigation - anonymous&quot;,&quot;left nav cta&quot;,&quot;stackoverflow.com/teams&quot;,null,null]">
Learn more                </a>
            </div>

            <div class="ps-absolute t8 r8">
                <svg width="53" height="49" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M49 11l.2 31H18.9L9 49v-7H4V8h31" fill="#CCEAFF" /><path d="M44.5 19v-.3l-.2-.1-18-13-.1-.1H.5v33h4V46l.8-.6 9.9-6.9h29.3V19z" stroke="#1060E1" stroke-miterlimit="10" /><path d="M31 2l6-1.5 7 2V38H14.9L5 45v-7H1V6h25l5-4z" fill="#fff" /><path d="M7 16.5h13m-13 6h14m-14 6h18" stroke="#1060E1" stroke-miterlimit="10" /><path d="M39 30a14 14 0 1 0 0-28 14 14 0 0 0 0 28z" fill="#FFB935" /><path d="M50.5 14a13.5 13.5 0 1 1-27 0 13.5 13.5 0 0 1 27 0z" stroke="#F48024" stroke-miterlimit="10" /><path d="M32.5 21.5v-8h9v8h-9zm2-9.5V9.3A2.5 2.5 0 0 1 37 6.8a2.5 2.5 0 0 1 2.5 2.5V12h-5zm2 3v2m1-2v2" stroke="#fff" stroke-miterlimit="10" /></svg>
            </div>
        </div>

</div>



        <div id="content" class="snippet-hidden">

            
    <div id="mainbar">
        

        <div class="grid">
            <div class="grid fl1 mb24">
                <h1 class="grid--cell fs-headline1 mb0">
Questions tagged [node.js]                </h1>
            </div>

            <div class="ml12 aside-cta grid--cell print:d-none">
                
    <a href="/questions/ask" class="ws-nowrap s-btn s-btn__primary" >
        Ask Question
    </a>

            </div>
        </div>

    <style>.everyoneloves__top-leaderboard:empty,.everyoneloves__mid-leaderboard:empty,.everyoneloves__bot-mid-leaderboard:empty{
            margin-bottom:0;
}
</style>
<div id="dfp-tag" class="everyonelovesstackoverflow everyoneloves__tag-sponsorship mb12"></div>

                        <div class="mb24">
                    <p>
Node.js is an event-based, non-blocking, asynchronous I/O runtime that uses Google&#x27;s V8 JavaScript engine and libuv library. It is used for developing applications that make heavy use of the ability to run JavaScript both on the client, as well as on server side and therefore benefit from the re-usability of code and the lack of context switching.                    </p>
                    <div class=" grid gs12 jc-space-between ai-center fw-wrap">
                        <div class="grid--cell">
                            <ul class="grid gs12 list-ls-none fw-wrap">
                                    <li class="grid--cell">
                                        <a title="Tag wiki" href="/tags/node.js/info">Learn more…</a>
                                    </li>
                                <li class="grid--cell">
                                    <a title="Top answerers and askers in this tag" href="/tags/node.js/topusers">Top users</a>
                                </li>
                                <li class="grid--cell">
                                    <a title="Common, alternate spellings or phrasings for this tag" href="/tags/node.js/synonyms">Synonyms (2)</a>
                                </li>
                                    <li class="grid--cell">
                                        <a title="Find yourself a job" href="/jobs/developer-jobs-using-node.js?med=site-ui&ref=tag-page_node.js">node.js jobs</a>
                                    </li>
                            </ul>
                        </div>
                    </div>
            </div>


            
<script>
    StackExchange.ready(function () {
        initTagRenderer("".split(" "), "".split(" "));
        StackExchange.userQuestionList.init({
            sharingUrl: ""
        });
    });
</script>
<div data-controller="se-uql" data-se-uql-id="" data-se-uql-sanitize-tag-query="false">
    <div class="grid ai-center jc-space-between mb12 sm:fd-column sm:ai-stretch">
        <div class="fs-body3 grid--cell fl1 mr12 sm:mr0 sm:mb12">
            338,120

questions        </div>

        <div class="uql-nav grid--cell"
             data-action="se-uql-list:edit-current-requested@document->se-uql#toggleEditor">
            <div class="grid ai-center jc-space-between">
                <div class="js-uql-navigation s-btn-group grid--cell mr16 ff-row-nowrap">
                        <a class="s-btn s-btn__muted s-btn__outlined s-btn__sm grid d-flex is-selected" data-nav-value="Newest" href="/questions/tagged/node.js?tab=Newest" data-shortcut="N">
                            <div class="grid--cell">Newest</div>
                        </a>
                        <a class="s-btn s-btn__muted s-btn__outlined s-btn__sm grid d-flex" data-nav-value="Active" href="/questions/tagged/node.js?tab=Active" data-shortcut="A">
                            <div class="grid--cell">Active</div>
                        </a>
                        <a class="s-btn s-btn__muted s-btn__outlined s-btn__sm grid d-flex uql-nav--expanded-item" data-nav-value="Bounties" href="/questions/tagged/node.js?tab=Bounties" data-shortcut="E">
                            <div class="grid--cell">Bountied</div>
                                <div class="s-badge s-badge__bounty s-badge__bounty s-badge__sm lh-xs ml4 px4 grid--cell">21</div>
                        </a>
                        <a class="s-btn s-btn__muted s-btn__outlined s-btn__sm grid d-flex uql-nav--expanded-item" data-nav-value="Unanswered" href="/questions/tagged/node.js?tab=Unanswered" data-shortcut="U">
                            <div class="grid--cell">Unanswered</div>
                        </a>
                    <button class="s-btn s-btn__muted s-btn__outlined s-btn__sm s-btn__dropdown"
                            role="button"
                            data-controller="s-popover"
                            data-action="s-popover#toggle"
                            data-target="se-uql.toggleMoreButton"
                            aria-haspopup="true"
                            aria-expanded="false"
                            aria-controls="uql-more-popover">
                        More
                    </button>
                </div>

                <div class="s-popover z-dropdown ws2"
                     id="uql-more-popover"
                     data-target="se-uql.morePopover">
                    <div class="s-popover--arrow"></div>
                    <ul class="list-reset mtn8 mbn8 js-uql-navigation">
                            <li class="uql-item my0 uql-nav--collapsed-item">
                                    <a href="/questions/tagged/node.js?tab=Bounties" class="mln12 mrn12 px12 py6 fl1 s-block-link" data-shortcut="">
                                        Bountied
                                            <span class="s-badge s-badge__bounty s-badge__bounty s-badge__sm lh-xs px4">21</span>
                                    </a>
                            </li>
                            <li class="uql-item my0 uql-nav--collapsed-item">
                                    <a href="/questions/tagged/node.js?tab=Unanswered" class="mln12 mrn12 px12 py6 fl1 s-block-link" data-shortcut="">
                                        Unanswered
                                    </a>
                            </li>
                            <li class="uql-item my0">
                                    <a href="/questions/tagged/node.js?tab=Frequent" class="mln12 mrn12 px12 py6 fl1 s-block-link" data-shortcut="F">
                                        Frequent
                                    </a>
                            </li>
                            <li class="uql-item my0">
                                    <a href="/questions/tagged/node.js?tab=Votes" class="mln12 mrn12 px12 py6 fl1 s-block-link" data-shortcut="V">
                                        Votes
                                    </a>
                            </li>
                                <li class="uql-item uql-item__separator bg-black-075 d:bg-black-025"></li>
                            <li class="uql-item my0">
                                    <span class="s-block-link c-default fc-black-100 mrn12 px12 py6">Unanswered (my tags)</span>
                            </li>
                    </ul>
                </div>

                <div class="grid--cell">
                    <button class="s-btn s-btn__filled s-btn__sm s-btn__icon ws-nowrap"
                            role="button"
                            data-controller="s-expandable-control"
                            data-s-expandable-control-toggle-class="is-selected"
                            data-target="se-uql.toggleFormButton"
                            aria-expanded="false"
                            aria-controls="uql-form">
                        <svg aria-hidden="true" class="sm:d-none va-middle svg-icon iconGearSm" width="14" height="14" viewBox="0 0 14 14"><path d="M8.17 11.42l-.39 1.53a6.07 6.07 0 01-1.58 0l-.39-1.53c-.39-.1-.75-.26-1.1-.46l-1.35.8c-.42-.31-.8-.69-1.12-1.1l.8-1.37c-.2-.34-.35-.7-.46-1.1L1.05 7.8a6.06 6.06 0 010-1.57l1.53-.4c.1-.4.25-.76.45-1.11l-.8-1.36c.32-.42.7-.8 1.1-1.11l1.36.8c.35-.2.73-.36 1.13-.47l.4-1.53a6.06 6.06 0 011.55 0l.4 1.53c.4.1.78.26 1.13.47l1.36-.8c.41.31.78.68 1.1 1.1l-.8 1.36c.2.35.36.73.46 1.13l1.53.39a6.06 6.06 0 010 1.57l-1.53.39c-.1.4-.27.77-.47 1.11l.8 1.36c-.32.42-.7.8-1.11 1.11l-1.36-.8c-.34.2-.71.35-1.1.45zM7 9a2 2 0 100-4 2 2 0 000 4z"/></svg> Filter
                    </button>
                </div>
            </div>


        </div>
    </div>

    <form class="s-expandable ps-relative z-active"
          id="uql-form"
          data-target="se-uql.form"
          data-action="se-uql#navigate">
        <input name="uqlId" type="hidden"/>
        <div class="s-expandable--content">
            <div class="bg-black-050 ba bc-black-3 bar-sm mb16">
                <div class="px12 py16">
                    <div class="grid gs32 fw-wrap">
                        <div class="grid--cell">
                            <fieldset class="grid gs8 gsy fd-column">
                                <legend class="grid--cell s-label px0">Filter by</legend>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-checkbox d-block"
                           type="checkbox"
                           name="filterId"
                           value="NoAnswers"
                           id="5ead676e-2279-452d-ab8c-9463dccb669b" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="5ead676e-2279-452d-ab8c-9463dccb669b">No answers</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-checkbox d-block"
                           type="checkbox"
                           name="filterId"
                           value="NoAcceptedAnswer"
                           id="86c425d7-4aaa-4135-a236-b96fcd379382" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="86c425d7-4aaa-4135-a236-b96fcd379382">No accepted answer</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-checkbox d-block"
                           type="checkbox"
                           name="filterId"
                           value="Bounty"
                           id="4743b918-1da1-4865-abba-46cf8a4308e9" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="4743b918-1da1-4865-abba-46cf8a4308e9">Has bounty</label>
            </div>
        </div>
                            </fieldset>
                        </div>
                        <div class="grid--cell">
                            <fieldset class="grid gs8 gsy fd-column">
                                <legend class="grid--cell s-label px0">Sorted by</legend>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="sortId"
                           value="Newest"
                           checked="checked"
                           id="2f653505-5c50-4bbf-b92a-4e957d10a1ee" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="2f653505-5c50-4bbf-b92a-4e957d10a1ee">Newest</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="sortId"
                           value="RecentActivity"
                           id="6f4967a8-2a2d-4662-9baf-e85d5d9169f7" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="6f4967a8-2a2d-4662-9baf-e85d5d9169f7">Recent activity</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="sortId"
                           value="MostVotes"
                           id="03c27cc4-0c00-4a71-9a91-78cad98f67c1" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="03c27cc4-0c00-4a71-9a91-78cad98f67c1">Most votes</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="sortId"
                           value="MostFrequent"
                           id="54816282-a086-4438-b773-65e0a64ee6a7" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="54816282-a086-4438-b773-65e0a64ee6a7">Most frequent</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="sortId"
                           value="BountyEndingSoon"
                           id="ed4eb5a5-f99f-4bcf-afba-3518b9f3289c" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="ed4eb5a5-f99f-4bcf-afba-3518b9f3289c">Bounty ending soon</label>
            </div>
        </div>
                            </fieldset>
                        </div>
                        <div class="grid--cell">
                            <fieldset class="grid gs8 gsy fd-column">
                                <legend class="grid--cell s-label px0">Tagged with</legend>
                                        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="tagModeId"
                           value="Watched"
                           id="40a86b41-fd7c-4541-9bc3-37e7ff3827b8" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="40a86b41-fd7c-4541-9bc3-37e7ff3827b8">My watched tags</label>
            </div>
        </div>

                                        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="tagModeId"
                           value="Specified"
                           checked="checked"
                           id="167d18a7-7210-431a-bef3-f9e4962cb04b" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="167d18a7-7210-431a-bef3-f9e4962cb04b">The following tags:</label>
            </div>
        </div>

                            </fieldset>
                            <div class="ps-relative ml24 mt8 ws2">
                                <input id="uql-modal-tag-input" class="w100 s-input" name="tagQuery" data-target="se-uql.tagQuery" type="text" size="60" tabindex="0" placeholder="e.g. javascript or java" value="node.js">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p12 bt bc-black-3">
                    <div class="grid">
                        <div class="grid gs4 gsx fl1">
                            <button class="s-btn s-btn__sm s-btn__primary grid--cell" type="submit" data-target="se-uql.applyButton">Apply filter</button>
                        </div>
                        <div class="grid--cell">
                            <button class="s-btn s-btn__sm" data-action="se-uql#cancelEditor" type="button">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

</div>


        <div id="questions" class="flush-left">
<div class="question-summary" id="question-summary-62797799">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="2 views">
    2 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797799/multiple-api-calls-in-loop-fails" class="question-hyperlink">Multiple api calls in loop fails</a></h3>
        <div class="excerpt">
            Having some issues when calling an external api to fetch information inside a loop in my node/express backend. I need information I get from the loop to get the correct data back from the endpoint. ...
        </div>
        <div class="tags t-nodeûjs t-express t-async-await">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/express" class="post-tag" title="show questions tagged &#39;express&#39;" rel="tag">express</a> <a href="/questions/tagged/async-await" class="post-tag" title="show questions tagged &#39;async-await&#39;" rel="tag">async-await</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 15:02:25Z" class="relativetime">1 min ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/11369415/gameatrix"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/ad7cbcf5691b5c8c2377874019438f46?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/11369415/gameatrix">GameAtrix</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">63</span><span title="6 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">6</span></span><span class="v-visible-sr">6 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797651">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>-1</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="21 views">
    21 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797651/how-to-return-object-from-fetch-function" class="question-hyperlink">How to return object from fetch function?</a></h3>
        <div class="excerpt">
            I'd like to create an external function that fetch data and return the result.
But I can't make it work, here's my function:
```
// Request.js:
import React from 'react'
import { authHeader } from &...
        </div>
        <div class="tags t-javascript t-nodeûjs t-reactjs t-fetch">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/reactjs" class="post-tag" title="show questions tagged &#39;reactjs&#39;" rel="tag">reactjs</a> <a href="/questions/tagged/fetch" class="post-tag" title="show questions tagged &#39;fetch&#39;" rel="tag">fetch</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:54:58Z" class="relativetime">8 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/13892224/sacha-apk"><div class="gravatar-wrapper-32"><img src="https://lh4.googleusercontent.com/-1im_MwM1pXI/AAAAAAAAAAI/AAAAAAAAAAA/AMZuucljpGD3hzAc7U19_zQj8m2ej2W3tg/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/13892224/sacha-apk">Sacha APK</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797627">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="6 views">
    6 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797627/nodejs-add-device-to-ble-whitelist" class="question-hyperlink">NodeJS - add device to BLE whitelist</a></h3>
        <div class="excerpt">
            I am using @abandonware/noble for scanning and interrogating Bluetooth devices on Linux. I could not, however, find a method to add a MAC address to the LE whitelist, similar to hcitool lewladd on ...
        </div>
        <div class="tags t-nodeûjs t-bluetooth-lowenergy">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/bluetooth-lowenergy" class="post-tag" title="show questions tagged &#39;bluetooth-lowenergy&#39;" rel="tag">bluetooth-lowenergy</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:53:42Z" class="relativetime">9 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/2408418/slav"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/71c70c6bc07b6c18d18befb7a74bb7ef?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/2408418/slav">Slav</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">25</span><span title="5 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">5</span></span><span class="v-visible-sr">5 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797612">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="6 views">
    6 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797612/node-js-api-shows-front-end-code-in-response-when-i-try-to-run-my-login-api" class="question-hyperlink">Node.js API shows Front End code in response when I try to run my login API</a></h3>
        <div class="excerpt">
            This is a bug I am facing in my project, with front end in REACT NATIVE, and REST API in NODE.JS at the back end, the database used is mongodb.
When I use my REST API to login, on my local server, it ...
        </div>
        <div class="tags t-nodeûjs t-mongodb t-rest t-swagger t-response">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/mongodb" class="post-tag" title="show questions tagged &#39;mongodb&#39;" rel="tag">mongodb</a> <a href="/questions/tagged/rest" class="post-tag" title="show questions tagged &#39;rest&#39;" rel="tag">rest</a> <a href="/questions/tagged/swagger" class="post-tag" title="show questions tagged &#39;swagger&#39;" rel="tag">swagger</a> <a href="/questions/tagged/response" class="post-tag" title="show questions tagged &#39;response&#39;" rel="tag">response</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:52:59Z" class="relativetime">10 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/10211323/utkarsh-shrivastava"><div class="gravatar-wrapper-32"><img src="https://lh5.googleusercontent.com/-RL_0hNVLp5k/AAAAAAAAAAI/AAAAAAAAAbU/9Hd-Sbo8dwI/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/10211323/utkarsh-shrivastava">Utkarsh Shrivastava</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">33</span><span title="3 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">3</span></span><span class="v-visible-sr">3 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797595">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>1</strong></span>
                    <div class="viewcount">vote</div>
                </div>
            </div>
            <div class="status answered">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="10 views">
    10 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797595/mongodb-aggregate-with-sum-of-array-object-values" class="question-hyperlink">MongoDB Aggregate with sum of array object values</a></h3>
        <div class="excerpt">
            I have a collection with the following data:
{ &quot;id&quot;: 1,
  &quot;name&quot;: &quot;abc&quot;,
  &quot;age&quot; : &quot;12&quot;
  &quot;quizzes&quot;: [
      {
          &quot;id&quot;: &...
        </div>
        <div class="tags t-nodeûjs t-mongodb t-mongodb-query">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/mongodb" class="post-tag" title="show questions tagged &#39;mongodb&#39;" rel="tag">mongodb</a> <a href="/questions/tagged/mongodb-query" class="post-tag" title="show questions tagged &#39;mongodb-query&#39;" rel="tag">mongodb-query</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:51:56Z" class="relativetime">11 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/5821627/mostafa-habibi"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/7583d142e5a8ec541f9a90a26357d534?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/5821627/mostafa-habibi">Mostafa Habibi</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">71</span><span title="5 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">5</span></span><span class="v-visible-sr">5 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797510">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="11 views">
    11 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797510/deploying-react-js-and-node-js-full-stack-on-aws-production" class="question-hyperlink">Deploying react js and node js full stack on AWS production?</a></h3>
        <div class="excerpt">
            I have currently deployed the React and Node.js on nginx which sits on AWS . I have no issues in deployment and no errors.
The current environment is: PRODUCTION.
But I have a doubt whether the method ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-reactjs t-amazon-web-services t-nginx">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/reactjs" class="post-tag" title="show questions tagged &#39;reactjs&#39;" rel="tag">reactjs</a> <a href="/questions/tagged/amazon-web-services" class="post-tag" title="show questions tagged &#39;amazon-web-services&#39;" rel="tag">amazon-web-services</a> <a href="/questions/tagged/nginx" class="post-tag" title="show questions tagged &#39;nginx&#39;" rel="tag">nginx</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:48:11Z" class="relativetime">15 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/10335023/rittesh-p-v"><div class="gravatar-wrapper-32"><img src="https://lh6.googleusercontent.com/-SWMHoVsXBC0/AAAAAAAAAAI/AAAAAAAABjc/F4secWOtoU8/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/10335023/rittesh-p-v">Rittesh P.V</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">77</span><span title="1 silver badge" aria-hidden="true"><span class="badge2"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 silver badge</span><span title="8 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">8</span></span><span class="v-visible-sr">8 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797506">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="6 views">
    6 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797506/cant-open-chrome-browser-under-my-profile-in-autotest-selenium" class="question-hyperlink">can&#39;t open chrome browser under my profile in autotest selenium [duplicate]</a></h3>
        <div class="excerpt">
            I run an autotest. A browser opens without logging into my profile. The path to the profile was written in the arguments. What can be wrong?
How can I run an autotest so that the browser opens with my ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-selenium t-selenium-webdriver">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/selenium" class="post-tag" title="show questions tagged &#39;selenium&#39;" rel="tag">selenium</a> <a href="/questions/tagged/selenium-webdriver" class="post-tag" title="show questions tagged &#39;selenium-webdriver&#39;" rel="tag">selenium-webdriver</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:47:59Z" class="relativetime">15 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/7510932/%d0%90%d0%bb%d0%b5%d0%ba%d1%81%d0%b0%d0%bd%d0%b4%d1%80"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/a296a3039bbea5f31de8c22a0a29face?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/7510932/%d0%90%d0%bb%d0%b5%d0%ba%d1%81%d0%b0%d0%bd%d0%b4%d1%80">Александр</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">137</span><span title="8 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">8</span></span><span class="v-visible-sr">8 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797497">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="3 views">
    3 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797497/react-native-using-expo-suddenly-does-not-want-to-start-giving-saying-react-runt" class="question-hyperlink">React native using expo suddenly does not want to start giving saying React runtime does not include the Node standard library</a></h3>
        <div class="excerpt">
            When I try to open expo project on my android phone I get this error message:

The package at "node_modules\body-parser\lib\types\urlencoded.js" attempted to import the Node standard library module "...
        </div>
        <div class="tags t-javascript t-nodeûjs t-react-native t-expo">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/react-native" class="post-tag" title="show questions tagged &#39;react-native&#39;" rel="tag">react-native</a> <a href="/questions/tagged/expo" class="post-tag" title="show questions tagged &#39;expo&#39;" rel="tag">expo</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:47:40Z" class="relativetime">15 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/10709694/omar-diaa"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/JT6lA.jpg?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/10709694/omar-diaa">Omar Diaa</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">50</span><span title="7 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">7</span></span><span class="v-visible-sr">7 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797402">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="5 views">
    5 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797402/sinonjs-not-stubbing-class-method" class="question-hyperlink">Sinonjs not stubbing class method</a></h3>
        <div class="excerpt">
            I want to stub a method that I call like this:
let context = new AuthenticationContext(authAuthorityUrl, true)
context.acquireTokenWithUsernamePassword() 

I defined my stub method like this:
let stub ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-typescript t-sinon">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/typescript" class="post-tag" title="show questions tagged &#39;typescript&#39;" rel="tag">typescript</a> <a href="/questions/tagged/sinon" class="post-tag" title="show questions tagged &#39;sinon&#39;" rel="tag">sinon</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:43:21Z" class="relativetime">20 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/13752975/josh"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/b6f978feb0aabf6909ce33f6f27d1d61?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/13752975/josh">josh</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797292">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>2</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="16 views">
    16 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797292/will-npm-always-install-the-latest-available-version-from-the-specified-range" class="question-hyperlink">Will npm always install the latest available version from the specified range?</a></h3>
        <div class="excerpt">
            Consider I have a package that has lodash as a dependency which is specified using the following semver range: ^3.9.1:

1). Will npm always install the latest available version that is satisfied by ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-npm t-npm-install">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/npm" class="post-tag" title="show questions tagged &#39;npm&#39;" rel="tag">npm</a> <a href="/questions/tagged/npm-install" class="post-tag" title="show questions tagged &#39;npm-install&#39;" rel="tag">npm-install</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:37:18Z" class="relativetime">26 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/1056679/slava-fomin-ii"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/bb906e4ebc05732cd74ff47671e6667c?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/1056679/slava-fomin-ii">Slava Fomin II</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score 17,948" dir="ltr">17.9k</span><span title="16 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">16</span></span><span class="v-visible-sr">16 gold badges</span><span title="86 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">86</span></span><span class="v-visible-sr">86 silver badges</span><span title="158 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">158</span></span><span class="v-visible-sr">158 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797288">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>1</strong></span>
                    <div class="viewcount">vote</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="7 views">
    7 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797288/difficulty-updating-an-existing-subdocuments-array-element-with-mongoose-using" class="question-hyperlink">Difficulty updating an existing subdocument&#39;s array element with Mongoose using &#39;set&#39;?</a></h3>
        <div class="excerpt">
            I am not able to save &amp; update a Mongoose subdocument's array element using the set function.
Brief
I use a front end HTML form that creates a request eventually calling this controller in my Node ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-express t-mongoose t-model-view-controller">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/express" class="post-tag" title="show questions tagged &#39;express&#39;" rel="tag">express</a> <a href="/questions/tagged/mongoose" class="post-tag" title="show questions tagged &#39;mongoose&#39;" rel="tag">mongoose</a> <a href="/questions/tagged/model-view-controller" class="post-tag" title="show questions tagged &#39;model-view-controller&#39;" rel="tag">model-view-controller</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:36:56Z" class="relativetime">26 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/1654382/codeblack"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/tCUZz.jpg?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/1654382/codeblack">CODEBLACK</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1,157</span><span title="11 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">11</span></span><span class="v-visible-sr">11 silver badges</span><span title="21 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">21</span></span><span class="v-visible-sr">21 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797241">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="9 views">
    9 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797241/get-datetime6-value-from-database-with-whole-percision" class="question-hyperlink">Get datetime(6) value from database with whole percision</a></h3>
        <div class="excerpt">
            I have a column createdAt in MySQL 5.7 of type datetime(6) and its default value is CURRENT_TIMESTAMP(6).
This is achieved through NestJS and TypeOrm. I am using CreateDateColumn like this
@Entity('...
        </div>
        <div class="tags t-mysql t-nodeûjs t-nestjs t-typeorm">
            <a href="/questions/tagged/mysql" class="post-tag" title="show questions tagged &#39;mysql&#39;" rel="tag">mysql</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/nestjs" class="post-tag" title="show questions tagged &#39;nestjs&#39;" rel="tag">nestjs</a> <a href="/questions/tagged/typeorm" class="post-tag" title="show questions tagged &#39;typeorm&#39;" rel="tag">typeorm</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:34:46Z" class="relativetime">28 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/1413903/golobich"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/9ZUsJ.jpg?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/1413903/golobich">golobich</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1,178</span><span title="2 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 gold badges</span><span title="11 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">11</span></span><span class="v-visible-sr">11 silver badges</span><span title="28 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">28</span></span><span class="v-visible-sr">28 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797150">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="3 views">
    3 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797150/retrieve-text-in-namedrange-with-google-docs-api" class="question-hyperlink">Retrieve text in namedRange with Google Docs API</a></h3>
        <div class="excerpt">
            Using the Google Docs/Drive APIs with Node, I've successfully made a service which produces 'template' style documents which feature namedRanges for other users to write into. I'd like to use the ...
        </div>
        <div class="tags t-nodeûjs t-google-docs-api t-named-ranges">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/google-docs-api" class="post-tag" title="show questions tagged &#39;google-docs-api&#39;" rel="tag">google-docs-api</a> <a href="/questions/tagged/named-ranges" class="post-tag" title="show questions tagged &#39;named-ranges&#39;" rel="tag">named-ranges</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:30:36Z" class="relativetime">32 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/1377099/gs-dan"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/6f3d3f745ca8f49cb9e3813a7000dc0a?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/1377099/gs-dan">GS_Dan</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">77</span><span title="2 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 silver badges</span><span title="7 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">7</span></span><span class="v-visible-sr">7 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797117">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="4 views">
    4 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797117/how-to-pass-config-variables-to-less-in-next-js" class="question-hyperlink">How to pass config variables to .less in Next.js?</a></h3>
        <div class="excerpt">
            In development mode I pass config variables with process.config to .less files.
// next.config.js

var config = require('config');
const withLess = require('@zeit/next-less')
const withCss = require('@...
        </div>
        <div class="tags t-javascript t-css t-nodeûjs t-less t-nextûjs">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/css" class="post-tag" title="show questions tagged &#39;css&#39;" rel="tag">css</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/less" class="post-tag" title="show questions tagged &#39;less&#39;" rel="tag">less</a> <a href="/questions/tagged/next.js" class="post-tag" title="show questions tagged &#39;next.js&#39;" rel="tag">next.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:29:34Z" class="relativetime">33 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/8104084/aliaga-aliyev"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/pGE5G.jpg?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/8104084/aliaga-aliyev">Aliaga Aliyev</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">318</span><span title="4 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">4</span></span><span class="v-visible-sr">4 silver badges</span><span title="18 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">18</span></span><span class="v-visible-sr">18 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62797096">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="6 views">
    6 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62797096/how-to-make-prettier-work-with-yarn-2-berry" class="question-hyperlink">How to make Prettier work with Yarn 2 (berry)</a></h3>
        <div class="excerpt">
            I've added
.pnp.js
.yarn/

to my .prettierignore. .pnp.js is in fact ignored, however some files inside .yarn/ will still be formatted. I think the reason is some directories inside .yarn/ contain ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-yarn t-prettier">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/yarn" class="post-tag" title="show questions tagged &#39;yarn&#39;" rel="tag">yarn</a> <a href="/questions/tagged/prettier" class="post-tag" title="show questions tagged &#39;prettier&#39;" rel="tag">prettier</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:28:40Z" class="relativetime">34 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/7122582/gieted"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/FFKSQ.png?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/7122582/gieted">Gieted</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">194</span><span title="13 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">13</span></span><span class="v-visible-sr">13 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796961">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="5 views">
    5 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796961/aws-sam-fails-to-build-layer" class="question-hyperlink">AWS SAM fails to build layer</a></h3>
        <div class="excerpt">
            I have read that SAM now supports building layers and followed the directions mentioned here. However, i am getting a build error when i try to build the layer locally with sam build samDeployLayer
...
        </div>
        <div class="tags t-nodeûjs t-amazon-web-services t-aws-lambda t-yaml t-aws-sam">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/amazon-web-services" class="post-tag" title="show questions tagged &#39;amazon-web-services&#39;" rel="tag">amazon-web-services</a> <a href="/questions/tagged/aws-lambda" class="post-tag" title="show questions tagged &#39;aws-lambda&#39;" rel="tag">aws-lambda</a> <a href="/questions/tagged/yaml" class="post-tag" title="show questions tagged &#39;yaml&#39;" rel="tag">yaml</a> <a href="/questions/tagged/aws-sam" class="post-tag" title="show questions tagged &#39;aws-sam&#39;" rel="tag">aws-sam</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:20:47Z" class="relativetime">42 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/4409490/akurudi"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/40e94b001fb08208a8eae80327a4ed8e?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/4409490/akurudi">akurudi</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">25</span><span title="4 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">4</span></span><span class="v-visible-sr">4 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796903">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="7 views">
    7 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796903/im-trying-to-implement-a-credit-and-background-checking-system-i-have-tried-tw" class="question-hyperlink">Im trying to implement a credit and background checking system , I have tried two apis but nothing works</a></h3>
        <div class="excerpt">
            as the title says , im working on a project with react native as front end and nodejs in backend . One of the core features of the app is credit and background checking . Ive tried experian and ...
        </div>
        <div class="tags t-nodeûjs t-react-native">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/react-native" class="post-tag" title="show questions tagged &#39;react-native&#39;" rel="tag">react-native</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:17:22Z" class="relativetime">46 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/13892409/imran-hossain"><div class="gravatar-wrapper-32"><img src="https://lh5.googleusercontent.com/-rEuOxgoqywg/AAAAAAAAAAI/AAAAAAAAAAA/AMZuucnw8zf1WDmHO-6rKKqpR-o7oRxrzQ/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/13892409/imran-hossain">Imran Hossain</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796876">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>1</strong></span>
                    <div class="viewcount">vote</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="22 views">
    22 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796876/how-can-i-replace-all-with-a-variable-in-node-js" class="question-hyperlink">How can I replace all with a variable in node.js?</a></h3>
        <div class="excerpt">
            I was making a filter for my Discord.js bot. If the character is not in the English alphabet, it should be removed so the filter can check if a word in the string is filtered.
const alphabet = [&quot;...
        </div>
        <div class="tags t-nodeûjs t-discordûjs">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/discord.js" class="post-tag" title="show questions tagged &#39;discord.js&#39;" rel="tag">discord.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:16:07Z" class="relativetime">47 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/13133576/hgg"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/6eaec0355e79c1a7e0aac7a27acae60d?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/13133576/hgg">HGG</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">13</span><span title="4 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">4</span></span><span class="v-visible-sr">4 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796857">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="12 views">
    12 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796857/node-js-not-outputting-logfile-when-using-screen" class="question-hyperlink">node.js not outputting logfile when using screen</a></h3>
        <div class="excerpt">
            Running this command to start my script (running on my Raspberry Pi), a logfile is created and being updated properly.
sudo node index.js &gt; log.log 2&gt; error.log

However, when trying to run node ...
        </div>
        <div class="tags t-nodeûjs t-raspberry-pi">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/raspberry-pi" class="post-tag" title="show questions tagged &#39;raspberry-pi&#39;" rel="tag">raspberry-pi</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:15:09Z" class="relativetime">48 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/13892400/jeroen"><div class="gravatar-wrapper-32"><img src="https://lh6.googleusercontent.com/-Eu6MCNr09nA/AAAAAAAAAAI/AAAAAAAAAAA/AMZuucnfKd7lVyGTy0ewEMGK1q3dLC8ejQ/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/13892400/jeroen">Jeroen</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796754">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>-1</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="13 views">
    13 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796754/socket-io-node-js-error-during-handshake-error-code-500" class="question-hyperlink">Socket.io + node JS = Error during handshake: error code 500</a></h3>
        <div class="excerpt">
            I was working on Socket.io and node jS to develop a chat web app. It worked locally but I have faced many issues when I deployed my changes to Azure app service.
I am creating a secure connection on ...
        </div>
        <div class="tags t-nodeûjs t-reactjs t-azure t-socketûio t-azure-devops">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/reactjs" class="post-tag" title="show questions tagged &#39;reactjs&#39;" rel="tag">reactjs</a> <a href="/questions/tagged/azure" class="post-tag" title="show questions tagged &#39;azure&#39;" rel="tag">azure</a> <a href="/questions/tagged/socket.io" class="post-tag" title="show questions tagged &#39;socket.io&#39;" rel="tag">socket.io</a> <a href="/questions/tagged/azure-devops" class="post-tag" title="show questions tagged &#39;azure-devops&#39;" rel="tag">azure-devops</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:09:40Z" class="relativetime">53 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/9532883/danish-sarwar"><div class="gravatar-wrapper-32"><img src="https://graph.facebook.com/1312912702134751/picture?type=large" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/9532883/danish-sarwar">Danish Sarwar</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">137</span><span title="1 silver badge" aria-hidden="true"><span class="badge2"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 silver badge</span><span title="6 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">6</span></span><span class="v-visible-sr">6 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796733">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="18 views">
    18 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796733/nodejs-save-values-of-an-async-function-in-an-array" class="question-hyperlink">Nodejs: Save values of an async function in an array [duplicate]</a></h3>
        <div class="excerpt">
            I want to read all JSON files in a directory and add the content to an array.
const fs = require('fs');

function read(path){
    var array = [];
    fs.readdir(path, (err, files) =&gt; {
        if(...
        </div>
        <div class="tags t-javascript t-nodeûjs t-es6-promise">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/es6-promise" class="post-tag" title="show questions tagged &#39;es6-promise&#39;" rel="tag">es6-promise</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:08:54Z" class="relativetime">54 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/6568823/dun"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/7a3086608a11de50296503bf85c86c78?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/6568823/dun">dun</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">333</span><span title="1 gold badge" aria-hidden="true"><span class="badge1"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 gold badge</span><span title="2 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 silver badges</span><span title="11 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">11</span></span><span class="v-visible-sr">11 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796715">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="7 views">
    7 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796715/why-does-the-ini-file-want-different-paths-when-debugging-and-different-paths-wh" class="question-hyperlink">Why does the ini file want different paths when debugging and different paths when running? Node Js</a></h3>
        <div class="excerpt">
            when i debug while reading the ini file path: (./ config) successfully sees the path but when i run
throws the error;Error: ENOENT: no such file or directory, open './config.ini'.It works when I ...
        </div>
        <div class="tags t-nodeûjs t-ini">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/ini" class="post-tag" title="show questions tagged &#39;ini&#39;" rel="tag">ini</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:07:50Z" class="relativetime">55 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/12516431/safa-aytan"><div class="gravatar-wrapper-32"><img src="https://lh3.googleusercontent.com/a-/AAuE7mDFBEXJSUmERTtHeoVL-53JgOSZesb8xyFS5gzSzA=k-s32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/12516431/safa-aytan">safa aytan</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">51</span><span title="5 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">5</span></span><span class="v-visible-sr">5 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796658">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="19 views">
    19 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796658/cannot-access-property-of-req-user-without-iterating" class="question-hyperlink">Cannot access property of req.user without iterating</a></h3>
        <div class="excerpt">
            I'm havig trouble understanding how to access the properties of a global variable that is set in the middleware of my application
// app.js
app.use(function (req, res, next) {
  res.locals.user = req....
        </div>
        <div class="tags t-javascript t-nodeûjs t-mongodb t-express t-handlebarsûjs">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/mongodb" class="post-tag" title="show questions tagged &#39;mongodb&#39;" rel="tag">mongodb</a> <a href="/questions/tagged/express" class="post-tag" title="show questions tagged &#39;express&#39;" rel="tag">express</a> <a href="/questions/tagged/handlebars.js" class="post-tag" title="show questions tagged &#39;handlebars.js&#39;" rel="tag">handlebars.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:05:35Z" class="relativetime">57 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/11794977/onetap"><div class="gravatar-wrapper-32"><img src="https://lh4.googleusercontent.com/-WJD-Lkj4svE/AAAAAAAAAAI/AAAAAAAAAAA/ACHi3rfBK9xK2sUBc6LI-vp3q9tZ9YhavQ/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/11794977/onetap">onetap</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">85</span><span title="1 silver badge" aria-hidden="true"><span class="badge2"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 silver badge</span><span title="6 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">6</span></span><span class="v-visible-sr">6 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796640">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="14 views">
    14 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796640/response-does-not-return-mongoose" class="question-hyperlink">response does not return mongoose</a></h3>
        <div class="excerpt">
            It does not return anything back (hang state) and i see in console
{ _id: 5f05d1527de7984a2c998385, name: 'alexa', age: 12 }. I tried both method promise and callback but still same. Can you guess ...
        </div>
        <div class="tags t-nodeûjs t-mongodb t-mongoose">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/mongodb" class="post-tag" title="show questions tagged &#39;mongodb&#39;" rel="tag">mongodb</a> <a href="/questions/tagged/mongoose" class="post-tag" title="show questions tagged &#39;mongoose&#39;" rel="tag">mongoose</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 14:04:52Z" class="relativetime">58 mins ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/10842900/indraraj26"><div class="gravatar-wrapper-32"><img src="https://lh5.googleusercontent.com/-pIXYAAxqxNE/AAAAAAAAAAI/AAAAAAAAAAA/AKxrwcYQw9xLYysoRAl0oh2eZh79YeNrXA/mo/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/10842900/indraraj26">Indraraj26</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">205</span><span title="2 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 silver badges</span><span title="14 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">14</span></span><span class="v-visible-sr">14 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796434">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="6 views">
    6 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796434/how-to-use-r-portable-with-electron" class="question-hyperlink">How to use R Portable with Electron?</a></h3>
        <div class="excerpt">
            I'm trying to create an Electron app that runs R within itself. Eventually I would like to create an app that once installed has the program with R in it.
        </div>
        <div class="tags t-r t-nodeûjs t-electron">
            <a href="/questions/tagged/r" class="post-tag" title="show questions tagged &#39;r&#39;" rel="tag">r</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/electron" class="post-tag" title="show questions tagged &#39;electron&#39;" rel="tag">electron</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:54:28Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/13874036/typer-writer"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/6917b8692f58215238ce7debf3269b9f?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/13874036/typer-writer">Typer Writer</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">33</span><span title="5 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">5</span></span><span class="v-visible-sr">5 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796391">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="7 views">
    7 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796391/how-to-get-image-stream-with-out-saving-image-using-gm-module-to-post-the-stream" class="question-hyperlink">How to get image stream with out saving image using gm module to post the stream data to the another server</a></h3>
        <div class="excerpt">
            I'm trying to get stream of a crop image to send to another service(API) that accepts only stream in post. But, i'm unable to get the stream from gm module. I tried following
gm(main.png')
            ...
        </div>
        <div class="tags t-nodeûjs">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:52:21Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/8007415/pavan-karumuri"><div class="gravatar-wrapper-32"><img src="https://lh6.googleusercontent.com/-7sakkqyel3s/AAAAAAAAAAI/AAAAAAAAD3o/W5J4zRqhJRs/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/8007415/pavan-karumuri">Pavan Karumuri</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">27</span><span title="5 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">5</span></span><span class="v-visible-sr">5 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796376">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="7 views">
    7 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796376/how-to-save-and-read-binary-image-data-from-amazon-s3" class="question-hyperlink">How to save and read Binary Image data from amazon s3?</a></h3>
        <div class="excerpt">
            using node js my proejct needs to save images to aws s3 in BLOB format and retrive it show in browser as well. I am able save the the image in BLOB format but when I try to load it on browser its not ...
        </div>
        <div class="tags t-nodeûjs t-amazon-s3 t-blob">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/amazon-s3" class="post-tag" title="show questions tagged &#39;amazon-s3&#39;" rel="tag">amazon-s3</a> <a href="/questions/tagged/blob" class="post-tag" title="show questions tagged &#39;blob&#39;" rel="tag">blob</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:51:45Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/966787/navinraj-pandey"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/XOTCi.jpg?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/966787/navinraj-pandey">NavinRaj Pandey</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1,508</span><span title="2 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 gold badges</span><span title="20 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">20</span></span><span class="v-visible-sr">20 silver badges</span><span title="34 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">34</span></span><span class="v-visible-sr">34 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796205">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="7 views">
    7 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796205/integrate-json-file-content-into-sqlite-in-node-js" class="question-hyperlink">Integrate Json file content into Sqlite in node js</a></h3>
        <div class="excerpt">
            I would like to insert my Json content into my Sqlite3 database with node is, but I'm beginner and I don't know how can do this, so can someone help me Please. For the moment I have this code :
    ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-json t-sqlite t-insert">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/json" class="post-tag" title="show questions tagged &#39;json&#39;" rel="tag">json</a> <a href="/questions/tagged/sqlite" class="post-tag" title="show questions tagged &#39;sqlite&#39;" rel="tag">sqlite</a> <a href="/questions/tagged/insert" class="post-tag" title="show questions tagged &#39;insert&#39;" rel="tag">insert</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:42:50Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/11433276/barys"><div class="gravatar-wrapper-32"><img src="https://lh4.googleusercontent.com/-U-GSUPOfmko/AAAAAAAAAAI/AAAAAAAAAJw/jqheLQGUKVQ/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/11433276/barys">Barys</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">9</span><span title="4 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">4</span></span><span class="v-visible-sr">4 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796203">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="8 views">
    8 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796203/how-to-produce-data-through-sequelize" class="question-hyperlink">How to produce data through Sequelize</a></h3>
        <div class="excerpt">
            Hi There i want to ask how to produce data group by certain id and find max value of that id,
For example I have Table Student Quiz
id   student_id    score
1       2           200
2       2           ...
        </div>
        <div class="tags t-nodeûjs t-express t-sequelizeûjs">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/express" class="post-tag" title="show questions tagged &#39;express&#39;" rel="tag">express</a> <a href="/questions/tagged/sequelize.js" class="post-tag" title="show questions tagged &#39;sequelize.js&#39;" rel="tag">sequelize.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:42:43Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/10501457/nelvan-balthazar"><div class="gravatar-wrapper-32"><img src="https://lh3.googleusercontent.com/-3WP9hVU783A/AAAAAAAAAAI/AAAAAAAAHhg/hOr8a-dJcGQ/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/10501457/nelvan-balthazar">Nelvan Balthazar</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">53</span><span title="6 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">6</span></span><span class="v-visible-sr">6 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796053">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="14 views">
    14 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796053/azure-function-api-giving-slow-response" class="question-hyperlink">Azure function API giving slow response</a></h3>
        <div class="excerpt">
            I am new to the Azure platform. I have written multiple functions in node js.
I am facing an issue for the slow function response from the function to get or add data. Sometimes it works fine.
Please ...
        </div>
        <div class="tags t-nodeûjs t-azure t-performance t-azure-functions">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/azure" class="post-tag" title="show questions tagged &#39;azure&#39;" rel="tag">azure</a> <a href="/questions/tagged/performance" class="post-tag" title="show questions tagged &#39;performance&#39;" rel="tag">performance</a> <a href="/questions/tagged/azure-functions" class="post-tag" title="show questions tagged &#39;azure-functions&#39;" rel="tag">azure-functions</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:34:05Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/1776512/pratik"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/e2f99d31e6607130c3c83b4147a3a45f?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/1776512/pratik">pratik</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">77</span><span title="2 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 silver badges</span><span title="11 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">11</span></span><span class="v-visible-sr">11 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796027">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="14 views">
    14 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796027/why-is-npm-install-never-finishing" class="question-hyperlink">Why is `npm install` never finishing?</a></h3>
        <div class="excerpt">
            Environment:
Digital Ocean droplet (Ubuntu 18.04)
node (v14.5.0)
npm (v6.14.5)
Installed with nvm (v0.35.3)
I've set up 3 server blocks with nginx for development, staging, and production of the same ...
        </div>
        <div class="tags t-nodeûjs t-npm t-npm-install">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/npm" class="post-tag" title="show questions tagged &#39;npm&#39;" rel="tag">npm</a> <a href="/questions/tagged/npm-install" class="post-tag" title="show questions tagged &#39;npm-install&#39;" rel="tag">npm-install</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:32:48Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/4777848/cweber105"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/8RjBV.jpg?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/4777848/cweber105">cweber105</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">416</span><span title="4 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">4</span></span><span class="v-visible-sr">4 silver badges</span><span title="16 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">16</span></span><span class="v-visible-sr">16 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62796024">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="12 views">
    12 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62796024/how-to-run-a-python-script-as-a-background-process-in-nodejs-that-doesnt-close" class="question-hyperlink">How to run a Python script as a background process in NodeJS that doesn&#39;t close?</a></h3>
        <div class="excerpt">
            I have a python script which receives data from NodeJS, uses it to gather data and then sends this data back to the NodeJS server any time a request is made.
The problem is that a part of this python ...
        </div>
        <div class="tags t-python t-nodeûjs">
            <a href="/questions/tagged/python" class="post-tag" title="show questions tagged &#39;python&#39;" rel="tag">python</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:32:45Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/6255419/max-kenney"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/60e54d8852b6c6213b740a6a60d5227e?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/6255419/max-kenney">Max Kenney</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">23</span><span title="5 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">5</span></span><span class="v-visible-sr">5 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62795932">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="22 views">
    22 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62795932/saving-object-to-json-file-than-using-it-back-in-function-after-reading" class="question-hyperlink">Saving object to JSON file than using it back in function after reading</a></h3>
        <div class="excerpt">
            I am completly new to node.js but have to use it in my student project that require this library: https://github.com/bitchan/eccrypto.
The goal is to encrypt file using ethereum public key, save it as ...
        </div>
        <div class="tags t-nodeûjs t-json t-parsing t-encryption t-ethereum">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/json" class="post-tag" title="show questions tagged &#39;json&#39;" rel="tag">json</a> <a href="/questions/tagged/parsing" class="post-tag" title="show questions tagged &#39;parsing&#39;" rel="tag">parsing</a> <a href="/questions/tagged/encryption" class="post-tag" title="show questions tagged &#39;encryption&#39;" rel="tag">encryption</a> <a href="/questions/tagged/ethereum" class="post-tag" title="show questions tagged &#39;ethereum&#39;" rel="tag">ethereum</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:28:44Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/13892008/agiwar"><div class="gravatar-wrapper-32"><img src="https://lh3.googleusercontent.com/-b-LrCWLXFNA/AAAAAAAAAAI/AAAAAAAAAAA/AMZuuclNGQsgUHzcufLO6zH-N_1SLv6RIQ/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/13892008/agiwar">Agiwar</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62795827">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="14 views">
    14 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62795827/cast-to-objectid-failed-for-value-some-id-at-path-id-for-model-category" class="question-hyperlink">Cast to ObjectId failed for value &ldquo;some_id&rdquo; at path &ldquo;_id&rdquo; for model &ldquo;Category&rdquo;</a></h3>
        <div class="excerpt">
            when I use findOne from mongoose version 5.9.12, I got some error like this :
error
https://i.stack.imgur.com/8kAcY.png
my code:
[code][2]
https://i.stack.imgur.com/v8Prd.png
my models:
models
        </div>
        <div class="tags t-nodeûjs t-mongodb t-express t-mongoose">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/mongodb" class="post-tag" title="show questions tagged &#39;mongodb&#39;" rel="tag">mongodb</a> <a href="/questions/tagged/express" class="post-tag" title="show questions tagged &#39;express&#39;" rel="tag">express</a> <a href="/questions/tagged/mongoose" class="post-tag" title="show questions tagged &#39;mongoose&#39;" rel="tag">mongoose</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:23:54Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/12205608/fathurrahman"><div class="gravatar-wrapper-32"><img src="https://lh4.googleusercontent.com/-nAD5fR6dBLk/AAAAAAAAAAI/AAAAAAAAAAA/ACHi3rfomudiBYYB9zZ2OHuz9zH2CrIhEw/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/12205608/fathurrahman">Fathurrahman</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">3</span><span title="3 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">3</span></span><span class="v-visible-sr">3 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62795579">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>1</strong></span>
                    <div class="viewcount">vote</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="26 views">
    26 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62795579/multi-tier-architecture-angular-node-js-and-mysql" class="question-hyperlink">Multi-tier architecture: Angular, Node.js and MySQL</a></h3>
        <div class="excerpt">
            I'm using angular7, Node.js and mySQLto create a platform, each one of them runs on a seperate port and I'm only using HTTP protocol , I'm really confused if it's a 3 tier architecture (client, web ...
        </div>
        <div class="tags t-mysql t-nodeûjs t-angular t-architecture t-multi-tier">
            <a href="/questions/tagged/mysql" class="post-tag" title="show questions tagged &#39;mysql&#39;" rel="tag">mysql</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/angular" class="post-tag" title="show questions tagged &#39;angular&#39;" rel="tag">angular</a> <a href="/questions/tagged/architecture" class="post-tag" title="show questions tagged &#39;architecture&#39;" rel="tag">architecture</a> <a href="/questions/tagged/multi-tier" class="post-tag" title="show questions tagged &#39;multi-tier&#39;" rel="tag">multi-tier</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:09:50Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/10851944/computer-tricks"><div class="gravatar-wrapper-32"><img src="https://lh6.googleusercontent.com/-qrxJC-VA3Pg/AAAAAAAAAAI/AAAAAAAAAEk/1L3kTX2PE_Y/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/10851944/computer-tricks">computer tricks</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">254</span><span title="2 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 silver badges</span><span title="9 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">9</span></span><span class="v-visible-sr">9 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62795540">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="17 views">
    17 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62795540/monkey-patch-the-node-js-winston-logging" class="question-hyperlink">Monkey patch the node js winston logging</a></h3>
        <div class="excerpt">
            do you have an idea on how to monkey patch the node js winston logging methods like info, debug by using shimmer(https://www.npmjs.com/package/shimmer) ?
For example,
This is my winston 3.x setup:
let ...
        </div>
        <div class="tags t-nodeûjs t-winston t-shimmer">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/winston" class="post-tag" title="show questions tagged &#39;winston&#39;" rel="tag">winston</a> <a href="/questions/tagged/shimmer" class="post-tag" title="show questions tagged &#39;shimmer&#39;" rel="tag">shimmer</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 13:07:40Z" class="relativetime">1 hour ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/534600/arman-ortega"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/1cd9c8984f2fdeb996130d54d62a98d9?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/534600/arman-ortega">Arman Ortega</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1,665</span><span title="20 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">20</span></span><span class="v-visible-sr">20 silver badges</span><span title="23 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">23</span></span><span class="v-visible-sr">23 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62795391">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="19 views">
    19 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62795391/python-not-returning-value-to-node" class="question-hyperlink">python not returning value to node</a></h3>
        <div class="excerpt">
            node server code
let { PythonShell } = require(&quot;python-shell&quot;);

let options = {
    mode: 'text',
    pythonPath: 'C:\\Python27\\ArcGIS10.6\\python.exe',
    pythonOptions: ['-u'], 
    ...
        </div>
        <div class="tags t-python t-nodeûjs t-python-2û7">
            <a href="/questions/tagged/python" class="post-tag" title="show questions tagged &#39;python&#39;" rel="tag">python</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/python-2.7" class="post-tag" title="show questions tagged &#39;python-2.7&#39;" rel="tag">python-2.7</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:59:19Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/6436372/lord-corwin"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/e45bafcbab5d00cf423c91e0d6d50dfc?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/6436372/lord-corwin">Lord Corwin</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">19</span><span title="7 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">7</span></span><span class="v-visible-sr">7 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62795376">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>1</strong></span>
                    <div class="viewcount">vote</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="33 views">
    33 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62795376/asynchronous-code-in-node-avoid-redundant-usage-of-async-await" class="question-hyperlink">Asynchronous code in node - avoid redundant usage of async / await</a></h3>
        <div class="excerpt">
            I have a question about the usage of async / await in a Node.js project wrote in typescript.
We have a chain of functions all with async and await. And my question is:
Could we avoid all these async / ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-asynchronous t-async-await">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/asynchronous" class="post-tag" title="show questions tagged &#39;asynchronous&#39;" rel="tag">asynchronous</a> <a href="/questions/tagged/async-await" class="post-tag" title="show questions tagged &#39;async-await&#39;" rel="tag">async-await</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:58:45Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/4594263/belen"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/rEQWq.png?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/4594263/belen">Belen</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">171</span><span title="1 silver badge" aria-hidden="true"><span class="badge2"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 silver badge</span><span title="17 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">17</span></span><span class="v-visible-sr">17 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62795334">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>1</strong></span>
                    <div class="viewcount">vote</div>
                </div>
            </div>
            <div class="status answered">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="18 views">
    18 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62795334/how-to-stop-a-node-js-server-from-user" class="question-hyperlink">How to stop a node js server from user</a></h3>
        <div class="excerpt">
            My flask server starts at port 5000 and from there another node js server starts from port 3000 and opens a new window. I want when the users clsoes the node js window, it should stop node js server ...
        </div>
        <div class="tags t-nodeûjs t-flask t-server">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/flask" class="post-tag" title="show questions tagged &#39;flask&#39;" rel="tag">flask</a> <a href="/questions/tagged/server" class="post-tag" title="show questions tagged &#39;server&#39;" rel="tag">server</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:56:33Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/7146542/t2020"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/c139d122b1d9474f927b843714444f45?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/7146542/t2020">T2020</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">11</span><span title="2 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62795299">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>1</strong></span>
                    <div class="viewcount">vote</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="15 views">
    15 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62795299/join-multiple-rooms-at-once-socket-io" class="question-hyperlink">Join multiple rooms at once Socket.io</a></h3>
        <div class="excerpt">
            I have an application where a user can get a list of chat rooms they are in, they can then click into any specific chat room they want. Currently the socket joins the room when the user clicks into a ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-sockets t-socketûio">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/sockets" class="post-tag" title="show questions tagged &#39;sockets&#39;" rel="tag">sockets</a> <a href="/questions/tagged/socket.io" class="post-tag" title="show questions tagged &#39;socket.io&#39;" rel="tag">socket.io</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:53:49Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/12528168/conor"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/7765adc6a75e54296b07554c14568ede?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/12528168/conor">Conor</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">13</span><span title="3 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">3</span></span><span class="v-visible-sr">3 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62795210">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>1</strong></span>
                    <div class="viewcount">vote</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="3 views">
    3 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62795210/error-sequelizeeagerloadingerror-query-and-models" class="question-hyperlink">Error SequelizeEagerLoadingError query and models</a></h3>
        <div class="excerpt">
            I would like to execute this query sql :
SELECT u.name_user, u.firstname_user, u.email_user, u.school_user, j.date_joueur, j.infos_joueur, j.id_joueur, u.id_user FROM joueurs AS j, users AS u WHERE j....
        </div>
        <div class="tags t-nodeûjs t-model t-sequelizeûjs">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/model" class="post-tag" title="show questions tagged &#39;model&#39;" rel="tag">model</a> <a href="/questions/tagged/sequelize.js" class="post-tag" title="show questions tagged &#39;sequelize.js&#39;" rel="tag">sequelize.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:49:07Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/13891853/iphono-yid"><div class="gravatar-wrapper-32"><img src="https://lh3.googleusercontent.com/a-/AOh14GiFbPOLAwEOYv0UjZTFXPlkKVqx7vrMpVfjn-DN8w=k-s32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/13891853/iphono-yid">iPhono YiD</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">11</span><span title="1 bronze badge" aria-hidden="true"><span class="badge3"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 bronze badge</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62794981">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="9 views">
    9 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62794981/google-app-engine-google-app-engine-spamming-logs-for-connection-refused-to-re" class="question-hyperlink">Google App Engine : Google App Engine spamming logs for connection refused to Redis, but it&#39;s working</a></h3>
        <div class="excerpt">
            I am working on deploying my NodeJS app on Google App Engine. App is working good, and I have created a redis instance, which is added as ENV parameter. It's working fine, but somehow Gooogle App ...
        </div>
        <div class="tags t-nodeûjs t-google-app-engine t-redis t-gcloud">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/google-app-engine" class="post-tag" title="show questions tagged &#39;google-app-engine&#39;" rel="tag">google-app-engine</a> <a href="/questions/tagged/redis" class="post-tag" title="show questions tagged &#39;redis&#39;" rel="tag">redis</a> <a href="/questions/tagged/gcloud" class="post-tag" title="show questions tagged &#39;gcloud&#39;" rel="tag">gcloud</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:37:00Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/1510701/we-are-borg"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/jsK9w.gif?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/1510701/we-are-borg">We are Borg</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">4,314</span><span title="10 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">10</span></span><span class="v-visible-sr">10 gold badges</span><span title="71 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">71</span></span><span class="v-visible-sr">71 silver badges</span><span title="163 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">163</span></span><span class="v-visible-sr">163 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62794835">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="6 views">
    6 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62794835/can-i-deploy-an-app-that-uses-both-python-and-node-js-on-amazon-elastic-beanstal" class="question-hyperlink">Can I deploy an app that uses both Python and Node.js on Amazon Elastic Beanstalk?</a></h3>
        <div class="excerpt">
            See TL;DR before the question if you wish, but any quick responses are appreciated.

I have a web-app that uses Node.js for the backend and Python for running a particular script.
The app basically ...
        </div>
        <div class="tags t-python t-nodeûjs t-amazon-web-services t-heroku t-amazon-elastic-beanstalk">
            <a href="/questions/tagged/python" class="post-tag" title="show questions tagged &#39;python&#39;" rel="tag">python</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/amazon-web-services" class="post-tag" title="show questions tagged &#39;amazon-web-services&#39;" rel="tag">amazon-web-services</a> <a href="/questions/tagged/heroku" class="post-tag" title="show questions tagged &#39;heroku&#39;" rel="tag">heroku</a> <a href="/questions/tagged/amazon-elastic-beanstalk" class="post-tag" title="show questions tagged &#39;amazon-elastic-beanstalk&#39;" rel="tag">amazon-elastic-beanstalk</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:28:45Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/12172493/abhijit"><div class="gravatar-wrapper-32"><img src="https://lh5.googleusercontent.com/-uKtRzoySlhA/AAAAAAAAAAI/AAAAAAAAABQ/bfVRpVArJdE/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/12172493/abhijit">Abhijit</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">31</span><span title="1 silver badge" aria-hidden="true"><span class="badge2"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 silver badge</span><span title="8 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">8</span></span><span class="v-visible-sr">8 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62794831">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="8 views">
    8 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62794831/upload-multiple-images-to-a-nested-array" class="question-hyperlink">upload multiple images to a nested array</a></h3>
        <div class="excerpt">
            is it possible to implement an image upload in my node api with this library where the response in my POST request looks like this or do I need to check out other libraries:
{
  &quot;name&quot;: &...
        </div>
        <div class="tags t-nodeûjs t-multipartform-data t-busboy t-multiparty">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/multipartform-data" class="post-tag" title="show questions tagged &#39;multipartform-data&#39;" rel="tag">multipartform-data</a> <a href="/questions/tagged/busboy" class="post-tag" title="show questions tagged &#39;busboy&#39;" rel="tag">busboy</a> <a href="/questions/tagged/multiparty" class="post-tag" title="show questions tagged &#39;multiparty&#39;" rel="tag">multiparty</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:28:25Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/13823337/kingarhut"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/bfeaccfd99851ea73aa1e4dde48f2bea?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/13823337/kingarhut">KingArhut</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1</span><span title="1 bronze badge" aria-hidden="true"><span class="badge3"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 bronze badge</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62794690">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="9 views">
    9 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62794690/electron-fs-readdir-callback-sometimes-doesnt-execute-on-reload" class="question-hyperlink">Electron - fs.readdir callback sometimes doesn&#39;t execute on reload</a></h3>
        <div class="excerpt">
            About 30% of the time my electron app does not execute the fs.readdir callback after I've reloaded the window that contains that script. When I open the application with electron ., the issue never ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-electron">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/electron" class="post-tag" title="show questions tagged &#39;electron&#39;" rel="tag">electron</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:21:10Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/8380672/user8380672"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/463868807436004115b401690551c9cc?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/8380672/user8380672">user8380672</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">23</span><span title="2 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 silver badges</span><span title="6 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">6</span></span><span class="v-visible-sr">6 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62794618">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>1</strong></span>
                    <div class="viewcount">vote</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="18 views">
    18 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62794618/showing-first-is-real-value-but-second-shows-undefined-in-my-modal-project" class="question-hyperlink">showing first is real value but second shows undefined in my modal project</a></h3>
        <div class="excerpt">
            my modal code
  &lt;form action=&quot;/update&quot; method=&quot;post&quot;&gt;
      &lt;div class=&quot;modal fade&quot; id=&quot;duzen&quot; tabindex=&quot;-1&quot; role=&quot;dialog&quot; aria-...
        </div>
        <div class="tags t-nodeûjs t-ajax t-bootstrap-modal">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/ajax" class="post-tag" title="show questions tagged &#39;ajax&#39;" rel="tag">ajax</a> <a href="/questions/tagged/bootstrap-modal" class="post-tag" title="show questions tagged &#39;bootstrap-modal&#39;" rel="tag">bootstrap-modal</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:16:38Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/10197727/asuscu"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/f315c667d76ba12b2419b470748b512e?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/10197727/asuscu">asuscu</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">140</span><span title="1 gold badge" aria-hidden="true"><span class="badge1"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 gold badge</span><span title="1 silver badge" aria-hidden="true"><span class="badge2"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 silver badge</span><span title="9 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">9</span></span><span class="v-visible-sr">9 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62794527">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="9 views">
    9 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62794527/nesting-multiple-joinsconsecutive-tables-in-knex" class="question-hyperlink">Nesting multiple joins(consecutive tables) in knex</a></h3>
        <div class="excerpt">
            I'm new to knex and trying to figure out how to implement nested joins in knex. I found something that I want to do in this answer - Create nested json from sql query postgres 9.4
Though I understand ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-postgresql t-knexûjs">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/postgresql" class="post-tag" title="show questions tagged &#39;postgresql&#39;" rel="tag">postgresql</a> <a href="/questions/tagged/knex.js" class="post-tag" title="show questions tagged &#39;knex.js&#39;" rel="tag">knex.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:10:59Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/10677273/parfectshot"><div class="gravatar-wrapper-32"><img src="https://lh3.googleusercontent.com/-dkbGHqYzMw4/AAAAAAAAAAI/AAAAAAAAAAA/AGDgw-gAPocISbUAAYxwHpcDMEX5Fy-xrA/mo/photo.jpg?sz=32" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/10677273/parfectshot">ParfectShot</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">41</span><span title="9 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">9</span></span><span class="v-visible-sr">9 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62794526">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>-2</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views " title="18 views">
    18 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62794526/how-to-include-single-sign-on-using-3rd-party-oauth-server-in-node-red" class="question-hyperlink">how to include single sign on using 3rd party oauth server in Node-RED?</a></h3>
        <div class="excerpt">
            I want to include a 3rd party authentication server in my node red application. The flow should be such that when anyone enters the link, it redirects them to the server, there they will enter ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-oauth-2û0 t-jwt t-node-red">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/oauth-2.0" class="post-tag" title="show questions tagged &#39;oauth-2.0&#39;" rel="tag">oauth-2.0</a> <a href="/questions/tagged/jwt" class="post-tag" title="show questions tagged &#39;jwt&#39;" rel="tag">jwt</a> <a href="/questions/tagged/node-red" class="post-tag" title="show questions tagged &#39;node-red&#39;" rel="tag">node-red</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:10:58Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/13891661/developerforlife"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/b0b733e82bfca37ce586cf019e822fec?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/13891661/developerforlife">developerforLIFE</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62794506">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status unanswered">
                <strong>0</strong>answers
            </div>
        </div>
        <div class="views " title="10 views">
    10 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62794506/how-to-use-typescript-declaration-file-with-mocha-tests" class="question-hyperlink">How to use TypeScript Declaration File with mocha tests?</a></h3>
        <div class="excerpt">
            I have a TypeScript project, where the test are written in TypeScript. I want to use mocha to directly test TS files. I'm using ts-node for that, as described in ts-node#mocha.
In the project I'm ...
        </div>
        <div class="tags t-nodeûjs t-typescript t-mocha t-typescript-typings t-ts-node">
            <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/typescript" class="post-tag" title="show questions tagged &#39;typescript&#39;" rel="tag">typescript</a> <a href="/questions/tagged/mocha" class="post-tag" title="show questions tagged &#39;mocha&#39;" rel="tag">mocha</a> <a href="/questions/tagged/typescript-typings" class="post-tag" title="show questions tagged &#39;typescript-typings&#39;" rel="tag">typescript-typings</a> <a href="/questions/tagged/ts-node" class="post-tag" title="show questions tagged &#39;ts-node&#39;" rel="tag">ts-node</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:09:38Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/297094/robert-zaremba"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/08a7e4ec1109264bc3d18a519d15146c?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/297094/robert-zaremba">Robert Zaremba</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">6,011</span><span title="5 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">5</span></span><span class="v-visible-sr">5 gold badges</span><span title="37 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">37</span></span><span class="v-visible-sr">37 silver badges</span><span title="65 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">65</span></span><span class="v-visible-sr">65 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-62794450">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>0</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>3</strong>answers
            </div>
        </div>
        <div class="views " title="30 views">
    30 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/62794450/variable-scope-in-async-functions" class="question-hyperlink">Variable scope in async functions</a></h3>
        <div class="excerpt">
            I am trying to access a variable that i declared inside in an async function. Like this:
exports.startTheBasketEngine = async (username, password, domainData) =&gt; {
    const parse = domainData....
        </div>
        <div class="tags t-javascript t-nodeûjs">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2020-07-08 12:05:50Z" class="relativetime">2 hours ago</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/1270400/tolgay-toklar"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/32be7e25bc01928144a0846fa067ba8d?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/1270400/tolgay-toklar">Tolgay Toklar</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">3,102</span><span title="5 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">5</span></span><span class="v-visible-sr">5 gold badges</span><span title="28 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">28</span></span><span class="v-visible-sr">28 silver badges</span><span title="50 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">50</span></span><span class="v-visible-sr">50 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div>        </div>

        <br class="cbt" />
<div class="s-pagination page-sizer fr">
  <a href="/questions/tagged/node.js?tab=newest&amp;pagesize=15" title="Show 15 items per page" class="s-pagination--item">15</a>
  <a href="/questions/tagged/node.js?tab=newest&amp;pagesize=30" title="Show 30 items per page" class="s-pagination--item">30</a>
  <a href="/questions/tagged/node.js?tab=newest&amp;pagesize=50" title="Show 50 items per page" class="s-pagination--item is-selected">50</a>
  <span class="s-pagination--item s-pagination--item__clear">per page</span>
</div>
<div class="s-pagination pager fl">
<div class="s-pagination--item is-selected">1</div>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/node.js?tab=newest&page=2&pagesize=50" rel="" title="Go to page 2">2</a>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/node.js?tab=newest&page=3&pagesize=50" rel="" title="Go to page 3">3</a>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/node.js?tab=newest&page=4&pagesize=50" rel="" title="Go to page 4">4</a>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/node.js?tab=newest&page=5&pagesize=50" rel="" title="Go to page 5">5</a>
<div class="s-pagination--item s-pagination--item__clear">…</div>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/node.js?tab=newest&page=6763&pagesize=50" rel="" title="Go to page 6763">6763</a>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/node.js?tab=newest&page=2&pagesize=50" rel="next" title="Go to page 2"> Next</a></div>
    </div>
    <div id="sidebar">
        
<div class="s-sidebarwidget s-sidebarwidget__yellow s-anchors s-anchors__grayscale mb16" data-tracker="cb=1">
    <ul class="d-block p0 m0">
                    <div class="s-sidebarwidget--header s-sidebarwidget__small-bold-text fc-light d:fc-black-900 bb bbw1">
                        Upcoming Events
                    </div>
    <li class="s-sidebarwidget--item grid px16">
        <div class="grid--cell1 fl-shrink0">
            <div class="favicon favicon-stackoverflow" title="Stack Overflow"></div>
        </div>
        <div class="grid--cell">
            <a href="https://stackoverflow.com/election" class="fc-danger js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;Upcoming Events&quot;,&quot;https://stackoverflow.com/election&quot;,null,null]"  data-gps-track="communitybulletin.click({ priority: 5, position: 0 })">2020 Community Moderator Election</a>
            <div>ends <span title="2020-07-21 20:00:00Z">Jul 21</span></div>
        </div>
    </li>
                    <div class="s-sidebarwidget--header s-sidebarwidget__small-bold-text fc-light d:fc-black-900 bb bbw1">
                        Featured on Meta
                    </div>
        <li class="s-sidebarwidget--item grid px16">
            <div class="grid--cell1 fl-shrink0">
<div class="favicon favicon-stackexchangemeta" title="Meta Stack Exchange"></div>            </div>
            <div class="grid--cell">
                <a href="https://meta.stackexchange.com/questions/349276/new-post-lock-available-on-meta-sites-policy-lock" class="js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;Featured on Meta&quot;,&quot;https://meta.stackexchange.com/questions/349276/new-post-lock-available-on-meta-sites-policy-lock&quot;,null,null]" data-gps-track="communitybulletin.click({ priority: 3, position: 1 })">New post lock available on meta sites: Policy Lock</a>
            </div>
        </li>
        <li class="s-sidebarwidget--item grid px16">
            <div class="grid--cell1 fl-shrink0">
<div class="favicon favicon-stackexchangemeta" title="Meta Stack Exchange"></div>            </div>
            <div class="grid--cell">
                <a href="https://meta.stackexchange.com/questions/350184/feedback-post-new-moderator-reinstatement-and-appeal-process-revisions" class="js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;Featured on Meta&quot;,&quot;https://meta.stackexchange.com/questions/350184/feedback-post-new-moderator-reinstatement-and-appeal-process-revisions&quot;,null,null]" data-gps-track="communitybulletin.click({ priority: 3, position: 2 })">Feedback post: New moderator reinstatement and appeal process revisions</a>
            </div>
        </li>
        <li class="s-sidebarwidget--item grid px16">
            <div class="grid--cell1 fl-shrink0">
<div class="favicon favicon-stackoverflowmeta" title="Meta Stack Overflow"></div>            </div>
            <div class="grid--cell">
                <a href="https://meta.stackoverflow.com/questions/398909/data-validation-background-for-the-thank-you-reaction-feature-test" class="js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;Featured on Meta&quot;,&quot;https://meta.stackoverflow.com/questions/398909/data-validation-background-for-the-thank-you-reaction-feature-test&quot;,null,null]" data-gps-track="communitybulletin.click({ priority: 6, position: 3 })">Data validation &amp; background for the Thank You Reaction feature test</a>
            </div>
        </li>
        <li class="s-sidebarwidget--item grid px16">
            <div class="grid--cell1 fl-shrink0">
<div class="favicon favicon-stackoverflowmeta" title="Meta Stack Overflow"></div>            </div>
            <div class="grid--cell">
                <a href="https://meta.stackoverflow.com/questions/399106/2020-community-moderator-election-questionnaire" class="js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;Featured on Meta&quot;,&quot;https://meta.stackoverflow.com/questions/399106/2020-community-moderator-election-questionnaire&quot;,null,null]" data-gps-track="communitybulletin.click({ priority: 6, position: 4 })">2020 Community Moderator Election - Questionnaire</a>
            </div>
        </li>
    </ul>
</div>


<div id="dfp-tsb" class="everyonelovesstackoverflow everyoneloves__top-sidebar mb8"></div>
<div id="dfp-msb" class="everyonelovesstackoverflow everyoneloves__mid-sidebar mb8"></div>
<div id="hireme"></div>            <div class="module js-gps-related-tags">
                <h4 id="h-related-tags">Related Tags</h4>
        <div data-name="javascript">
            <a href="/questions/tagged/node.js+javascript" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js javascript&#39;" rel="tag">javascript</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">124518</span></span>
        </div>
        <div data-name="express">
            <a href="/questions/tagged/node.js+express" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js express&#39;" rel="tag">express</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">55117</span></span>
        </div>
        <div data-name="mongodb">
            <a href="/questions/tagged/node.js+mongodb" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js mongodb&#39;" rel="tag">mongodb</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">36372</span></span>
        </div>
        <div data-name="mongoose">
            <a href="/questions/tagged/node.js+mongoose" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js mongoose&#39;" rel="tag">mongoose</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">23136</span></span>
        </div>
        <div data-name="npm">
            <a href="/questions/tagged/node.js+npm" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js npm&#39;" rel="tag">npm</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">17974</span></span>
        </div>
        <div data-name="reactjs">
            <a href="/questions/tagged/node.js+reactjs" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js reactjs&#39;" rel="tag">reactjs</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">12164</span></span>
        </div>
        <div data-name="socket.io">
            <a href="/questions/tagged/node.js+socket.io" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js socket.io&#39;" rel="tag">socket.io</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">11259</span></span>
        </div>
        <div data-name="angularjs">
            <a href="/questions/tagged/node.js+angularjs" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js angularjs&#39;" rel="tag">angularjs</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">9100</span></span>
        </div>
        <div data-name="json">
            <a href="/questions/tagged/node.js+json" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js json&#39;" rel="tag">json</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">9032</span></span>
        </div>
        <div data-name="mysql">
            <a href="/questions/tagged/node.js+mysql" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js mysql&#39;" rel="tag">mysql</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">8541</span></span>
        </div>
        <div class="dno js-hidden" data-name="typescript">
            <a href="/questions/tagged/node.js+typescript" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js typescript&#39;" rel="tag">typescript</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">7066</span></span>
        </div>
        <div class="dno js-hidden" data-name="angular">
            <a href="/questions/tagged/node.js+angular" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js angular&#39;" rel="tag">angular</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">6978</span></span>
        </div>
        <div class="dno js-hidden" data-name="html">
            <a href="/questions/tagged/node.js+html" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js html&#39;" rel="tag">html</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">6505</span></span>
        </div>
        <div class="dno js-hidden" data-name="asynchronous">
            <a href="/questions/tagged/node.js+asynchronous" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js asynchronous&#39;" rel="tag">asynchronous</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">5938</span></span>
        </div>
        <div class="dno js-hidden" data-name="sequelize.js">
            <a href="/questions/tagged/node.js+sequelize.js" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js sequelize.js&#39;" rel="tag">sequelize.js</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">5621</span></span>
        </div>
        <div class="dno js-hidden" data-name="amazon-web-services">
            <a href="/questions/tagged/node.js+amazon-web-services" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js amazon-web-services&#39;" rel="tag">amazon-web-services</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">5448</span></span>
        </div>
        <div class="dno js-hidden" data-name="promise">
            <a href="/questions/tagged/node.js+promise" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js promise&#39;" rel="tag">promise</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">5351</span></span>
        </div>
        <div class="dno js-hidden" data-name="heroku">
            <a href="/questions/tagged/node.js+heroku" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js heroku&#39;" rel="tag">heroku</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">5290</span></span>
        </div>
        <div class="dno js-hidden" data-name="firebase">
            <a href="/questions/tagged/node.js+firebase" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js firebase&#39;" rel="tag">firebase</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">4694</span></span>
        </div>
        <div class="dno js-hidden" data-name="jquery">
            <a href="/questions/tagged/node.js+jquery" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js jquery&#39;" rel="tag">jquery</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">4633</span></span>
        </div>
        <div class="dno js-hidden" data-name="passport.js">
            <a href="/questions/tagged/node.js+passport.js" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js passport.js&#39;" rel="tag">passport.js</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">4547</span></span>
        </div>
        <div class="dno js-hidden" data-name="webpack">
            <a href="/questions/tagged/node.js+webpack" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js webpack&#39;" rel="tag">webpack</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">4197</span></span>
        </div>
        <div class="dno js-hidden" data-name="sockets">
            <a href="/questions/tagged/node.js+sockets" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js sockets&#39;" rel="tag">sockets</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">4063</span></span>
        </div>
        <div class="dno js-hidden" data-name="arrays">
            <a href="/questions/tagged/node.js+arrays" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js arrays&#39;" rel="tag">arrays</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">3851</span></span>
        </div>
        <div class="dno js-hidden" data-name="websocket">
            <a href="/questions/tagged/node.js+websocket" class="post-tag no-tag-menu" title="show questions tagged &#39;node.js websocket&#39;" rel="tag">websocket</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">3760</span></span>
        </div>
        <a href="#"
           class="show-more js-show-more js-gps-track"
           data-gps-track="related_tags.click({ item_type:2 })">
            more related tags
        </a>
        <script>
            StackExchange.ready(function () {
                var $div = $('#h-related-tags').parent();
                $div.find('.js-show-more').click(function () {
                    $div.find('.js-hidden').show();
                    $(this).remove();
                    return false;
                });
            });
        </script>

            </div>

        <div id="hot-network-questions" class="module tex2jax_ignore">
    <h4>
        <a href="https://stackexchange.com/questions?tab=hot"
           class="js-gps-track s-link s-link__inherit" 
           data-gps-track="posts_hot_network.click({ item_type:1, location:9 })">
            Hot Network Questions
        </a>
    </h4>
    <ul>
            <li >
                <div class="favicon favicon-codegolf" title="Code Golf Stack Exchange"></div><a href="https://codegolf.stackexchange.com/questions/206830/implement-a-unix-file-system-and-command-line-parser" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:200 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Implement a UNIX file system and command line parser
                </a>

            </li>
            <li >
                <div class="favicon favicon-tex" title="TeX - LaTeX Stack Exchange"></div><a href="https://tex.stackexchange.com/questions/552667/how-to-get-the-index-variable-in-the-foreach-loop" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:85 }); posts_hot_network.click({ item_type:2, location:9 })">
                    How to get the index variable in the foreach loop
                </a>

            </li>
            <li >
                <div class="favicon favicon-travel" title="Travel Stack Exchange"></div><a href="https://travel.stackexchange.com/questions/158151/do-foreigners-need-a-vignette-to-drive-on-german-motorways" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:273 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Do foreigners need a vignette to drive on German motorways?
                </a>

            </li>
            <li >
                <div class="favicon favicon-superuser" title="Super User"></div><a href="https://superuser.com/questions/1566851/can-original-file-get-corrupted-during-copying" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:3 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Can original file get corrupted during copying?
                </a>

            </li>
            <li >
                <div class="favicon favicon-academia" title="Academia Stack Exchange"></div><a href="https://academia.stackexchange.com/questions/151476/should-a-teacher-be-able-to-solve-all-the-assignments-they-give-their-students-t" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:415 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Should a teacher be able to solve all the assignments they give their students themselves?
                </a>

            </li>
            <li >
                <div class="favicon favicon-astronomy" title="Astronomy Stack Exchange"></div><a href="https://astronomy.stackexchange.com/questions/36826/how-many-satellites-orbit-their-planet-faster-than-the-planet-rotates" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:514 }); posts_hot_network.click({ item_type:2, location:9 })">
                    How many satellites orbit their planet faster than the planet rotates?
                </a>

            </li>
            <li >
                <div class="favicon favicon-money" title="Personal Finance &amp; Money Stack Exchange"></div><a href="https://money.stackexchange.com/questions/127478/possible-executive-assistant-job-scam-to-buy-bitcoin" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:93 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Possible Executive Assistant Job Scam to buy bitcoin
                </a>

            </li>
            <li >
                <div class="favicon favicon-cooking" title="Seasoned Advice"></div><a href="https://cooking.stackexchange.com/questions/109493/where-does-the-green-part-of-the-scallion-start-and-the-white-part-end" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:49 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Where does the green part of the scallion start and the white part end?
                </a>

            </li>
            <li >
                <div class="favicon favicon-mattermodeling" title="Matter Modeling Stack Exchange"></div><a href="https://mattermodeling.stackexchange.com/questions/1480/how-big-should-a-supercell-be" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:704 }); posts_hot_network.click({ item_type:2, location:9 })">
                    How big should a supercell be?
                </a>

            </li>
            <li >
                <div class="favicon favicon-worldbuilding" title="Worldbuilding Stack Exchange"></div><a href="https://worldbuilding.stackexchange.com/questions/180071/if-guns-had-a-50-chance-of-lethally-backfiring-what-would-they-be-used-for" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:579 }); posts_hot_network.click({ item_type:2, location:9 })">
                    If guns had a 50% chance of lethally backfiring, what would they be used for?
                </a>

            </li>
            <li >
                <div class="favicon favicon-engineering" title="Engineering Stack Exchange"></div><a href="https://engineering.stackexchange.com/questions/36563/are-toasters-really-electrified-inside-of-the-slots" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:595 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Are toasters really electrified inside of the &quot;slots&quot;?
                </a>

            </li>
            <li >
                <div class="favicon favicon-money" title="Personal Finance &amp; Money Stack Exchange"></div><a href="https://money.stackexchange.com/questions/127424/is-it-an-ok-strategy-to-sell-whenever-an-investment-gains-value-above-a-threshol" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:93 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Is it an OK strategy to sell whenever an investment gains value above a threshold?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-aviation" title="Aviation Stack Exchange"></div><a href="https://aviation.stackexchange.com/questions/79376/what-could-explain-the-fact-that-during-1976-80-i-used-to-hear-commercial-jets" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:528 }); posts_hot_network.click({ item_type:2, location:9 })">
                    What could explain the fact that during 1976-80, I used to hear commercial jets make sonic booms while flying overhead?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-stats" title="Cross Validated"></div><a href="https://stats.stackexchange.com/questions/475837/how-can-the-square-of-an-asymptotically-normal-variable-also-be-asympotically-no" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:65 }); posts_hot_network.click({ item_type:2, location:9 })">
                    How can the square of an asymptotically normal variable also be asympotically normal?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-mathoverflow" title="MathOverflow"></div><a href="https://mathoverflow.net/questions/364982/smooth-map-homotopic-to-lie-group-homomorphism" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:504 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Smooth map homotopic to Lie group homomorphism
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-webmasters" title="Webmasters Stack Exchange"></div><a href="https://webmasters.stackexchange.com/questions/130442/confusing-domain-name-extensions" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:45 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Confusing domain name extensions
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-travel" title="Travel Stack Exchange"></div><a href="https://travel.stackexchange.com/questions/158170/does-a-uk-entry-ban-affect-travel-to-other-countries" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:273 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Does a UK entry ban affect travel to other countries?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-music" title="Music: Practice &amp; Theory Stack Exchange"></div><a href="https://music.stackexchange.com/questions/101626/does-roman-numerals-for-a-chord-progressions-change-capitalization-when-played-i" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:240 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Does Roman Numerals for a chord progressions change capitalization when played in a different key than the original?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-politics" title="Politics Stack Exchange"></div><a href="https://politics.stackexchange.com/questions/54399/is-it-true-that-jim-crow-laws-were-primarily-promoted-by-the-democratic-party" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:475 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Is it true that Jim Crow laws were primarily promoted by the Democratic Party?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-mathoverflow" title="MathOverflow"></div><a href="https://mathoverflow.net/questions/365070/intuition-behind-stability-and-unstability-in-model-theory" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:504 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Intuition behind stability and unstability in model theory
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-scifi" title="Science Fiction &amp; Fantasy Stack Exchange"></div><a href="https://scifi.stackexchange.com/questions/234150/picard-crusher-love-scene" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:186 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Picard/Crusher Love Scene
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-security" title="Information Security Stack Exchange"></div><a href="https://security.stackexchange.com/questions/234251/how-can-we-eliminate-passwords-given-the-problems-with-biometric-authentication" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:162 }); posts_hot_network.click({ item_type:2, location:9 })">
                    How can we eliminate passwords given the problems with biometric authentication?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-puzzling" title="Puzzling Stack Exchange"></div><a href="https://puzzling.stackexchange.com/questions/99712/almost-impossible-sudoku-like-puzzle" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:559 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Almost impossible Sudoku like puzzle
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-medicalsciences" title="Medical Sciences Stack Exchange"></div><a href="https://medicalsciences.stackexchange.com/questions/24071/why-use-a-placebo-in-some-potential-covid-19-vaccine-trials" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:607 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Why use a placebo in some potential COVID-19 vaccine trials?
                </a>

            </li>
    </ul>

        <a href="#" 
           class="show-more js-show-more js-gps-track" 
           data-gps-track="posts_hot_network.click({ item_type:3, location:9 })">
            more hot questions
        </a>
</div>

                <div id="feed-link" class="js-feed-link">
        <a href="/feeds/tag?tagnames=node.js&amp;sort=newest" title="The 30 newest node.js questions">
            <svg aria-hidden="true" class="fc-orange-400 svg-icon iconRss" width="18" height="18" viewBox="0 0 18 18"><path d="M1 3c0-1.1.9-2 2-2h12a2 2 0 012 2v12a2 2 0 01-2 2H3a2 2 0 01-2-2V3zm14.5 12C15.5 8.1 9.9 2.5 3 2.5V5a10 10 0 0110 10h2.5zm-5 0A7.5 7.5 0 003 7.5V10a5 5 0 015 5h2.5zm-5 0A2.5 2.5 0 003 12.5V15h2.5z"/></svg>
            Newest node.js questions feed
        </a>
    </div>
    <aside class="s-modal js-feed-link-modal" tabindex="-1" role="dialog" aria-labelledby="feed-modal-title" aria-describedby="feed-modal-description" aria-hidden="true">
        <div class="s-modal--dialog js-modal-dialog wmx4" role="document"  data-controller="se-draggable">
            <h1 class="s-modal--header fw-bold js-first-tabbable" id="feed-modal-title" data-target="se-draggable.handle" tabindex="0">
                Subscribe to RSS
            </h1>
            <div class="grid gs4 gsy fd-column">
                <div class="grid--cell">
                    <label class="d-block s-label c-default" for="feed-url">
                        Newest node.js questions feed
                        <p class="s-description mt2" id="feed-modal-description">To subscribe to this RSS feed, copy and paste this URL into your RSS reader.</p>
                    </label>
                </div>
                <div class="grid ps-relative">
                    <input class="s-input" type="text" name="feed-url" id="feed-url" readonly="readonly" value="https://stackoverflow.com/feeds/tag?tagnames=node.js&amp;sort=newest" />
                    <svg aria-hidden="true" class="s-input-icon fc-orange-400 svg-icon iconRss" width="18" height="18" viewBox="0 0 18 18"><path d="M1 3c0-1.1.9-2 2-2h12a2 2 0 012 2v12a2 2 0 01-2 2H3a2 2 0 01-2-2V3zm14.5 12C15.5 8.1 9.9 2.5 3 2.5V5a10 10 0 0110 10h2.5zm-5 0A7.5 7.5 0 003 7.5V10a5 5 0 015 5h2.5zm-5 0A2.5 2.5 0 003 12.5V15h2.5z"/></svg>
                </div>
            </div>
            <a class="s-modal--close s-btn s-btn__muted js-modal-close js-last-tabbable" href="#" aria-label="Close">
                <svg aria-hidden="true" class="svg-icon iconClearSm" width="14" height="14" viewBox="0 0 14 14"><path d="M12 3.41L10.59 2 7 5.59 3.41 2 2 3.41 5.59 7 2 10.59 3.41 12 7 8.41 10.59 12 12 10.59 8.41 7 12 3.41z"/></svg>
            </a>
        </div>
    </aside>

    </div>

        </div>
    </div>
        
<script>;try{(function(a){function b(a){return'string'==typeof a?document.getElementById(a):a}function c(a){return a=b(a),!!a&&'none'===getComputedStyle(a).display}function d(a){return!c(a)}function e(a){return!!a}function f(a){return /^\s*$/.test(b(a).innerHTML)}function g(a){var b=a.style;b.height=b.maxHeight=b.minHeight='auto',b.display='none',[].forEach.call(a.children,g)}function h(a,b){var c;return function(){return a&&(c=a.call(b||this,arguments),a=null),c}}function i(a){var b=document.createElement('script');b.src=a,document.body.appendChild(b)}function j(a){return k([],a)}function k(a,b){return a.push=function(a){return b(),delete this.push,this.push(a)},a}function l(){try{return!new Function('return async()=>{};')}catch(a){return!0}}function m(){return'undefined'!=typeof googletag&&!!googletag.apiReady}function n(){m()||(googletag={cmd:j(A)})}function o(){var a=document.createElement('div');a.className='adsbox',a.id='clc-abd',a.style.position='absolute',a.style.pointerEvents='none',a.innerHTML='&nbsp;',document.body.appendChild(a)}function p(){return Object.keys(E.ids)}function r(a){var b=E.ids[a],c=E.slots[b];'function'==typeof c&&(c=c(a));return{path:'/'+B+'/'+D+'/'+b+'/'+C,sizes:c,zone:b}}function q(a){try{Array.isArray(clc.dfp.slotsRenderedEvents)||(clc.dfp.slotsRenderedEvents=[]),clc.dfp.slotsRenderedEvents.push(a);var b=a.slot.getSlotElementId(),c=[];b||c.push('id=0');var d=document.getElementById(b);if(!b||d?d.hasAttribute('data-clc-stalled')&&c.push('st=1'):c.push('el=0'),0!==c.length)return void F(c.join('&'));var e=r(b),f=e.zone;if(clc.collapse&&clc.collapse[f]&&a.isEmpty)return g(d),void d.setAttribute('data-clc-ready','true');if(-1!==x.dh.indexOf(a.lineItemId))g(d);else if(a.lineItemId&&(d.setAttribute('data-clc-prefilled','true'),'dfp-msb'==b)){var h=document.getElementById('hireme');g(h)}d.setAttribute('data-clc-ready','true')}catch(a){var i=document.querySelector('#dfp-tsb, #dfp-isb, #clc-tsb');i&&i.setAttribute('data-clc-ready','true'),F('e=1')}}function s(a){return!(clc.collapse&&void 0!==clc.collapse[a])||!!clc.collapse[a]}function t(a,b){'dfp-isb'===a&&b.setTargeting('Sidebar',['Inline']),'dfp-tsb'===a&&b.setTargeting('Sidebar',['Right']);var c=r(a),d=c.path,e=c.sizes,f=c.zone,g=googletag.defineSlot(d,e,a);if(s(f)){var h=!x.ll;g.setCollapseEmptyDiv(!0,h)}g.addService(b),!1}function u(b){var c=a.dfp&&a.dfp.targeting||{};'SystemDefault'===c.ProductVariant&&(window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches?c.ProductVariant='Dark':c.ProductVariant='Light'),Object.keys(c).forEach(function(a){b.setTargeting(a,c[a])})}function v(a){var g=a.map(b).filter(e);return{eligible:g.filter(f).filter(d),ineligible:g.filter(c)}}function w(b){void 0===b&&(b=p());var c=['dfp-mlb','dfp-smlb'];if(!m())return n(),void googletag.cmd.push(function(){return w(b)});var d=v(b),e=d.eligible,f=d.ineligible;if(f.forEach(g),0!==e.length){x.abd&&o(),googletag.destroySlots();var h=googletag.pubads();x.sf&&(h.setForceSafeFrame(!0),h.setSafeFrameConfig({allowOverlayExpansion:!0,allowPushExpansion:!0,sandbox:!0})),x.ll||h.enableSingleRequest(),a.sreEvent||(h.addEventListener('slotRenderEnded',q),a.sreEvent=!0),u(h);var i=e.filter(function(a){return!x.ll||0>c.indexOf(a.id)}),j=e.filter(function(a){return!!x.ll&&0<=c.indexOf(a.id)});i.forEach(function(a){t(a.id,h),a.setAttribute('data-dfp-zone','true')}),googletag.enableServices(),i.forEach(function(a){googletag.display(a.id)}),x.ll&&(h.enableLazyLoad({fetchMarginPercent:0,renderMarginPercent:0}),j.forEach(function(a){t(a.id,h),a.setAttribute('data-clc-prefilled','true')}),j.forEach(function(a){googletag.display(a.id)}))}}var x=function(a){for(var b=[],c=1;c<arguments.length;c++)b[c-1]=arguments[c];for(var d,e=0,f=b;e<f.length;e++)for(var g in d=f[e],d)a[g]=d[g];return a}({"lib":"https://cdn.sstatic.net/clc/clc.min.js?v=7dce99576e19","style":"https://cdn.sstatic.net/clc/styles/clc.min.css?v=8b21b47ef0c7","u":"https://clc.stackoverflow.com/markup.js","wa":true,"kt":2000,"tto":true,"h":"clc.stackoverflow.com","allowed":"^(((talent\\.)?stackoverflow)|(blog\\.codinghorror)|(serverfault|askubuntu)|([^\\.]+\\.stackexchange))\\.com$","wv":true,"al":false,"dh":[5171832659],"abd":true},a.options||{}),y=h(function(){var a=x.lib;l()&&(a=a.replace(/(\.min)?\.js(\?v=[0-9a-fA-F]+)?$/,'.ie$1.js$2')),i(a)}),z=a.cmd||[];Array.isArray(z)&&(0<z.length?y():k(z,y));var A=h(function(){i('https://www.googletagservices.com/tag/js/gpt.js')}),B='248424177',C=/^\/tags\//.test(location.pathname)||/^\/questions\/tagged\//.test(location.pathname)?'tag-pages':/^\/$/.test(location.pathname)||/^\/home/.test(location.pathname)?'home-page':'question-pages',D=location.hostname;var E={slots:{lb:[[728,90]],mlb:[[728,90]],smlb:[[728,90]],bmlb:[[728,90]],sb:function(a){return'dfp-tsb'===a?[[300,250],[300,600]]:[[300,250]]},"tag-sponsorship":[[730,135]],"mobile-below-question":[[320,50],[300,250]],msb:[[300,250],[300,600]]},ids:{"dfp-tlb":'lb',"dfp-mlb":'mlb',"dfp-smlb":'smlb',"dfp-bmlb":'bmlb',"dfp-tsb":'sb',"dfp-isb":'sb',"dfp-tag":'tag-sponsorship',"dfp-msb":'msb',"dfp-m-aq":'mobile-below-question',"clc-tlb":'lb',"clc-mlb":'mlb',"clc-tsb":'sb'}},F=function(a){new Image().src='https://'+x.h+'/stalled.gif?'+a};(function(){var b=x.al;b&&z.push(function(){return a.load()})})(),n(),a.dfp={load:w},a.options=x,a.cmd=z})(this.clc=this.clc||{})}catch(a){window.console.error(a)}</script>    <script>
        var clc = clc || {};
        clc.collapse = { sb: !0, 'tag-sponsorship': !0, lb:!0, mlb:!0, smlb:!0, bmlb:!0, 'mobile-below-question':!0};
        clc.options = clc.options || {};
        clc.options.sf = !0;
        clc.options.hb = !1;
        clc.options.ll = !0;
        clc.cmd = clc.cmd || [];
        clc.cmd.push(function () { window.clc_request='AtWiIxVQI9gIAAAAAAAAAAACAAAAAQAAAAAJAAAAfG5vZGUuanN8AI2z4YoVay45SlQ'; clc.load(); });
        clc.dfp = clc.dfp || {};
        clc.dfp.targeting = {Registered:['false'],'so-tag':['node.js'],'tag-reportable':['node.js'],'tag-non-reportable':['node.js']};
        var googletag = googletag || {};
        googletag.cmd = googletag.cmd || [];
        googletag.cmd.push(function () { clc.dfp.load(); });

            StackExchange.ready(function () { googletag.cmd.push(function () { StackExchange.ads.init(googletag, '/ads/report-ad', 'Report this ad') }) });
    </script>

            <footer id="footer" class="site-footer js-footer" role="contentinfo">
        <div class="site-footer--container">
                <div class="site-footer--logo">
                    
                    <a href="https://stackoverflow.com"><svg aria-hidden="true" class="native svg-icon iconLogoGlyphMd" width="32" height="37" viewBox="0 0 32 37"><path d="M26 33v-9h4v13H0V24h4v9h22z" fill="#BCBBBB"/><path d="M21.5 0l-2.7 2 9.9 13.3 2.7-2L21.5 0zM26 18.4L13.3 7.8l2.1-2.5 12.7 10.6-2.1 2.5zM9.1 15.2l15 7 1.4-3-15-7-1.4 3zm14 10.79l.68-2.95-16.1-3.35L7 23l16.1 2.99zM23 30H7v-3h16v3z" fill="#F48024"/></svg></a>
                </div>
            <nav class="site-footer--nav">
                    <div class="site-footer--col site-footer--col__visible js-footer-col" data-name="default">
                        <h5 class="-title"><a href="https://stackoverflow.com" class="js-gps-track" data-gps-track="footer.click({ location: 5, link: 15})">Stack Overflow</a></h5>
                        <ul class="-list js-primary-footer-links">
                            <li class="-item"><a href="/questions" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 16})">Questions</a></li>
                                <li class="-item"><a href="https://stackoverflow.com/jobs" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 17})">Jobs</a></li>
                                <li class="-item"><a href="https://stackoverflow.com/jobs/directory/developer-jobs" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 11})">Developer Jobs Directory</a></li>
                                     <li class="-item"><a href="https://stackoverflow.com/jobs/salary" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 28})">Salary Calculator</a></li>
                                <li class="-item"><a href="/help" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 3 })">Help</a></li>
                                <li class="-item"><a onclick='StackExchange.switchMobile("on")' class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 12 })">Mobile</a></li>
                        </ul>
                    </div>
                    <div class="site-footer--col site-footer--col__visible js-footer-col" data-name="default">
                        <h5 class="-title"><a href="https://stackoverflowbusiness.com" class="js-gps-track" data-gps-track="footer.click({ location: 5, link: 19 })">Products</a></h5>
                        <ul class="-list">
                            <li class="-item"><a href="https://stackoverflow.com/teams" class="js-gps-track -link" 
                                                 data-ga="[&quot;teams traffic&quot;,&quot;footer - site nav&quot;,&quot;stackoverflow.com/teams&quot;,null,{&quot;dimension4&quot;:&quot;teams&quot;}]"
                                                 data-gps-track="footer.click({ location: 5, link: 29 })">Teams</a></li>
                            <li class="-item"><a href="https://stackoverflow.com/talent" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 20 })">Talent</a></li>
                            <li class="-item"><a href="https://stackoverflow.com/advertising" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 21 })">Advertising</a></li>
                            <li class="-item"><a href="https://stackoverflow.com/enterprise" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 22 })">Enterprise</a></li>
                        </ul>
                    </div>
                <div class="site-footer--col site-footer--col__visible js-footer-col" data-name="default">
                    <h5 class="-title"><a class="js-gps-track" data-gps-track="footer.click({ location: 5, link: 1 })" href="https://stackoverflow.com/company/about">Company</a></h5>
                    <ul class="-list">
                            <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 1 })" href="https://stackoverflow.com/company/about">About</a></li>
                        <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 27 })" href="https://stackoverflow.com/company/press">Press</a></li>
                            <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 9 })" href="https://stackoverflow.com/company/work-here">Work Here</a></li>
                        <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 7 })" href="https://stackoverflow.com/legal">Legal</a></li>
                        <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 8 })" href="https://stackoverflow.com/legal/privacy-policy">Privacy Policy</a></li>
                            <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 13 })" href="https://stackoverflow.com/company/contact">Contact Us</a></li>
                    </ul>
                </div>
                <div class="site-footer--col site-footer--categories-nav site-footer--col__visible">
                    <a href="#" class="site-footer--back js-footer-back"><svg aria-hidden="true" class="svg-icon iconArrowLeftAlt" width="18" height="18" viewBox="0 0 18 18"><path d="M10.58 16L12 14.59 6.4 9 12 3.41 10.57 2l-7 7 7 7z"/></svg></a>
                    <div>
                        <h5 class="-title"><a href="https://stackexchange.com" data-gps-track="footer.click({ location: 5, link: 30 })">Stack Exchange<br> Network</a></h5>
                        <ul class="-list">
                            <li class="-item"><a href="#" class="-link _expandable js-footer-category-trigger js-gps-track" data-gps-track="footer.click({ location: 5, link: 24 })" data-target="Technology">Technology</a></li>
                            <li class="-item"><a href="#" class="-link _expandable js-footer-category-trigger js-gps-track" data-gps-track="footer.click({ location: 5, link: 24 })" data-target="Life / Arts">Life / Arts</a></li>
                            <li class="-item"><a href="#" class="-link _expandable js-footer-category-trigger js-gps-track" data-gps-track="footer.click({ location: 5, link: 24 })" data-target="Culture / Recreation">Culture / Recreation</a></li>
                            <li class="-item"><a href="#" class="-link _expandable js-footer-category-trigger js-gps-track" data-gps-track="footer.click({ location: 5, link: 24 })" data-target="Science">Science</a></li>
                            <li class="-item"><a href="#" class="-link _expandable js-footer-category-trigger js-gps-track" data-gps-track="footer.click({ location: 5, link: 24 })" data-target="Other">Other</a></li>
                        </ul>
                    </div>
                </div>
                <div class="site-footer--categories">
                        <div class="site-footer--col site-footer--category js-footer-col" data-name="Technology">
        <ul class="-list">
                <li class="-item"><a href="https://stackoverflow.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional and enthusiast programmers">Stack Overflow</a></li>
                <li class="-item"><a href="https://serverfault.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="system and network administrators">Server Fault</a></li>
                <li class="-item"><a href="https://superuser.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="computer enthusiasts and power users">Super User</a></li>
                <li class="-item"><a href="https://webapps.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="power users of web applications">Web Applications</a></li>
                <li class="-item"><a href="https://askubuntu.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Ubuntu users and developers">Ask Ubuntu</a></li>
                <li class="-item"><a href="https://webmasters.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="pro webmasters">Webmasters</a></li>
                <li class="-item"><a href="https://gamedev.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional and independent game developers">Game Development</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://tex.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users of TeX, LaTeX, ConTeXt, and related typesetting systems">TeX - LaTeX</a></li>
                <li class="-item"><a href="https://softwareengineering.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professionals, academics, and students working within the systems development life cycle">Software Engineering</a></li>
                <li class="-item"><a href="https://unix.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users of Linux, FreeBSD and other Un*x-like operating systems">Unix &amp; Linux</a></li>
                <li class="-item"><a href="https://apple.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="power users of Apple hardware and software">Ask Different (Apple)</a></li>
                <li class="-item"><a href="https://wordpress.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="WordPress developers and administrators">WordPress Development</a></li>
                <li class="-item"><a href="https://gis.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="cartographers, geographers and GIS professionals">Geographic Information Systems</a></li>
                <li class="-item"><a href="https://electronics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="electronics and electrical engineering professionals, students, and enthusiasts">Electrical Engineering</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://android.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="enthusiasts and power users of the Android operating system">Android Enthusiasts</a></li>
                <li class="-item"><a href="https://security.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="information security professionals">Information Security</a></li>
                <li class="-item"><a href="https://dba.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="database professionals who wish to improve their database skills and learn from others in the community">Database Administrators</a></li>
                <li class="-item"><a href="https://drupal.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Drupal developers and administrators">Drupal Answers</a></li>
                <li class="-item"><a href="https://sharepoint.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="SharePoint enthusiasts">SharePoint</a></li>
                <li class="-item"><a href="https://ux.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="user experience researchers and experts">User Experience</a></li>
                <li class="-item"><a href="https://mathematica.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users of Wolfram Mathematica">Mathematica</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://salesforce.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Salesforce administrators, implementation experts, developers and anybody in-between">Salesforce</a></li>
                <li class="-item"><a href="https://expressionengine.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="administrators, end users, developers and designers for ExpressionEngine&#xAE; CMS">ExpressionEngine&#xAE; Answers</a></li>
                <li class="-item"><a href="https://pt.stackoverflow.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="programadores profissionais e entusiastas">Stack Overflow em Portugu&#xEA;s</a></li>
                <li class="-item"><a href="https://blender.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people who use Blender to create 3D graphics, animations, or games">Blender</a></li>
                <li class="-item"><a href="https://networkengineering.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="network engineers">Network Engineering</a></li>
                <li class="-item"><a href="https://crypto.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="software developers, mathematicians and others interested in cryptography">Cryptography</a></li>
                <li class="-item"><a href="https://codereview.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="peer programmer code reviews">Code Review</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://magento.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users of the Magento e-Commerce platform">Magento</a></li>
                <li class="-item"><a href="https://softwarerecs.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people seeking specific software recommendations">Software Recommendations</a></li>
                <li class="-item"><a href="https://dsp.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="practitioners of the art and science of signal, image and video processing">Signal Processing</a></li>
                <li class="-item"><a href="https://emacs.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="those using, extending or developing Emacs">Emacs</a></li>
                <li class="-item"><a href="https://raspberrypi.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users and developers of hardware and software for Raspberry Pi">Raspberry Pi</a></li>
                <li class="-item"><a href="https://ru.stackoverflow.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="&#x43F;&#x440;&#x43E;&#x433;&#x440;&#x430;&#x43C;&#x43C;&#x438;&#x441;&#x442;&#x43E;&#x432;">Stack Overflow &#x43D;&#x430; &#x440;&#x443;&#x441;&#x441;&#x43A;&#x43E;&#x43C;</a></li>
                <li class="-item"><a href="https://codegolf.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="programming puzzle enthusiasts and code golfers">Code Golf</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://es.stackoverflow.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="programadores y profesionales de la inform&#xE1;tica">Stack Overflow en espa&#xF1;ol</a></li>
                <li class="-item"><a href="https://ethereum.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users of Ethereum, the decentralized application platform and smart contract enabled blockchain">Ethereum</a></li>
                <li class="-item"><a href="https://datascience.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Data science professionals, Machine Learning specialists, and those interested in learning more about the field">Data Science</a></li>
                <li class="-item"><a href="https://arduino.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="developers of open-source hardware and software that is compatible with Arduino">Arduino</a></li>
                <li class="-item"><a href="https://bitcoin.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Bitcoin crypto-currency enthusiasts">Bitcoin</a></li>
                <li class="-item"><a href="https://sqa.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="software quality control experts, automation engineers, and software testers">Software Quality Assurance &amp; Testing</a></li>
                <li class="-item"><a href="https://sound.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="sound engineers, producers, editors, and enthusiasts">Sound Design</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://windowsphone.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="enthusiasts and power users of Windows Phone OS">Windows Phone</a></li>
                <li class="-item">
                    <a href="https://stackexchange.com/sites#technology" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 26 })">
                        <strong>
                            more (28)
                        </strong>
                    </a>
                </li>
        </ul>
    </div>
    <div class="site-footer--col site-footer--category js-footer-col" data-name="Life / Arts">
        <ul class="-list">
                <li class="-item"><a href="https://photo.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional, enthusiast and amateur photographers">Photography</a></li>
                <li class="-item"><a href="https://scifi.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="science fiction and fantasy enthusiasts">Science Fiction &amp; Fantasy</a></li>
                <li class="-item"><a href="https://graphicdesign.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Graphic Design professionals, students, and enthusiasts">Graphic Design</a></li>
                <li class="-item"><a href="https://movies.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="movie and TV enthusiasts">Movies &amp; TV</a></li>
                <li class="-item"><a href="https://music.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="musicians, students, and enthusiasts">Music: Practice &amp; Theory</a></li>
                <li class="-item"><a href="https://worldbuilding.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="writers/artists using science, geography and culture to construct imaginary worlds and settings">Worldbuilding</a></li>
                <li class="-item"><a href="https://video.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="engineers, producers, editors, and enthusiasts spanning the fields of video, and media creation">Video Production</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Life / Arts"><ul class="-list">
                <li class="-item"><a href="https://cooking.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional and amateur chefs">Seasoned Advice (cooking)</a></li>
                <li class="-item"><a href="https://diy.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="contractors and serious DIYers">Home Improvement</a></li>
                <li class="-item"><a href="https://money.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people who want to be financially literate">Personal Finance &amp; Money</a></li>
                <li class="-item"><a href="https://academia.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="academics and those enrolled in higher education">Academia</a></li>
                <li class="-item"><a href="https://law.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="legal professionals, students, and others with experience or interest in law">Law</a></li>
                <li class="-item"><a href="https://fitness.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="physical fitness professionals, athletes, trainers, and those providing health-related needs">Physical Fitness</a></li>
                <li class="-item"><a href="https://gardening.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="gardeners and landscapers">Gardening &amp; Landscaping</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Life / Arts"><ul class="-list">
                <li class="-item"><a href="https://parenting.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="parents, grandparents, nannies and others with a parenting role">Parenting</a></li>
                <li class="-item">
                    <a href="https://stackexchange.com/sites#lifearts" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 26 })">
                        <strong>
                            more (10)
                        </strong>
                    </a>
                </li>
        </ul>
    </div>
    <div class="site-footer--col site-footer--category js-footer-col" data-name="Culture / Recreation">
        <ul class="-list">
                <li class="-item"><a href="https://english.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="linguists, etymologists, and serious English language enthusiasts">English Language &amp; Usage</a></li>
                <li class="-item"><a href="https://skeptics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="scientific skepticism">Skeptics</a></li>
                <li class="-item"><a href="https://judaism.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="those who base their lives on Jewish law and tradition and anyone interested in learning more">Mi Yodeya (Judaism)</a></li>
                <li class="-item"><a href="https://travel.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="road warriors and seasoned travelers">Travel</a></li>
                <li class="-item"><a href="https://christianity.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="committed Christians, experts in Christianity and those interested in learning more">Christianity</a></li>
                <li class="-item"><a href="https://ell.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="speakers of other languages learning English">English Language Learners</a></li>
                <li class="-item"><a href="https://japanese.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students, teachers, and linguists wanting to discuss the finer points of the Japanese language">Japanese Language</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Culture / Recreation"><ul class="-list">
                <li class="-item"><a href="https://chinese.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students, teachers, and linguists wanting to discuss the finer points of the Chinese language">Chinese Language</a></li>
                <li class="-item"><a href="https://french.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students, teachers, and linguists wanting to discuss the finer points of the French language">French Language</a></li>
                <li class="-item"><a href="https://german.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="speakers of German wanting to discuss the finer points of the language and translation">German Language</a></li>
                <li class="-item"><a href="https://hermeneutics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professors, theologians, and those interested in exegetical analysis of biblical texts">Biblical Hermeneutics</a></li>
                <li class="-item"><a href="https://history.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="historians and history buffs">History</a></li>
                <li class="-item"><a href="https://spanish.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="linguists, teachers, students and Spanish language enthusiasts in general wanting to discuss the finer points of the language">Spanish Language</a></li>
                <li class="-item"><a href="https://islam.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Muslims, experts in Islam, and those interested in learning more about Islam">Islam</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Culture / Recreation"><ul class="-list">
                <li class="-item"><a href="https://rus.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="&#x43B;&#x438;&#x43D;&#x433;&#x432;&#x438;&#x441;&#x442;&#x43E;&#x432; &#x438; &#x44D;&#x43D;&#x442;&#x443;&#x437;&#x438;&#x430;&#x441;&#x442;&#x43E;&#x432; &#x440;&#x443;&#x441;&#x441;&#x43A;&#x43E;&#x433;&#x43E; &#x44F;&#x437;&#x44B;&#x43A;&#x430;">&#x420;&#x443;&#x441;&#x441;&#x43A;&#x438;&#x439; &#x44F;&#x437;&#x44B;&#x43A;</a></li>
                <li class="-item"><a href="https://russian.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students, teachers, and linguists wanting to discuss the finer points of the Russian language">Russian Language</a></li>
                <li class="-item"><a href="https://gaming.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="passionate videogamers on all platforms">Arqade (gaming)</a></li>
                <li class="-item"><a href="https://bicycles.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people who build and repair bicycles, people who train cycling, or commute on bicycles">Bicycles</a></li>
                <li class="-item"><a href="https://rpg.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="gamemasters and players of tabletop, paper-and-pencil role-playing games">Role-playing Games</a></li>
                <li class="-item"><a href="https://anime.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="anime and manga fans">Anime &amp; Manga</a></li>
                <li class="-item"><a href="https://puzzling.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="those who create, solve, and study puzzles">Puzzling</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Culture / Recreation"><ul class="-list">
                <li class="-item"><a href="https://mechanics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="mechanics and DIY enthusiast owners of cars, trucks, and motorcycles">Motor Vehicle Maintenance &amp; Repair</a></li>
                <li class="-item"><a href="https://boardgames.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people who like playing board games, designing board games or modifying the rules of existing board games">Board &amp; Card Games</a></li>
                <li class="-item"><a href="https://bricks.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="LEGO&#xAE; and building block enthusiasts">Bricks</a></li>
                <li class="-item"><a href="https://homebrew.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="dedicated home brewers and serious enthusiasts">Homebrewing</a></li>
                <li class="-item"><a href="https://martialarts.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students and teachers of all martial arts">Martial Arts</a></li>
                <li class="-item"><a href="https://outdoors.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people who love being outdoors enjoying nature and wilderness, and learning about the required skills and equipment">The Great Outdoors</a></li>
                <li class="-item"><a href="https://poker.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="serious players and enthusiasts of poker">Poker</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Culture / Recreation"><ul class="-list">
                <li class="-item"><a href="https://chess.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="serious players and enthusiasts of chess">Chess</a></li>
                <li class="-item"><a href="https://sports.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="participants in team and individual sport activities">Sports</a></li>
                <li class="-item">
                    <a href="https://stackexchange.com/sites#culturerecreation" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 26 })">
                        <strong>
                            more (16)
                        </strong>
                    </a>
                </li>
        </ul>
    </div>
    <div class="site-footer--col site-footer--category js-footer-col" data-name="Science">
        <ul class="-list">
                <li class="-item"><a href="https://mathoverflow.net" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional mathematicians">MathOverflow</a></li>
                <li class="-item"><a href="https://math.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people studying math at any level and professionals in related fields">Mathematics</a></li>
                <li class="-item"><a href="https://stats.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people interested in statistics, machine learning, data analysis, data mining, and data visualization">Cross Validated (stats)</a></li>
                <li class="-item"><a href="https://cstheory.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="theoretical computer scientists and researchers in related fields">Theoretical Computer Science</a></li>
                <li class="-item"><a href="https://physics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="active researchers, academics and students of physics">Physics</a></li>
                <li class="-item"><a href="https://chemistry.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="scientists, academics, teachers, and students in the field of chemistry">Chemistry</a></li>
                <li class="-item"><a href="https://biology.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="biology researchers, academics, and students">Biology</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Science"><ul class="-list">
                <li class="-item"><a href="https://cs.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students, researchers and practitioners of computer science">Computer Science</a></li>
                <li class="-item"><a href="https://philosophy.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="those interested in the study of the fundamental nature of knowledge, reality, and existence">Philosophy</a></li>
                <li class="-item"><a href="https://linguistics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional linguists and others with an interest in linguistic research and theory">Linguistics</a></li>
                <li class="-item"><a href="https://psychology.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="practitioners, researchers, and students in cognitive science, psychology, neuroscience, and psychiatry">Psychology &amp; Neuroscience</a></li>
                <li class="-item"><a href="https://scicomp.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="scientists using computers to solve scientific problems">Computational Science</a></li>
                <li class="-item">
                    <a href="https://stackexchange.com/sites#science" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 26 })">
                        <strong>
                            more (10)
                        </strong>
                    </a>
                </li>
        </ul>
    </div>
    <div class="site-footer--col site-footer--category js-footer-col" data-name="Other">
        <ul class="-list">
                <li class="-item"><a href="https://meta.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="meta-discussion of the Stack Exchange family of Q&amp;A websites">Meta Stack Exchange</a></li>
                <li class="-item"><a href="https://stackapps.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="apps, scripts, and development with the Stack Exchange API">Stack Apps</a></li>
                <li class="-item"><a href="https://api.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="programmatic interaction with Stack Exchange sites">API</a></li>
                <li class="-item"><a href="https://data.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="querying Stack Exchange data using SQL">Data</a></li>
        </ul>
    </div>

                </div>
            </nav>
            <div class="site-footer--copyright fs-fine">
                <ul class="-list">
                    <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link:4 })" href="https://stackoverflow.blog?blb=1">Blog</a></li>
                    <li class="-item"><a href="https://www.facebook.com/officialstackoverflow/" class="-link js-gps-track" data-gps-track="footer.click({ location: 5, link: 31 })">Facebook</a></li>
                    <li class="-item"><a href="https://twitter.com/stackoverflow" class="-link js-gps-track" data-gps-track="footer.click({ location: 5, link: 32 })">Twitter</a></li>
                    <li class="-item"><a href="https://linkedin.com/company/stack-overflow" class="-link js-gps-track" data-gps-track="footer.click({ location: 5, link: 33 })">LinkedIn</a></li>
                    <li class="-item"><a href="https://www.instagram.com/thestackoverflow" class="-link js-gps-track" data-gps-track="footer.click({ location: 5, link: 36 })">Instagram</a></li>
                </ul>

                <p class="mt-auto mb24">
site design / logo &#169; 2020 Stack Exchange Inc; user contributions licensed under <a href="https://stackoverflow.com/help/licensing">cc by-sa</a>.                    <span id="svnrev">rev&nbsp;2020.7.7.37196</span>
                </p>
            </div>
        </div>

    </footer>

            <script>StackExchange.ready(function () { StackExchange.responsiveness.addSwitcher(); })</script>
    <noscript>
        <div id="noscript-warning">Stack Overflow works best with JavaScript enabled
            <img src="https://pixel.quantserve.com/pixel/p-c1rF4kxgLUzNc.gif" alt="" class="dno">
        </div>
    </noscript>

        <script>
(function(i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function() { (i[r].q = i[r].q || []).push(arguments) }, i[r].l = 1 * new Date(); a = s.createElement(o),
                m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m);
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            StackExchange.ready(function () {

                StackExchange.ga.init({
                    sendTitles: true,
                    tracker: window.ga,
                    trackingCodes: [
                        'UA-108242619-1'
                    ],
                        checkDimension: 'dimension42'
                });



                    StackExchange.ga.setDimension('dimension2', '|node.js|');

                    StackExchange.ga.setDimension('dimension3', 'Questions/ListByTag');


                StackExchange.ga.trackPageView();
            });
            /**/

            var _qevents = _qevents || [],
            _comscore = _comscore || [];
            (function() {
                var ssl = 'https:' == document.location.protocol,
                    s = document.getElementsByTagName('script')[0],
                    qc = document.createElement('script');
 qc.async = true;
                    qc.src = (ssl ? 'https://secure' : 'http://edge') + '.quantserve.com/quant.js';
                    s.parentNode.insertBefore(qc, s);
                    _qevents.push({ qacct: "p-c1rF4kxgLUzNc" });/**/
 var sc = document.createElement('script');
                    sc.async = true;
                    sc.src = (ssl ? 'https://sb' : 'http://b') + '.scorecardresearch.com/beacon.js';
                    s.parentNode.insertBefore(sc, s);
                    _comscore.push({ c1: "2", c2: "17440561" });            })();
            
</script>

    
    </body>
    </html>
