<!DOCTYPE html>


    <html class="html__responsive">

    <head>

        <title>Highest Voted &#39;laravel+vue.js&#39; Questions - Stack Overflow</title>
        <link rel="shortcut icon" href="https://cdn.sstatic.net/Sites/stackoverflow/Img/favicon.ico?v=ec617d715196">
        <link rel="apple-touch-icon" href="https://cdn.sstatic.net/Sites/stackoverflow/Img/apple-touch-icon.png?v=c78bd457575a">
        <link rel="image_src" href="https://cdn.sstatic.net/Sites/stackoverflow/Img/apple-touch-icon.png?v=c78bd457575a"> 
        <link rel="search" type="application/opensearchdescription+xml" title="Stack Overflow" href="/opensearch.xml">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0">
        <meta property="og:type" content= "website" />
        <meta property="og:url" content="https://stackoverflow.com/questions/tagged/laravel&#x2B;vue.js"/>
        <meta property="og:site_name" content="Stack Overflow" />
        <meta property="og:image" itemprop="image primaryImageOfPage" content="https://cdn.sstatic.net/Sites/stackoverflow/Img/apple-touch-icon@2.png?v=73d79a89bded" />
        <meta name="twitter:card" content="summary"/>
        <meta name="twitter:domain" content="stackoverflow.com"/>
        <meta name="twitter:title" property="og:title" itemprop="name" content="Highest Voted &#x27;laravel&#x2B;vue.js&#x27; Questions" />
        <meta name="twitter:description" property="og:description" itemprop="description" content="Stack Overflow | The World&#x2019;s Largest Online Community for Developers" />

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://cdn.sstatic.net/Js/stub.en.js?v=39ab3f513667"></script>
    
        <link rel="stylesheet" type="text/css" href="https://cdn.sstatic.net/Shared/stacks.css?v=0ee8a05683e7" >
        <link rel="stylesheet" type="text/css" href="https://cdn.sstatic.net/Sites/stackoverflow/primary.css?v=c5fdf309f06b" >
        <link rel="stylesheet" type="text/css" href="https://cdn.sstatic.net/Sites/stackoverflow/secondary.css?v=0ad93e7d5552" >

    
            <link rel="alternate" type="application/atom+xml" title="Highest voted laravel vue.js questions feed" href="/feeds/tag?tagnames=laravel&#x2B;vue.js&amp;sort=votes" />

        
        
        
        
        
        
        


    <script>
        StackExchange.init({"locale":"en","serverTime":1594221699,"routeName":"Questions/ListByTag","stackAuthUrl":"https://stackauth.com","networkMetaHostname":"meta.stackexchange.com","site":{"name":"Stack Overflow","description":"Q&A for professional and enthusiast programmers","isNoticesTabEnabled":true,"enableNewTagCreationWarning":true,"insertSpaceAfterNameTabCompletion":false,"id":1,"childUrl":"https://meta.stackoverflow.com","negativeVoteScoreFloor":null,"enableSocialMediaInSharePopup":true,"protocol":"https"},"user":{"fkey":"3617a09d093ab016f84b62babf7378eed871cd3b24839c1012d3021561f38b45","tid":"5bb2a24c-fc6c-ddfc-7719-57f31a7f5462","rep":0,"isAnonymous":true,"isAnonymousNetworkWide":true,"ab":{"tutorial_tooltips":{"v":"thanks_reaction_icon","g":2}}},"events":{"postType":{"question":1},"postEditionSection":{"title":1,"body":2,"tags":3}},"story":{"minCompleteBodyLength":75,"likedTagsMaxLength":300,"dislikedTagsMaxLength":300},"jobPreferences":{"maxNumDeveloperRoles":2,"maxNumIndustries":4},"svgIconPath":"https://cdn.sstatic.net/Img/svg-icons","svgIconHash":"2816dfc51c0f"}, {"userProfile":{"openGraphAPIKey":"4a307e43-b625-49bb-af15-ffadf2bda017"},"userMessaging":{"showNewFeatureNotice":true},"tags":{},"subscriptions":{"defaultMaxTrueUpSeats":1000},"snippets":{"renderDomain":"stacksnippets.net","snippetsEnabled":true},"slack":{"sidebarAdDismissCookie":"slack-sidebar-ad","sidebarAdDismissCookieExpirationDays":60.0},"site":{"allowImageUploads":true,"enableImgurHttps":true,"enableUserHovercards":true,"forceHttpsImages":true,"styleCode":true},"paths":{},"monitoring":{"clientTimingsAbsoluteTimeout":30000,"clientTimingsDebounceTimeout":1000},"mentions":{"maxNumUsersInDropdown":50},"markdown":{"asteriskIntraWordEmphasis":true,"enableCommonmark":true},"flags":{"allowRetractingCommentFlags":true,"allowRetractingFlags":true},"comments":{},"accounts":{"currentPasswordRequiredForChangingStackIdPassword":true}});
        StackExchange.using.setCacheBreakers({"js/adops.en.js":"22a9bd59b1e9","js/ask.en.js":"1c0a624e1e04","js/begin-edit-event.en.js":"cb9965ad8784","js/events.en.js":"f2d560c0fe3c","js/explore-qlist.en.js":"be3b9d8380ea","js/full-anon.en.js":"0bcf47259372","js/full.en.js":"e44b79cbeab0","js/help.en.js":"76e2886f2122","js/inline-tag-editing.en.js":"25799d8d2d38","js/keyboard-shortcuts.en.js":"c547be604304","js/mobile.en.js":"45f128a33544","js/moderator.en.js":"82f863f6432c","js/postCollections-transpiled.en.js":"137dca7e528b","js/post-validation.en.js":"87800ef436e4","js/prettify-full.en.js":"87db5610dcfb","js/question-editor.en.js":"","js/review.en.js":"7c0ed16699f8","js/revisions.en.js":"fa23b076b70a","js/tageditor.en.js":"1f2a41e0a86e","js/tageditornew.en.js":"d0bb0592d3cb","js/tagsuggestions.en.js":"4d2d70ee1e16","js/third-party/stacks-editor/app.bundle.js":"72999662ddbd","js/third-party/stacks-editor/app.bundle.en.js":"","js/wmd.en.js":"c064f26b531a","js/snippet-javascript-codemirror.en.js":"d47545fd3fa1","js/markdown-it-loader.en.js":"7c8a40bee094"});
        StackExchange.using("gps", function() {
             StackExchange.gps.init(true);
        });
    </script>
    <noscript id="noscript-css"><style>body,.top-bar{margin-top:1.9em}</style></noscript>
    </head>
    <body class="tagged-questions-page unified-theme">
    <div id="notify-container"></div>
    <div id="custom-header"></div>
        
<header class="top-bar js-top-bar top-bar__network _fixed">
    <div class="wmx12 mx-auto grid ai-center h100" role="menubar">
        <div class="-main grid--cell">
                <a href="#" class="left-sidebar-toggle p0 ai-center jc-center js-left-sidebar-toggle" role="menuitem" aria-haspopup="true" aria-controls="left-sidebar" aria-expanded="false"><span class="ps-relative"></span></a>
                <div class="topbar-dialog leftnav-dialog js-leftnav-dialog dno">
                    <div class="left-sidebar js-unpinned-left-sidebar" data-can-be="left-sidebar" data-is-here-when="sm"></div>
                </div>
                    <a href="https://stackoverflow.com" class="-logo js-gps-track"
                        data-gps-track="top_nav.click({is_current:false, location:5, destination:8})">
                        <span class="-img _glyph">Stack Overflow</span>
                    </a>



        </div>

            <ol class="list-reset grid gs4" role="presentation">
                <li class="grid--cell">
                    <a href="#"
                        class="-marketing-link js-gps-track js-products-menu"
                        aria-controls="products-popover"
                        data-controller="s-popover"
                        data-action="s-popover#toggle"
                        data-s-popover-placement="bottom"
                        data-s-popover-toggle-class="is-selected"
                        data-gps-track="top_nav.products.click({location:5, destination:1})"
                        data-ga="[&quot;top navigation&quot;,&quot;products menu click&quot;,null,null,null]">
                        Products
                    </a>
                </li>

                    <li class="grid--cell md:d-none">
                        <a href="/teams/customers" class="-marketing-link js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:7})"
                            data-ga="[&quot;top navigation&quot;,&quot;customers menu click&quot;,null,null,null]">Customers</a>
                    </li>
                    <li class="grid--cell md:d-none">
                        <a href="/teams/use-cases" class="-marketing-link js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:8})"
                           data-ga="[&quot;top navigation&quot;,&quot;use cases menu click&quot;,null,null,null]">Use cases</a>
                    </li>
            </ol>
            <div class="s-popover ws2 p6"
                    id="products-popover"
                    role="menu"
                    aria-hidden="true">
                <div class="s-popover--arrow"></div>
                <ol class="list-reset s-anchors s-anchors__inherit">
                    <li>
                        <a href="/questions" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:2})"
                           data-ga="[&quot;top navigation&quot;,&quot;public qa submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Stack Overflow</span>
                            <span class="fs-caption d-block fc-light">Public questions and answers</span>
                        </a>
                    </li>
                    <li>
                        <a href="/teams" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:3})"
                           data-ga="[&quot;top navigation&quot;,&quot;teams submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Teams</span>
                            <span class="fs-caption d-block fc-light">Private questions and answers for your team</span>
                        </a>
                    </li>
                    <li>
                        <a href="/enterprise" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:4})"
                           data-ga="[&quot;top navigation&quot;,&quot;enterprise submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Enterprise</span>
                            <span class="fs-caption d-block fc-light">Private self-hosted questions and answers for your enterprise</span>
                        </a>
                    </li>
                    <li>
                        <a href="/jobs?so_source=ProductsMenu&so_medium=StackOverflow" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                            data-gps-track="top_nav.products.click({location:5, destination:9})"
                            data-ga="[&quot;top navigation&quot;,&quot;jobs submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Jobs</span>
                            <span class="fs-caption d-block fc-light">Programming and related technical career opportunities</span>
                        </a>
                    </li>
                    <li class="bt bc-black-3 mln6 mrn6 mt6 pt6 px6" >
                        <a href="https://stackoverflow.com/talent" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:5})"
                           data-ga="[&quot;top navigation&quot;,&quot;talent submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Talent</span>
                            <span class="fs-caption d-block fc-light">Hire technical talent</span>
                        </a>
                    </li>
                    <li>
                        <a href="https://stackoverflow.com/advertising" class="d-block py6 px6 bar-sm h:bg-black-100 js-gps-track"
                           data-gps-track="top_nav.products.click({location:5, destination:6})"
                           data-ga="[&quot;top navigation&quot;,&quot;advertising submenu click&quot;,null,null,null]">
                            <span class="fs-body1 d-block">Advertising</span>
                            <span class="fs-caption d-block fc-light">Reach developers worldwide</span>
                        </a>
                    </li>

                </ol>
            </div>

            <form id="search" role="search" action=/search method="get" class="grid--cell fl-grow1 searchbar px12 js-searchbar " autocomplete="off">
                    <div class="ps-relative">
                        <input name="q"
                               type="text"
                               placeholder="Search&#x2026;"
                               value="[laravel] [vue.js]"
                               autocomplete="off"
                               maxlength="240"
                               class="s-input s-input__search js-search-field "
                               aria-label="Search"
                               aria-controls="top-search" 
                               data-controller="s-popover"
                               data-action="focus->s-popover#show"
                               data-s-popover-placement="bottom-start"/>
                        <svg aria-hidden="true" class="s-input-icon s-input-icon__search svg-icon iconSearch" width="18" height="18" viewBox="0 0 18 18"><path d="M18 16.5l-5.14-5.18h-.35a7 7 0 10-1.19 1.19v.35L16.5 18l1.5-1.5zM12 7A5 5 0 112 7a5 5 0 0110 0z"/></svg>
                        <div class="s-popover p0 wmx100 wmn4 sm:wmn-initial js-top-search-popover s-popover--arrow__tl" id="top-search" role="menu">
    <div class="js-spinner p24 grid ai-center jc-center d-none">
        <div class="s-spinner s-spinner__sm fc-orange-400">
            <div class="v-visible-sr">Loading&#x2026;</div>
        </div>
    </div>

    <span class="v-visible-sr js-screen-reader-info"></span>
    <div class="js-ac-results overflow-y-auto hmx3 d-none"></div>

    <div class="js-search-hints" aria-describedby="Tips for searching"></div>
</div>
                    </div>
            </form>
        
        

<ol class="overflow-x-auto ml-auto -secondary grid ai-center list-reset h100 user-logged-out" role="presentation">
        <li class="-item searchbar-trigger"><a href="#" class="-link js-searchbar-trigger" role="button" aria-label="Search" aria-haspopup="true" aria-controls="search" title="Click to show search"><svg aria-hidden="true" class="svg-icon iconSearch" width="18" height="18" viewBox="0 0 18 18"><path d="M18 16.5l-5.14-5.18h-.35a7 7 0 10-1.19 1.19v.35L16.5 18l1.5-1.5zM12 7A5 5 0 112 7a5 5 0 0110 0z"/></svg></a></li>

            <li class="-ctas">
                            <a href="https://stackoverflow.com/users/login?ssrc=head&returnurl=https%3a%2f%2fstackoverflow.com%2fquestions%2ftagged%2flaravel%2bvue.js" class="login-link s-btn s-btn__filled py8 js-gps-track" rel="nofollow"
                               data-gps-track="login.click" data-ga="[&quot;top navigation&quot;,&quot;login button click&quot;,null,null,null]">Log in</a>
                            <a href="https://stackoverflow.com/users/signup?ssrc=head&returnurl=%2fusers%2fstory%2fcurrent" class="login-link s-btn s-btn__primary py8" rel="nofollow" data-ga="[&quot;sign up&quot;,&quot;Sign Up Navigation&quot;,&quot;Header&quot;,null,null]">Sign up</a>

            </li>

    <li class="js-topbar-dialog-corral" role="presentation">
            

    <div class="topbar-dialog siteSwitcher-dialog dno" role="menu">
        <div class="header">
            <h3>
                <a href="https://stackoverflow.com">current community</a>
            </h3>
        </div>
        <div class="modal-content bg-powder-050">
            <ul class="current-site">
                    <li class="grid">
                            <div class="fl1">
                <a href="https://stackoverflow.com"
       class="current-site-link site-link js-gps-track grid gs8 gsx"
       data-id="1"
       data-gps-track="site_switcher.click({ item_type:3 })">
        <div class="favicon favicon-stackoverflow site-icon grid--cell" title="Stack Overflow"></div>
        <span class="grid--cell fl1">
            Stack Overflow
        </span>
    </a>

    </div>
    <div class="related-links">
            <a href="https://stackoverflow.com/help" class="js-gps-track" data-gps-track="site_switcher.click({ item_type:14 })">help</a>
            <a href="https://chat.stackoverflow.com" class="js-gps-track" data-gps-track="site_switcher.click({ item_type:6 })">chat</a>
    </div>

                    </li>
                    <li class="related-site grid">
                            <div class="L-shaped-icon-container">
        <span class="L-shaped-icon"></span>
    </div>

                            <a href="https://meta.stackoverflow.com"
       class=" site-link js-gps-track grid gs8 gsx"
       data-id="552"
       data-gps-track="site.switch({ target_site:552, item_type:3 }),site_switcher.click({ item_type:4 })">
        <div class="favicon favicon-stackoverflowmeta site-icon grid--cell" title="Meta Stack Overflow"></div>
        <span class="grid--cell fl1">
            Meta Stack Overflow
        </span>
    </a>

                    </li>
            </ul>
        </div>

        <div class="header" id="your-communities-header">
            <h3>
your communities            </h3>

        </div>
        <div class="modal-content" id="your-communities-section">

                <div class="call-to-login">
<a href="https://stackoverflow.com/users/signup?ssrc=site_switcher&amp;returnurl=%2fusers%2fstory%2fcurrent" class="login-link js-gps-track" data-gps-track="site_switcher.click({ item_type:10 })">Sign up</a> or <a href="https://stackoverflow.com/users/login?ssrc=site_switcher&amp;returnurl=https%3a%2f%2fstackoverflow.com%2fquestions%2ftagged%2flaravel%2bvue.js" class="login-link js-gps-track" data-gps-track="site_switcher.click({ item_type:11 })">log in</a> to customize your list.                </div>
        </div>

        <div class="header">
            <h3><a href="https://stackexchange.com/sites">more stack exchange communities</a>
            </h3>
            <a href="https://stackoverflow.blog" class="fr">company blog</a>
        </div>
        <div class="modal-content">
                <div class="child-content"></div>
        </div>        
    </div>

    </li>
</ol>
    </div>
</header>
    <div id="js-gdpr-consent-banner" class="p8 ff-sans ps-fixed b0 l0 r0 z-banner" role="banner" aria-hidden="false" style="background-color: #3b4045; color: white;"> 
        <div class="wmx8 mx-auto grid grid__center" role="alertdialog" aria-describedby="notice-message">
            <div class="grid--cell mr12" aria-label="notice-message">
                <p class="mb0 lh-lg">
                    By using our site, you acknowledge that you have read and understand our <a class="s-link s-link__inherit td-underline fc-white" target="_blank" href="https://stackoverflow.com/legal/cookie-policy">Cookie Policy</a>, <a class="s-link s-link__inherit td-underline fc-white" target="_blank" href="https://stackoverflow.com/legal/privacy-policy">Privacy Policy</a>, and our <a class="s-link s-link__inherit td-underline fc-white" target="_blank" href="https://stackoverflow.com/legal/terms-of-service/public">Terms of Service</a>.
                </p>
            </div>
            <div class="grid--cell">
                <a class="s-btn s-btn__muted s-btn__icon js-notice-close" aria-label="notice-dismiss">
                    <svg aria-hidden="true" class="svg-icon iconClear" width="18" height="18" viewBox="0 0 18 18"><path d="M15 4.41L13.59 3 9 7.59 4.41 3 3 4.41 7.59 9 3 13.59 4.41 15 9 10.41 13.59 15 15 13.59 10.41 9 15 4.41z"/></svg>
                </a>
            </div>
        </div>
    </div>

    <script>
        StackExchange.ready(function () { StackExchange.topbar.init(); });
StackExchange.scrollPadding.setPaddingTop(50, 10);    </script>





    <div class="container">
            

<div id="left-sidebar" data-is-here-when="md lg" class="left-sidebar js-pinned-left-sidebar ps-relative">
    <div class="left-sidebar--sticky-container js-sticky-leftnav">
        <nav role="navigation">
            <ol class="nav-links">
        <li class="">
            <a
                href="/"
                class="pl8 js-gps-track nav-links--link"
                
                data-gps-track="top_nav.click({is_current:false, location:5, destination:8})">
Home            </a>
        </li>
                <li>
                    <ol class="nav-links">
                            <li class="fs-fine tt-uppercase ml8 mt16 mb4 fc-light">Public</li>
                                <li class=" youarehere">
            <a id="nav-questions"
                href="/questions"
                class="pl8 js-gps-track nav-links--link -link__with-icon"
                
                data-gps-track="top_nav.click({is_current:true, location:5, destination:1})">
<svg aria-hidden="true" class="svg-icon iconGlobe" width="18" height="18" viewBox="0 0 18 18"><path d="M9 1a8 8 0 100 16A8 8 0 009 1zM8 15.32a6.4 6.4 0 01-5.23-7.75L7 11.68v.8c0 .88.12 1.32 1 1.32v1.52zm5.72-2c-.2-.66-1-1.32-1.72-1.32h-1v-2c0-.44-.56-1-1-1H6V7h1c.44 0 1-.56 1-1V5h2c.88 0 1.4-.72 1.4-1.6v-.33a6.4 6.4 0 012.32 10.24v.01z"/></svg>                    <span class="-link--channel-name">Stack Overflow</span>
            </a>
        </li>

        <li class="">
            <a id="nav-tags"
                href="/tags"
                class=" js-gps-track nav-links--link"
                
                data-gps-track="top_nav.click({is_current:false, location:5, destination:2})">
Tags            </a>
        </li>
        <li class="">
            <a id="nav-users"
                href="/users"
                class=" js-gps-track nav-links--link"
                
                data-gps-track="top_nav.click({is_current:false, location:5, destination:3})">
Users            </a>
        </li>
                            <li class="fs-fine tt-uppercase ml8 mt16 mb4 fc-light">Find a Job</li>
        <li class="">
            <a id="nav-jobs"
                href="/jobs?so_medium=StackOverflow&amp;so_source=SiteNav"
                class=" js-gps-track nav-links--link"
                
                data-gps-track="top_nav.click({is_current:false, location:5, destination:6})">
Jobs            </a>
        </li>
        <li class="">
            <a id="nav-companies"
                href="/jobs/companies?so_medium=StackOverflow&amp;so_source=SiteNav"
                class=" js-gps-track nav-links--link"
                
                data-gps-track="top_nav.click({is_current:false, location:5, destination:12})">
Companies            </a>
        </li>
                    </ol>
                </li>
                    <li>
                        <ol class="nav-links">
                                <li class="grid ai-center jc-space-between ml8 mt24 mb4">
                                    <div class="grid--cell tt-uppercase fs-fine fc-light">Teams</div>
                                    <div class="grid--cell fs-fine fc-light mr4">
                                        <a href="javascript:void(0)" class="s-link s-link__inherit js-gps-track"
                                            role="button"
                                            aria-controls="popover-teams-create-cta"
                                            data-controller="s-popover"
                                            data-action="s-popover#toggle"
                                            data-s-popover-placement="bottom-start"
                                            data-s-popover-toggle-class="is-selected"
                                            data-gps-track="teams.create.left-sidenav.click({ Action: ShowInfo })"
                                            data-ga="[&quot;teams left navigation - anonymous&quot;,&quot;left nav show teams info&quot;,null,null,null]">
                                            What&#x2019;s this?
                                        </a>

                                    </div>
                                </li>
                                <li class="ps-relative">
                                    <a href="https://stackoverflow.com/teams"
                                        class="pl8 js-gps-track nav-links--link"
                                        title="Stack Overflow for Teams is a private, secure spot for your organization's questions and answers."
                                        data-gps-track="teams.create.left-sidenav.click({ Action: TeamsClick })"
                                        data-ga="[&quot;teams left navigation - anonymous&quot;,&quot;left nav team click&quot;,&quot;stackoverflow.com/teams&quot;,null,null]">
                                        <div class="grid ai-center">
                                            <div class="grid--cell s-avatar va-middle bg-orange-400">
                                                <div class="s-avatar--letter mtn1">
                                                    <svg aria-hidden="true" class="svg-icon iconBriefcaseSm" width="14" height="14" viewBox="0 0 14 14"><path d="M4 3a1 1 0 011-1h4a1 1 0 011 1v1h.5c.83 0 1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5h-7A1.5 1.5 0 012 10.5v-5C2 4.67 2.67 4 3.5 4H4V3zm5 1V3H5v1h4z"/></svg>
                                                </div>
                                                <svg aria-hidden="true" class="native s-avatar--badge svg-icon iconShieldXSm" width="9" height="10" viewBox="0 0 9 10"><path d="M0 1.84L4.5 0 9 1.84v3.17C9 7.53 6.3 10 4.5 10 2.7 10 0 7.53 0 5.01V1.84z" fill="var(--white)"/><path d="M1 2.5L4.5 1 8 2.5v2.51C8 7.34 5.34 9 4.5 9 3.65 9 1 7.34 1 5.01V2.5zm2.98 3.02L3.2 7h2.6l-.78-1.48a.4.4 0 01.15-.38c.34-.24.73-.7.73-1.14 0-.71-.5-1.23-1.41-1.23-.92 0-1.39.52-1.39 1.23 0 .44.4.9.73 1.14.12.08.18.23.15.38z" fill="var(--black-500)"/></svg>
                                            </div>
                                            <div class="grid--cell pl6">
Free 30 Day Trial                                            </div>
                                        </div>
                                    </a>
                                </li>
                        </ol>
                    </li>
            </ol>
        </nav>
    </div>


        <div class="s-popover w-auto p16"
             id="popover-teams-create-cta"
             role="menu"
             aria-hidden="true">
            <div class="s-popover--arrow"></div>

            <div class="ps-relative overflow-hidden">
                <p class="mb2"><strong>Teams</strong></p>
                <p class="mb16 fs-caption fc-medium">Q&amp;A for Work</p>
                <p class="mb8 fs-caption fc-medium">

                            Stack Overflow for Teams is a private, secure spot for you and
                            your coworkers to find and share information.
                                        </p>
                <a href="https://stackoverflow.com/teams"
                   class="js-gps-track ws-nowrap d-block"
                   data-gps-track="teams.create.left-sidenav.click({ Action: CtaClick })"
                   data-ga="[&quot;teams left navigation - anonymous&quot;,&quot;left nav cta&quot;,&quot;stackoverflow.com/teams&quot;,null,null]">
Learn more                </a>
            </div>

            <div class="ps-absolute t8 r8">
                <svg width="53" height="49" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M49 11l.2 31H18.9L9 49v-7H4V8h31" fill="#CCEAFF" /><path d="M44.5 19v-.3l-.2-.1-18-13-.1-.1H.5v33h4V46l.8-.6 9.9-6.9h29.3V19z" stroke="#1060E1" stroke-miterlimit="10" /><path d="M31 2l6-1.5 7 2V38H14.9L5 45v-7H1V6h25l5-4z" fill="#fff" /><path d="M7 16.5h13m-13 6h14m-14 6h18" stroke="#1060E1" stroke-miterlimit="10" /><path d="M39 30a14 14 0 1 0 0-28 14 14 0 0 0 0 28z" fill="#FFB935" /><path d="M50.5 14a13.5 13.5 0 1 1-27 0 13.5 13.5 0 0 1 27 0z" stroke="#F48024" stroke-miterlimit="10" /><path d="M32.5 21.5v-8h9v8h-9zm2-9.5V9.3A2.5 2.5 0 0 1 37 6.8a2.5 2.5 0 0 1 2.5 2.5V12h-5zm2 3v2m1-2v2" stroke="#fff" stroke-miterlimit="10" /></svg>
            </div>
        </div>

</div>



        <div id="content" class="snippet-hidden">

            
    <div id="mainbar">
        

        <div class="grid">
            <div class="grid fl1 mb24">
                <h1 class="grid--cell fs-headline1 mb0">
All Questions                </h1>
            </div>

            <div class="ml12 aside-cta grid--cell print:d-none">
                
    <a href="/questions/ask" class="ws-nowrap s-btn s-btn__primary" >
        Ask Question
    </a>

            </div>
        </div>

    <style>.everyoneloves__top-leaderboard:empty,.everyoneloves__mid-leaderboard:empty,.everyoneloves__bot-mid-leaderboard:empty{
            margin-bottom:0;
}
</style>
<div id="dfp-tag" class="everyonelovesstackoverflow everyoneloves__tag-sponsorship mb12"></div>

            <div class="mb24">Tagged with <a href="/questions/tagged/laravel" class="post-tag mx2" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag mx2" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> </div>

            
<script>
    StackExchange.ready(function () {
        initTagRenderer("".split(" "), "".split(" "));
        StackExchange.userQuestionList.init({
            sharingUrl: ""
        });
    });
</script>
<div data-controller="se-uql" data-se-uql-id="" data-se-uql-sanitize-tag-query="false">
    <div class="grid ai-center jc-space-between mb12 sm:fd-column sm:ai-stretch">
        <div class="fs-body3 grid--cell fl1 mr12 sm:mr0 sm:mb12">
            4,774

questions        </div>

        <div class="uql-nav grid--cell"
             data-action="se-uql-list:edit-current-requested@document->se-uql#toggleEditor">
            <div class="grid ai-center jc-space-between">
                <div class="js-uql-navigation s-btn-group grid--cell mr16 ff-row-nowrap">
                        <a class="s-btn s-btn__muted s-btn__outlined s-btn__sm grid d-flex" data-nav-value="Newest" href="/questions/tagged/laravel%2bvue.js?tab=Newest" data-shortcut="N">
                            <div class="grid--cell">Newest</div>
                        </a>
                        <a class="s-btn s-btn__muted s-btn__outlined s-btn__sm grid d-flex" data-nav-value="Active" href="/questions/tagged/laravel%2bvue.js?tab=Active" data-shortcut="A">
                            <div class="grid--cell">Active</div>
                        </a>
                        <a class="s-btn s-btn__muted s-btn__outlined s-btn__sm grid d-flex uql-nav--expanded-item" data-nav-value="Bounties" href="/questions/tagged/laravel%2bvue.js?tab=Bounties" data-shortcut="E">
                            <div class="grid--cell">Bountied</div>
                                <div class="s-badge s-badge__bounty s-badge__bounty s-badge__sm lh-xs ml4 px4 grid--cell">2</div>
                        </a>
                        <a class="s-btn s-btn__muted s-btn__outlined s-btn__sm grid d-flex uql-nav--expanded-item" data-nav-value="Unanswered" href="/questions/tagged/laravel%2bvue.js?tab=Unanswered" data-shortcut="U">
                            <div class="grid--cell">Unanswered</div>
                        </a>
                    <button class="s-btn s-btn__muted s-btn__outlined s-btn__sm s-btn__dropdown is-selected"
                            role="button"
                            data-controller="s-popover"
                            data-action="s-popover#toggle"
                            data-target="se-uql.toggleMoreButton"
                            aria-haspopup="true"
                            aria-expanded="false"
                            aria-controls="uql-more-popover">
                        More
                    </button>
                </div>

                <div class="s-popover z-dropdown ws2"
                     id="uql-more-popover"
                     data-target="se-uql.morePopover">
                    <div class="s-popover--arrow"></div>
                    <ul class="list-reset mtn8 mbn8 js-uql-navigation">
                            <li class="uql-item my0 uql-nav--collapsed-item">
                                    <a href="/questions/tagged/laravel%2bvue.js?tab=Bounties" class="mln12 mrn12 px12 py6 fl1 s-block-link" data-shortcut="">
                                        Bountied
                                            <span class="s-badge s-badge__bounty s-badge__bounty s-badge__sm lh-xs px4">2</span>
                                    </a>
                            </li>
                            <li class="uql-item my0 uql-nav--collapsed-item">
                                    <a href="/questions/tagged/laravel%2bvue.js?tab=Unanswered" class="mln12 mrn12 px12 py6 fl1 s-block-link" data-shortcut="">
                                        Unanswered
                                    </a>
                            </li>
                            <li class="uql-item my0">
                                    <a href="/questions/tagged/laravel%2bvue.js?tab=Frequent" class="mln12 mrn12 px12 py6 fl1 s-block-link" data-shortcut="F">
                                        Frequent
                                    </a>
                            </li>
                            <li class="uql-item my0">
                                    <a href="/questions/tagged/laravel%2bvue.js?tab=Votes" class="mln12 mrn12 px12 py6 fl1 s-block-link s-block-link__left is-selected" aria-current="page" data-shortcut="V">
                                        Votes
                                    </a>
                            </li>
                                <li class="uql-item uql-item__separator bg-black-075 d:bg-black-025"></li>
                            <li class="uql-item my0">
                                    <span class="s-block-link c-default fc-black-100 mrn12 px12 py6">Unanswered (my tags)</span>
                            </li>
                    </ul>
                </div>

                <div class="grid--cell">
                    <button class="s-btn s-btn__filled s-btn__sm s-btn__icon ws-nowrap"
                            role="button"
                            data-controller="s-expandable-control"
                            data-s-expandable-control-toggle-class="is-selected"
                            data-target="se-uql.toggleFormButton"
                            aria-expanded="false"
                            aria-controls="uql-form">
                        <svg aria-hidden="true" class="sm:d-none va-middle svg-icon iconGearSm" width="14" height="14" viewBox="0 0 14 14"><path d="M8.17 11.42l-.39 1.53a6.07 6.07 0 01-1.58 0l-.39-1.53c-.39-.1-.75-.26-1.1-.46l-1.35.8c-.42-.31-.8-.69-1.12-1.1l.8-1.37c-.2-.34-.35-.7-.46-1.1L1.05 7.8a6.06 6.06 0 010-1.57l1.53-.4c.1-.4.25-.76.45-1.11l-.8-1.36c.32-.42.7-.8 1.1-1.11l1.36.8c.35-.2.73-.36 1.13-.47l.4-1.53a6.06 6.06 0 011.55 0l.4 1.53c.4.1.78.26 1.13.47l1.36-.8c.41.31.78.68 1.1 1.1l-.8 1.36c.2.35.36.73.46 1.13l1.53.39a6.06 6.06 0 010 1.57l-1.53.39c-.1.4-.27.77-.47 1.11l.8 1.36c-.32.42-.7.8-1.11 1.11l-1.36-.8c-.34.2-.71.35-1.1.45zM7 9a2 2 0 100-4 2 2 0 000 4z"/></svg> Filter
                    </button>
                </div>
            </div>


        </div>
    </div>

    <form class="s-expandable ps-relative z-active"
          id="uql-form"
          data-target="se-uql.form"
          data-action="se-uql#navigate">
        <input name="uqlId" type="hidden"/>
        <div class="s-expandable--content">
            <div class="bg-black-050 ba bc-black-3 bar-sm mb16">
                <div class="px12 py16">
                    <div class="grid gs32 fw-wrap">
                        <div class="grid--cell">
                            <fieldset class="grid gs8 gsy fd-column">
                                <legend class="grid--cell s-label px0">Filter by</legend>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-checkbox d-block"
                           type="checkbox"
                           name="filterId"
                           value="NoAnswers"
                           id="f93b6a69-62cb-4734-b930-f840e9b40333" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="f93b6a69-62cb-4734-b930-f840e9b40333">No answers</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-checkbox d-block"
                           type="checkbox"
                           name="filterId"
                           value="NoAcceptedAnswer"
                           id="68cde3bd-13cb-4a1d-ade4-edd137bf8d65" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="68cde3bd-13cb-4a1d-ade4-edd137bf8d65">No accepted answer</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-checkbox d-block"
                           type="checkbox"
                           name="filterId"
                           value="Bounty"
                           id="7fec2540-3a61-4518-8142-60592d3229f4" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="7fec2540-3a61-4518-8142-60592d3229f4">Has bounty</label>
            </div>
        </div>
                            </fieldset>
                        </div>
                        <div class="grid--cell">
                            <fieldset class="grid gs8 gsy fd-column">
                                <legend class="grid--cell s-label px0">Sorted by</legend>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="sortId"
                           value="Newest"
                           id="67387cca-f844-43fe-8c74-8f90b5b4b052" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="67387cca-f844-43fe-8c74-8f90b5b4b052">Newest</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="sortId"
                           value="RecentActivity"
                           id="8509411c-ad42-4e97-a7cc-aebfb9598f04" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="8509411c-ad42-4e97-a7cc-aebfb9598f04">Recent activity</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="sortId"
                           value="MostVotes"
                           checked="checked"
                           id="efc42a47-f8b4-4f6a-ae32-5d9869f48172" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="efc42a47-f8b4-4f6a-ae32-5d9869f48172">Most votes</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="sortId"
                           value="MostFrequent"
                           id="ad7fa84b-4ece-47cf-947f-e6031d7aeb75" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="ad7fa84b-4ece-47cf-947f-e6031d7aeb75">Most frequent</label>
            </div>
        </div>
        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="sortId"
                           value="BountyEndingSoon"
                           id="64d8d434-6bdf-4c10-9d4c-7a7239d46bcf" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="64d8d434-6bdf-4c10-9d4c-7a7239d46bcf">Bounty ending soon</label>
            </div>
        </div>
                            </fieldset>
                        </div>
                        <div class="grid--cell">
                            <fieldset class="grid gs8 gsy fd-column">
                                <legend class="grid--cell s-label px0">Tagged with</legend>
                                        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="tagModeId"
                           value="Watched"
                           id="ee1aaebd-f5f3-4741-ba1e-9eb2f498d28e" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="ee1aaebd-f5f3-4741-ba1e-9eb2f498d28e">My watched tags</label>
            </div>
        </div>

                                        <div class="grid--cell">
            <div class="grid gs4 gsx ai-center">
                <div class="grid--cell">
                    <input class="s-radio d-block"
                           type="radio"
                           name="tagModeId"
                           value="Specified"
                           checked="checked"
                           id="5e54c2ac-3957-4105-a8de-f5ce63bace67" />
                </div>
                <label class="grid--cell s-label fw-normal ws-nowrap" for="5e54c2ac-3957-4105-a8de-f5ce63bace67">The following tags:</label>
            </div>
        </div>

                            </fieldset>
                            <div class="ps-relative ml24 mt8 ws2">
                                <input id="uql-modal-tag-input" class="w100 s-input" name="tagQuery" data-target="se-uql.tagQuery" type="text" size="60" tabindex="0" placeholder="e.g. javascript or java" value="laravel&#x2B;vue.js">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p12 bt bc-black-3">
                    <div class="grid">
                        <div class="grid gs4 gsx fl1">
                            <button class="s-btn s-btn__sm s-btn__primary grid--cell" type="submit" data-target="se-uql.applyButton">Apply filter</button>
                        </div>
                        <div class="grid--cell">
                            <button class="s-btn s-btn__sm" data-action="se-uql#cancelEditor" type="button">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

</div>


        <div id="questions" class="flush-left">
<div class="question-summary" id="question-summary-54126343">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>131</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>14</strong>answers
            </div>
        </div>
        <div class="views supernova" title="162,021 views">
    162k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/54126343/how-to-fix-unchecked-runtime-lasterror-the-message-port-closed-before-a-respon" class="question-hyperlink">How to fix &#39;Unchecked runtime.lastError: The message port closed before a response was received&#39; chrome issue?</a></h3>
        <div class="excerpt">
            I'm using VueJS and Laravel for my project. This issue started to show lately and it shows even in the old git branches.

This error only shows in Chrome browser.
        </div>
        <div class="tags t-laravel t-google-chrome t-vueûjs">
            <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/google-chrome" class="post-tag" title="show questions tagged &#39;google-chrome&#39;" rel="tag">google-chrome</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2019-01-10 10:12:32Z" class="relativetime">Jan 10 '19 at 10:12</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/8124531/triumf-maqedonci"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/98a77d73bd431a8b6f638a25455af870?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/8124531/triumf-maqedonci">Triumf Maqedonci</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1,498</span><span title="2 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 gold badges</span><span title="6 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">6</span></span><span class="v-visible-sr">6 silver badges</span><span title="16 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">16</span></span><span class="v-visible-sr">16 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-45000510">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>60</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>8</strong>answers
            </div>
        </div>
        <div class="views hot" title="75,519 views">
    76k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/45000510/vue-js-error-component-template-should-contain-exactly-one-root-element" class="question-hyperlink">Vue js error: Component template should contain exactly one root element</a></h3>
        <div class="excerpt">
            I don't know what the error is, so far I am testing through console log to check for changes after selecting a file (for uploading).

When I run $ npm run watch, i get the following error:
  "Webpack ...
        </div>
        <div class="tags t-javascript t-nodeûjs t-laravel t-vueûjs">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/node.js" class="post-tag" title="show questions tagged &#39;node.js&#39;" rel="tag">node.js</a> <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2017-07-09 20:04:17Z" class="relativetime">Jul 9 '17 at 20:04</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/1883256/pathros"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/uZVmH.png?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/1883256/pathros">Pathros</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">5,763</span><span title="9 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">9</span></span><span class="v-visible-sr">9 gold badges</span><span title="58 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">58</span></span><span class="v-visible-sr">58 silver badges</span><span title="93 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">93</span></span><span class="v-visible-sr">93 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-52873516">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>53</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered">
                <strong>11</strong>answers
            </div>
        </div>
        <div class="views hot" title="48,527 views">
    49k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/52873516/vue-js-returns-ob-observer-data-instead-of-my-array-of-objects" class="question-hyperlink">Vue JS returns [__ob__: Observer] data instead of my array of objects</a></h3>
        <div class="excerpt">
            I've created a page where I want to get all my data from the database with an API call, but I'm kinda new to VueJS and Javascript aswell and I don't know where I'm getting it wrong. I did test it with ...
        </div>
        <div class="tags t-javascript t-arrays t-laravel t-vueûjs t-axios">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/arrays" class="post-tag" title="show questions tagged &#39;arrays&#39;" rel="tag">arrays</a> <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/axios" class="post-tag" title="show questions tagged &#39;axios&#39;" rel="tag">axios</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2018-10-18 12:00:37Z" class="relativetime">Oct 18 '18 at 12:00</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/10424119/shawnest"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/9387389a80c90ffb1d2353f78696bb92?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/10424119/shawnest">shawnest</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">529</span><span title="1 gold badge" aria-hidden="true"><span class="badge1"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 gold badge</span><span title="3 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">3</span></span><span class="v-visible-sr">3 silver badges</span><span title="8 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">8</span></span><span class="v-visible-sr">8 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-36671106">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>33</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>3</strong>answers
            </div>
        </div>
        <div class="views hot" title="42,511 views">
    43k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/36671106/what-is-the-difference-between-vm-set-and-vue-set" class="question-hyperlink">What is the difference between vm.$set and Vue.set?</a></h3>
        <div class="excerpt">
            I have carefully read and re-read the Vue docs "Reactivity in Depth" and the API for vm.$set and Vue.set but I am still having a difficult time determining when to use which.  It is important for me ...
        </div>
        <div class="tags t-javascript t-laravel t-vueûjs">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2016-04-16 23:46:34Z" class="relativetime">Apr 16 '16 at 23:46</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/3089840/user3089840"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/BSs2k.png?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/3089840/user3089840">user3089840</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">2,785</span><span title="3 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">3</span></span><span class="v-visible-sr">3 gold badges</span><span title="22 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">22</span></span><span class="v-visible-sr">22 silver badges</span><span title="42 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">42</span></span><span class="v-visible-sr">42 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-37078423">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>32</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>8</strong>answers
            </div>
        </div>
        <div class="views hot" title="26,481 views">
    26k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/37078423/how-can-add-bootstrap-tooltip-inside-vue-js" class="question-hyperlink">How can add bootstrap tooltip inside Vue.js</a></h3>
        <div class="excerpt">
            I have a page for listing data from table using Vue.js and Laravel. Listing data is successful. Delete and edit function is going on. For that purpose I have added two &lt;span&gt; (glyphicon-pencil), ...
        </div>
        <div class="tags t-twitter-bootstrap t-laravel t-vueûjs">
            <a href="/questions/tagged/twitter-bootstrap" class="post-tag" title="show questions tagged &#39;twitter-bootstrap&#39;" rel="tag">twitter-bootstrap</a> <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2016-05-06 17:41:23Z" class="relativetime">May 6 '16 at 17:41</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/4113530/sarath-ts"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/fb19de8e3813d1fcb5593c1fa98087b0?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/4113530/sarath-ts">Sarath TS</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">2,177</span><span title="3 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">3</span></span><span class="v-visible-sr">3 gold badges</span><span title="20 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">20</span></span><span class="v-visible-sr">20 silver badges</span><span title="51 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">51</span></span><span class="v-visible-sr">51 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-39938284">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>27</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>5</strong>answers
            </div>
        </div>
        <div class="views hot" title="34,498 views">
    34k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/39938284/how-to-pass-laravel-csrf-token-value-to-vue" class="question-hyperlink">How to pass laravel CSRF token value to vue</a></h3>
        <div class="excerpt">
            I have this form where the user should only type text inside a text area:

            &lt;form action="#" v-on:submit="postStatus"&gt;{{-- Name of the method in Vue.js --}}
                &lt;div ...
        </div>
        <div class="tags t-laravel t-vueûjs t-laravel-5û3">
            <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/laravel-5.3" class="post-tag" title="show questions tagged &#39;laravel-5.3&#39;" rel="tag">laravel-5.3</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2016-10-08 23:04:12Z" class="relativetime">Oct 8 '16 at 23:04</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/1883256/pathros"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/uZVmH.png?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/1883256/pathros">Pathros</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">5,763</span><span title="9 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">9</span></span><span class="v-visible-sr">9 gold badges</span><span title="58 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">58</span></span><span class="v-visible-sr">58 silver badges</span><span title="93 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">93</span></span><span class="v-visible-sr">93 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-50020026">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>26</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>3</strong>answers
            </div>
        </div>
        <div class="views warm" title="5,224 views">
    5k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/50020026/what-is-the-best-vue-router-practice-for-very-large-webapplications" class="question-hyperlink">What is the best Vue-Router practice for very large webapplications?</a></h3>
        <div class="excerpt">
            I have to make a webapplication with many different modules (like a todo-module, document-modules, and a big usermanagement-module for admin users). The total number of pages is > 100. And the module ...
        </div>
        <div class="tags t-laravel t-vueûjs t-single-page-application t-vue-router">
            <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/single-page-application" class="post-tag" title="show questions tagged &#39;single-page-application&#39;" rel="tag">single-page-application</a> <a href="/questions/tagged/vue-router" class="post-tag" title="show questions tagged &#39;vue-router&#39;" rel="tag">vue-router</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2018-04-25 10:33:21Z" class="relativetime">Apr 25 '18 at 10:33</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/3310748/angelique000"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/lS92I.jpg?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/3310748/angelique000">angelique000</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">717</span><span title="1 gold badge" aria-hidden="true"><span class="badge1"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 gold badge</span><span title="8 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">8</span></span><span class="v-visible-sr">8 silver badges</span><span title="21 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">21</span></span><span class="v-visible-sr">21 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-41520258">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>25</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>4</strong>answers
            </div>
        </div>
        <div class="views hot" title="41,240 views">
    41k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/41520258/how-to-pass-a-php-variable-to-vue-component-instance-in-laravel-blade" class="question-hyperlink">How to pass a PHP variable to Vue component instance in Laravel blade?</a></h3>
        <div class="excerpt">
            How can I pass a value of a PHP variable to a Vue component in Laravel blade files?

In my example, I have an inline template client-details, I get this view from Laravel so now I want to pass the id ...
        </div>
        <div class="tags t-php t-laravel t-vueûjs t-vuejs2">
            <a href="/questions/tagged/php" class="post-tag" title="show questions tagged &#39;php&#39;" rel="tag">php</a> <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/vuejs2" class="post-tag" title="show questions tagged &#39;vuejs2&#39;" rel="tag">vuejs2</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2017-01-07 10:12:43Z" class="relativetime">Jan 7 '17 at 10:12</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/4153552/mastercheef85"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/fe54eafa5a32dc0f37be16248fc29703?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/4153552/mastercheef85">mastercheef85</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1,047</span><span title="2 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 gold badges</span><span title="12 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">12</span></span><span class="v-visible-sr">12 silver badges</span><span title="20 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">20</span></span><span class="v-visible-sr">20 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-46404051">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>24</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>1</strong>answer
            </div>
        </div>
        <div class="views hot" title="44,328 views">
    44k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/46404051/send-object-with-axios-get-request" class="question-hyperlink">Send object with axios get request [duplicate]</a></h3>
        <div class="excerpt">
            I want to send a get request with an object. The object data will be used on the server to update session data. But the object doesn't seem to be sent correctly, because if I try to send it back to ...
        </div>
        <div class="tags t-laravel t-vueûjs t-axios">
            <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/axios" class="post-tag" title="show questions tagged &#39;axios&#39;" rel="tag">axios</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2017-09-25 11:23:46Z" class="relativetime">Sep 25 '17 at 11:23</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/4245985/galivan"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/vBl1E.jpg?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/4245985/galivan">Galivan</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">2,389</span><span title="4 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">4</span></span><span class="v-visible-sr">4 gold badges</span><span title="19 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">19</span></span><span class="v-visible-sr">19 silver badges</span><span title="39 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">39</span></span><span class="v-visible-sr">39 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-34748981">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>23</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>7</strong>answers
            </div>
        </div>
        <div class="views hot" title="41,216 views">
    41k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/34748981/laravel-5-2-cors-get-not-working-with-preflight-options" class="question-hyperlink">Laravel 5.2 CORS, GET not working with preflight OPTIONS</a></h3>
        <div class="excerpt">
            The dreaded CORS Error:
  Cross-Origin Request Blocked: The Same Origin Policy disallows reading
  the remote resource at http://localhost/mysite/api/test. (Reason: CORS
  header 'Access-Control-...
        </div>
        <div class="tags t-php t-laravel t-cors t-vueûjs t-laravel-5û2">
            <a href="/questions/tagged/php" class="post-tag" title="show questions tagged &#39;php&#39;" rel="tag">php</a> <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/cors" class="post-tag" title="show questions tagged &#39;cors&#39;" rel="tag">cors</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/laravel-5.2" class="post-tag" title="show questions tagged &#39;laravel-5.2&#39;" rel="tag">laravel-5.2</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2016-01-12 16:34:15Z" class="relativetime">Jan 12 '16 at 16:34</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/2011685/suncoastkid"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/k4gAz.jpg?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/2011685/suncoastkid">suncoastkid</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">1,996</span><span title="6 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">6</span></span><span class="v-visible-sr">6 gold badges</span><span title="20 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">20</span></span><span class="v-visible-sr">20 silver badges</span><span title="44 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">44</span></span><span class="v-visible-sr">44 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-44193822">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>22</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>2</strong>answers
            </div>
        </div>
        <div class="views hot" title="24,181 views">
    24k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/44193822/cannot-use-v-for-on-stateful-component-root-element-because-it-renders-multiple" class="question-hyperlink">Cannot use v-for on stateful component root element because it renders multiple elements?</a></h3>
        <div class="excerpt">
            app.js

var Users = {
    template: `
        &lt;tr v-for="list in UsersData"&gt;
            &lt;th&gt;{{ list.idx }}&lt;/th&gt;
            &lt;td&gt;{{ list.id }}&lt;/td&gt;
        &lt;/tr&gt;
   ...
        </div>
        <div class="tags t-laravel t-vueûjs t-components t-blade">
            <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/components" class="post-tag" title="show questions tagged &#39;components&#39;" rel="tag">components</a> <a href="/questions/tagged/blade" class="post-tag" title="show questions tagged &#39;blade&#39;" rel="tag">blade</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2017-05-26 04:48:34Z" class="relativetime">May 26 '17 at 4:48</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/5789372/ofleaf"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/WMtlt.png?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/5789372/ofleaf">ofleaf</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">385</span><span title="1 gold badge" aria-hidden="true"><span class="badge1"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 gold badge</span><span title="2 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">2</span></span><span class="v-visible-sr">2 silver badges</span><span title="15 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">15</span></span><span class="v-visible-sr">15 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-39708680">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>21</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered">
                <strong>3</strong>answers
            </div>
        </div>
        <div class="views hot" title="10,521 views">
    11k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/39708680/using-vue-js-in-laravel-5-3" class="question-hyperlink">Using Vue.js in Laravel 5.3</a></h3>
        <div class="excerpt">
            In Laravel projects prior to 5.3 I've utilised Vue.js using the script tag like this:

&lt;script type="text/javascript" src="../js/vue.js"&gt;&lt;/script&gt;
I would then create a Vue instance ...
        </div>
        <div class="tags t-javascript t-laravel t-vueûjs t-laravel-5û3">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/laravel-5.3" class="post-tag" title="show questions tagged &#39;laravel-5.3&#39;" rel="tag">laravel-5.3</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2016-09-26 17:16:14Z" class="relativetime">Sep 26 '16 at 17:16</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/648247/haakym"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/bf79700fcc3d2438d7893cb3b06fdb06?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/648247/haakym">haakym</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">9,054</span><span title="10 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">10</span></span><span class="v-visible-sr">10 gold badges</span><span title="49 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">49</span></span><span class="v-visible-sr">49 silver badges</span><span title="84 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">84</span></span><span class="v-visible-sr">84 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-52734396">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>21</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered">
                <strong>4</strong>answers
            </div>
        </div>
        <div class="views " title="685 views">
    685 views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/52734396/best-way-for-managing-uploaded-files-in-my-editor" class="question-hyperlink">best way for managing uploaded files in my editor?</a></h3>
        <div class="excerpt">
            I'm working on a social blog that has an editor built in JavaScript for creating a blog by a user. One of my biggest issues is uploading files and its limitations. Right now for auto-saving user posts,...
        </div>
        <div class="tags t-php t-laravel t-vueûjs t-ckeditor">
            <a href="/questions/tagged/php" class="post-tag" title="show questions tagged &#39;php&#39;" rel="tag">php</a> <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/ckeditor" class="post-tag" title="show questions tagged &#39;ckeditor&#39;" rel="tag">ckeditor</a> 
        </div>
        <div class="started fr">
            <div class="user-info ">
    <div class="user-action-time">
        asked <span title="2018-10-10 06:59:00Z" class="relativetime">Oct 10 '18 at 6:59</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/10024416/k90mirzaei"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/047ceb186f7a7895fbb667a825124940?s=32&amp;d=identicon&amp;r=PG&amp;f=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/10024416/k90mirzaei">k90mirzaei</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">264</span><span title="1 silver badge" aria-hidden="true"><span class="badge2"></span><span class="badgecount">1</span></span><span class="v-visible-sr">1 silver badge</span><span title="12 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">12</span></span><span class="v-visible-sr">12 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-41539961">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>20</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered-accepted">
                <strong>2</strong>answers
            </div>
        </div>
        <div class="views hot" title="16,218 views">
    16k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/41539961/vuejs-js-for-multiple-pages-not-for-a-single-page-application" class="question-hyperlink">Vuejs js for multiple pages, not for a single page application</a></h3>
        <div class="excerpt">
            I need to build an application using laravel 5.3 and vuejs 2, because I need to use two-way binding rather than use jquery. 

I need to set up the views with blade templates. Then, I need to use vuejs ...
        </div>
        <div class="tags t-laravel t-vueûjs t-laravel-5û3 t-vue-component t-vuejs2">
            <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/laravel-5.3" class="post-tag" title="show questions tagged &#39;laravel-5.3&#39;" rel="tag">laravel-5.3</a> <a href="/questions/tagged/vue-component" class="post-tag" title="show questions tagged &#39;vue-component&#39;" rel="tag">vue-component</a> <a href="/questions/tagged/vuejs2" class="post-tag" title="show questions tagged &#39;vuejs2&#39;" rel="tag">vuejs2</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2017-01-09 01:58:50Z" class="relativetime">Jan 9 '17 at 1:58</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/792690/dinuka-thilanga"><div class="gravatar-wrapper-32"><img src="https://www.gravatar.com/avatar/200844f03b5e3c2b510ce7b2fd6abdd7?s=32&amp;d=identicon&amp;r=PG" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/792690/dinuka-thilanga">Dinuka Thilanga</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">3,724</span><span title="7 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">7</span></span><span class="v-visible-sr">7 gold badges</span><span title="46 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">46</span></span><span class="v-visible-sr">46 silver badges</span><span title="86 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">86</span></span><span class="v-visible-sr">86 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div><div class="question-summary" id="question-summary-48240582">
    <div class="statscontainer">
        <div class="stats">
            <div class="vote">
                <div class="votes">
                    <span class="vote-count-post "><strong>20</strong></span>
                    <div class="viewcount">votes</div>
                </div>
            </div>
            <div class="status answered">
                <strong>2</strong>answers
            </div>
        </div>
        <div class="views hot" title="16,628 views">
    17k views
</div>
    </div>
    <div class="summary">
        <h3><a href="/questions/48240582/vue-js-best-way-to-implement-mpamulti-page-app-in-laravel" class="question-hyperlink">Vue.js : Best way to implement MPA(Multi page app) in laravel</a></h3>
        <div class="excerpt">
            I have been looking around for quite a time, But didn't got anything convening. 

What will be the best approach and practice to implement Vue MPA architecture in laravel.

Searched for quite a bit. ...
        </div>
        <div class="tags t-javascript t-laravel t-design-patterns t-vueûjs t-multipage">
            <a href="/questions/tagged/javascript" class="post-tag" title="show questions tagged &#39;javascript&#39;" rel="tag">javascript</a> <a href="/questions/tagged/laravel" class="post-tag" title="show questions tagged &#39;laravel&#39;" rel="tag">laravel</a> <a href="/questions/tagged/design-patterns" class="post-tag" title="show questions tagged &#39;design-patterns&#39;" rel="tag">design-patterns</a> <a href="/questions/tagged/vue.js" class="post-tag" title="show questions tagged &#39;vue.js&#39;" rel="tag">vue.js</a> <a href="/questions/tagged/multipage" class="post-tag" title="show questions tagged &#39;multipage&#39;" rel="tag">multipage</a> 
        </div>
        <div class="started fr">
            <div class="user-info user-hover">
    <div class="user-action-time">
        asked <span title="2018-01-13 14:00:24Z" class="relativetime">Jan 13 '18 at 14:00</span>
    </div>
    <div class="user-gravatar32">
        <a href="/users/4866624/gammer"><div class="gravatar-wrapper-32"><img src="https://i.stack.imgur.com/M6I2w.gif?s=32&amp;g=1" alt="" width="32" height="32" class="bar-sm"></div></a>
    </div>
    <div class="user-details">
        <a href="/users/4866624/gammer">Gammer</a>
        <div class="-flair">
            <span class="reputation-score" title="reputation score " dir="ltr">4,395</span><span title="12 gold badges" aria-hidden="true"><span class="badge1"></span><span class="badgecount">12</span></span><span class="v-visible-sr">12 gold badges</span><span title="44 silver badges" aria-hidden="true"><span class="badge2"></span><span class="badgecount">44</span></span><span class="v-visible-sr">44 silver badges</span><span title="93 bronze badges" aria-hidden="true"><span class="badge3"></span><span class="badgecount">93</span></span><span class="v-visible-sr">93 bronze badges</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div>        </div>

        <br class="cbt" />
<div class="s-pagination page-sizer fr">
  <a href="/questions/tagged/laravel%2bvue.js?tab=votes&amp;pagesize=15" title="Show 15 items per page" class="s-pagination--item is-selected">15</a>
  <a href="/questions/tagged/laravel%2bvue.js?tab=votes&amp;pagesize=30" title="Show 30 items per page" class="s-pagination--item">30</a>
  <a href="/questions/tagged/laravel%2bvue.js?tab=votes&amp;pagesize=50" title="Show 50 items per page" class="s-pagination--item">50</a>
  <span class="s-pagination--item s-pagination--item__clear">per page</span>
</div>
<div class="s-pagination pager fl">
<div class="s-pagination--item is-selected">1</div>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/laravel%2bvue.js?tab=votes&page=2&pagesize=15" rel="" title="Go to page 2">2</a>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/laravel%2bvue.js?tab=votes&page=3&pagesize=15" rel="" title="Go to page 3">3</a>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/laravel%2bvue.js?tab=votes&page=4&pagesize=15" rel="" title="Go to page 4">4</a>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/laravel%2bvue.js?tab=votes&page=5&pagesize=15" rel="" title="Go to page 5">5</a>
<div class="s-pagination--item s-pagination--item__clear">…</div>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/laravel%2bvue.js?tab=votes&page=319&pagesize=15" rel="" title="Go to page 319">319</a>
<a class="s-pagination--item js-pagination-item" href="/questions/tagged/laravel%2bvue.js?tab=votes&page=2&pagesize=15" rel="next" title="Go to page 2"> Next</a></div>
    </div>
    <div id="sidebar">
        
<div class="s-sidebarwidget s-sidebarwidget__yellow s-anchors s-anchors__grayscale mb16" data-tracker="cb=1">
    <ul class="d-block p0 m0">
                    <div class="s-sidebarwidget--header s-sidebarwidget__small-bold-text fc-light d:fc-black-900 bb bbw1">
                        The Overflow Blog
                    </div>
        <li class="s-sidebarwidget--item grid px16">
            <div class="grid--cell1 fl-shrink0">
<svg aria-hidden="true" class="va-text-top svg-icon iconPencilSm" width="14" height="14" viewBox="0 0 14 14"><path d="M11.1 1.71l1.13 1.12c.2.2.2.51 0 .71L11.1 4.7 9.21 2.86l1.17-1.15c.2-.2.51-.2.71 0zM2 10.12l6.37-6.43 1.88 1.88L3.88 12H2v-1.88z"/></svg>            </div>
            <div class="grid--cell">
                <a href="https://stackoverflow.blog/2020/07/08/improving-performance-with-simd-intrinsics-in-three-use-cases/" class="js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;The Overflow Blog&quot;,&quot;https://stackoverflow.blog/2020/07/08/improving-performance-with-simd-intrinsics-in-three-use-cases/&quot;,null,null]" data-gps-track="communitybulletin.click({ priority: 1, position: 0 })">Improving performance with SIMD intrinsics in three use cases</a>
            </div>
        </li>
                    <div class="s-sidebarwidget--header s-sidebarwidget__small-bold-text fc-light d:fc-black-900 bb bbw1">
                        Upcoming Events
                    </div>
    <li class="s-sidebarwidget--item grid px16">
        <div class="grid--cell1 fl-shrink0">
            <div class="favicon favicon-stackoverflow" title="Stack Overflow"></div>
        </div>
        <div class="grid--cell">
            <a href="https://stackoverflow.com/election" class="fc-danger js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;Upcoming Events&quot;,&quot;https://stackoverflow.com/election&quot;,null,null]"  data-gps-track="communitybulletin.click({ priority: 5, position: 1 })">2020 Community Moderator Election</a>
            <div>ends <span title="2020-07-21 20:00:00Z">Jul 21</span></div>
        </div>
    </li>
                    <div class="s-sidebarwidget--header s-sidebarwidget__small-bold-text fc-light d:fc-black-900 bb bbw1">
                        Featured on Meta
                    </div>
        <li class="s-sidebarwidget--item grid px16">
            <div class="grid--cell1 fl-shrink0">
<div class="favicon favicon-stackexchangemeta" title="Meta Stack Exchange"></div>            </div>
            <div class="grid--cell">
                <a href="https://meta.stackexchange.com/questions/349276/new-post-lock-available-on-meta-sites-policy-lock" class="js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;Featured on Meta&quot;,&quot;https://meta.stackexchange.com/questions/349276/new-post-lock-available-on-meta-sites-policy-lock&quot;,null,null]" data-gps-track="communitybulletin.click({ priority: 3, position: 2 })">New post lock available on meta sites: Policy Lock</a>
            </div>
        </li>
        <li class="s-sidebarwidget--item grid px16">
            <div class="grid--cell1 fl-shrink0">
<div class="favicon favicon-stackexchangemeta" title="Meta Stack Exchange"></div>            </div>
            <div class="grid--cell">
                <a href="https://meta.stackexchange.com/questions/350184/feedback-post-new-moderator-reinstatement-and-appeal-process-revisions" class="js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;Featured on Meta&quot;,&quot;https://meta.stackexchange.com/questions/350184/feedback-post-new-moderator-reinstatement-and-appeal-process-revisions&quot;,null,null]" data-gps-track="communitybulletin.click({ priority: 3, position: 3 })">Feedback post: New moderator reinstatement and appeal process revisions</a>
            </div>
        </li>
        <li class="s-sidebarwidget--item grid px16">
            <div class="grid--cell1 fl-shrink0">
<div class="favicon favicon-stackoverflowmeta" title="Meta Stack Overflow"></div>            </div>
            <div class="grid--cell">
                <a href="https://meta.stackoverflow.com/questions/398909/data-validation-background-for-the-thank-you-reaction-feature-test" class="js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;Featured on Meta&quot;,&quot;https://meta.stackoverflow.com/questions/398909/data-validation-background-for-the-thank-you-reaction-feature-test&quot;,null,null]" data-gps-track="communitybulletin.click({ priority: 6, position: 4 })">Data validation &amp; background for the Thank You Reaction feature test</a>
            </div>
        </li>
        <li class="s-sidebarwidget--item grid px16">
            <div class="grid--cell1 fl-shrink0">
<div class="favicon favicon-stackoverflowmeta" title="Meta Stack Overflow"></div>            </div>
            <div class="grid--cell">
                <a href="https://meta.stackoverflow.com/questions/399106/2020-community-moderator-election-questionnaire" class="js-gps-track" data-ga="[&quot;community bulletin board&quot;,&quot;Featured on Meta&quot;,&quot;https://meta.stackoverflow.com/questions/399106/2020-community-moderator-election-questionnaire&quot;,null,null]" data-gps-track="communitybulletin.click({ priority: 6, position: 5 })">2020 Community Moderator Election - Questionnaire</a>
            </div>
        </li>
    </ul>
</div>


<div id="dfp-tsb" class="everyonelovesstackoverflow everyoneloves__top-sidebar mb8"></div>
<div id="dfp-msb" class="everyonelovesstackoverflow everyoneloves__mid-sidebar mb8"></div>
<div id="hireme"></div>            <div class="module js-gps-related-tags">
                <h4 id="h-related-tags">Related Tags</h4>
        <div data-name="javascript">
            <a href="/questions/tagged/laravel+vue.js+javascript" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js javascript&#39;" rel="tag">javascript</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">1202</span></span>
        </div>
        <div data-name="php">
            <a href="/questions/tagged/laravel+vue.js+php" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js php&#39;" rel="tag">php</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">994</span></span>
        </div>
        <div data-name="vuejs2">
            <a href="/questions/tagged/laravel+vue.js+vuejs2" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js vuejs2&#39;" rel="tag">vuejs2</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">575</span></span>
        </div>
        <div data-name="axios">
            <a href="/questions/tagged/laravel+vue.js+axios" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js axios&#39;" rel="tag">axios</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">434</span></span>
        </div>
        <div data-name="laravel-5">
            <a href="/questions/tagged/laravel+vue.js+laravel-5" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js laravel-5&#39;" rel="tag">laravel-5</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">410</span></span>
        </div>
        <div data-name="vue-component">
            <a href="/questions/tagged/laravel+vue.js+vue-component" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js vue-component&#39;" rel="tag">vue-component</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">276</span></span>
        </div>
        <div data-name="vue-router">
            <a href="/questions/tagged/laravel+vue.js+vue-router" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js vue-router&#39;" rel="tag">vue-router</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">162</span></span>
        </div>
        <div data-name="laravel-blade">
            <a href="/questions/tagged/laravel+vue.js+laravel-blade" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js laravel-blade&#39;" rel="tag">laravel-blade</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">128</span></span>
        </div>
        <div data-name="webpack">
            <a href="/questions/tagged/laravel+vue.js+webpack" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js webpack&#39;" rel="tag">webpack</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">114</span></span>
        </div>
        <div data-name="vuex">
            <a href="/questions/tagged/laravel+vue.js+vuex" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js vuex&#39;" rel="tag">vuex</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">93</span></span>
        </div>
        <div class="dno js-hidden" data-name="laravel-mix">
            <a href="/questions/tagged/laravel+vue.js+laravel-mix" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js laravel-mix&#39;" rel="tag">laravel-mix</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">89</span></span>
        </div>
        <div class="dno js-hidden" data-name="npm">
            <a href="/questions/tagged/laravel+vue.js+npm" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js npm&#39;" rel="tag">npm</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">84</span></span>
        </div>
        <div class="dno js-hidden" data-name="api">
            <a href="/questions/tagged/laravel+vue.js+api" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js api&#39;" rel="tag">api</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">82</span></span>
        </div>
        <div class="dno js-hidden" data-name="single-page-application">
            <a href="/questions/tagged/laravel+vue.js+single-page-application" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js single-page-application&#39;" rel="tag">single-page-application</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">78</span></span>
        </div>
        <div class="dno js-hidden" data-name="vuetify.js">
            <a href="/questions/tagged/laravel+vue.js+vuetify.js" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js vuetify.js&#39;" rel="tag">vuetify.js</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">77</span></span>
        </div>
        <div class="dno js-hidden" data-name="html">
            <a href="/questions/tagged/laravel+vue.js+html" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js html&#39;" rel="tag">html</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">75</span></span>
        </div>
        <div class="dno js-hidden" data-name="pusher">
            <a href="/questions/tagged/laravel+vue.js+pusher" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js pusher&#39;" rel="tag">pusher</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">74</span></span>
        </div>
        <div class="dno js-hidden" data-name="ajax">
            <a href="/questions/tagged/laravel+vue.js+ajax" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js ajax&#39;" rel="tag">ajax</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">72</span></span>
        </div>
        <div class="dno js-hidden" data-name="jquery">
            <a href="/questions/tagged/laravel+vue.js+jquery" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js jquery&#39;" rel="tag">jquery</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">70</span></span>
        </div>
        <div class="dno js-hidden" data-name="json">
            <a href="/questions/tagged/laravel+vue.js+json" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js json&#39;" rel="tag">json</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">62</span></span>
        </div>
        <div class="dno js-hidden" data-name="laravel-passport">
            <a href="/questions/tagged/laravel+vue.js+laravel-passport" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js laravel-passport&#39;" rel="tag">laravel-passport</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">59</span></span>
        </div>
        <div class="dno js-hidden" data-name="mysql">
            <a href="/questions/tagged/laravel+vue.js+mysql" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js mysql&#39;" rel="tag">mysql</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">57</span></span>
        </div>
        <div class="dno js-hidden" data-name="node.js">
            <a href="/questions/tagged/laravel+vue.js+node.js" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js node.js&#39;" rel="tag">node.js</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">57</span></span>
        </div>
        <div class="dno js-hidden" data-name="eloquent">
            <a href="/questions/tagged/laravel+vue.js+eloquent" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js eloquent&#39;" rel="tag">eloquent</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">54</span></span>
        </div>
        <div class="dno js-hidden" data-name="laravel-echo">
            <a href="/questions/tagged/laravel+vue.js+laravel-echo" class="post-tag no-tag-menu" title="show questions tagged &#39;laravel vue.js laravel-echo&#39;" rel="tag">laravel-echo</a>&nbsp;<span class="item-multiplier"><span class="item-multiplier-x">&times;</span>&nbsp;<span class="item-multiplier-count">49</span></span>
        </div>
        <a href="#"
           class="show-more js-show-more js-gps-track"
           data-gps-track="related_tags.click({ item_type:2 })">
            more related tags
        </a>
        <script>
            StackExchange.ready(function () {
                var $div = $('#h-related-tags').parent();
                $div.find('.js-show-more').click(function () {
                    $div.find('.js-hidden').show();
                    $(this).remove();
                    return false;
                });
            });
        </script>

            </div>

        <div id="hot-network-questions" class="module tex2jax_ignore">
    <h4>
        <a href="https://stackexchange.com/questions?tab=hot"
           class="js-gps-track s-link s-link__inherit" 
           data-gps-track="posts_hot_network.click({ item_type:1, location:9 })">
            Hot Network Questions
        </a>
    </h4>
    <ul>
            <li >
                <div class="favicon favicon-retrocomputing" title="Retrocomputing Stack Exchange"></div><a href="https://retrocomputing.stackexchange.com/questions/15516/when-ibm-started-to-use-ascii" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:648 }); posts_hot_network.click({ item_type:2, location:9 })">
                    When IBM started to use ASCII
                </a>

            </li>
            <li >
                <div class="favicon favicon-politics" title="Politics Stack Exchange"></div><a href="https://politics.stackexchange.com/questions/54407/whats-the-difference-between-paying-someone-to-kill-another-countrys-soldiers" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:475 }); posts_hot_network.click({ item_type:2, location:9 })">
                    What&#x27;s the difference between paying someone to kill another country&#x27;s soldiers, and arming that someone to kill another country&#x27;s soldiers?
                </a>

            </li>
            <li >
                <div class="favicon favicon-movies" title="Movies &amp; TV Stack Exchange"></div><a href="https://movies.stackexchange.com/questions/109899/can-there-be-sunlight-in-australia-and-texas-at-the-same-time" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:367 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Can there be sunlight in Australia and Texas at the same time?
                </a>

            </li>
            <li >
                <div class="favicon favicon-academia" title="Academia Stack Exchange"></div><a href="https://academia.stackexchange.com/questions/151426/i-ghosted-my-previous-supervisor-for-15-days-how-to-improve-my-situation" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:415 }); posts_hot_network.click({ item_type:2, location:9 })">
                    I ghosted my previous supervisor for 15 days. How to improve my situation?
                </a>

            </li>
            <li >
                <div class="favicon favicon-workplace" title="The Workplace Stack Exchange"></div><a href="https://workplace.stackexchange.com/questions/160063/employees-quitting-soon-after-being-denied-promotion-raise" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:423 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Employees quitting soon after being denied promotion/raise
                </a>

            </li>
            <li >
                <div class="favicon favicon-crypto" title="Cryptography Stack Exchange"></div><a href="https://crypto.stackexchange.com/questions/81799/i-do-many-searches-but-cant-find-any-explanation-about-aes-analysis-using-entr" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:281 }); posts_hot_network.click({ item_type:2, location:9 })">
                    I do many searches but can&#x27;t find any explanation about &quot;AES analysis using entropy&quot;
                </a>

            </li>
            <li >
                <div class="favicon favicon-worldbuilding" title="Worldbuilding Stack Exchange"></div><a href="https://worldbuilding.stackexchange.com/questions/180071/if-guns-had-a-50-chance-of-lethally-backfiring-what-would-they-be-used-for" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:579 }); posts_hot_network.click({ item_type:2, location:9 })">
                    If guns had a 50% chance of lethally backfiring, what would they be used for?
                </a>

            </li>
            <li >
                <div class="favicon favicon-parenting" title="Parenting Stack Exchange"></div><a href="https://parenting.stackexchange.com/questions/40165/is-placing-my-child-in-the-same-class-as-a-close-cousin-a-bad-idea" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:228 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Is placing my child in the same class as a close cousin a bad idea?
                </a>

            </li>
            <li >
                <div class="favicon favicon-music" title="Music: Practice &amp; Theory Stack Exchange"></div><a href="https://music.stackexchange.com/questions/101626/does-roman-numerals-for-a-chord-progressions-change-capitalization-when-played-i" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:240 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Does Roman Numerals for a chord progressions change capitalization when played in a different key than the original?
                </a>

            </li>
            <li >
                <div class="favicon favicon-politics" title="Politics Stack Exchange"></div><a href="https://politics.stackexchange.com/questions/54391/is-there-mass-unemployment-in-the-usa-or-is-there-not" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:475 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Is there mass unemployment in the USA or is there not?
                </a>

            </li>
            <li >
                <div class="favicon favicon-retrocomputing" title="Retrocomputing Stack Exchange"></div><a href="https://retrocomputing.stackexchange.com/questions/15512/did-any-computer-use-a-7-bit-byte" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:648 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Did any computer use a 7-bit byte?
                </a>

            </li>
            <li >
                <div class="favicon favicon-worldbuilding" title="Worldbuilding Stack Exchange"></div><a href="https://worldbuilding.stackexchange.com/questions/180081/what-makes-supervillains-want-to-tell-their-plans-to-adversaries" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:579 }); posts_hot_network.click({ item_type:2, location:9 })">
                    What makes supervillains want to tell their plans to adversaries?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-astronomy" title="Astronomy Stack Exchange"></div><a href="https://astronomy.stackexchange.com/questions/36826/how-many-satellites-orbit-their-planet-faster-than-the-planet-rotates" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:514 }); posts_hot_network.click({ item_type:2, location:9 })">
                    How many satellites orbit their planet faster than the planet rotates?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-physics" title="Physics Stack Exchange"></div><a href="https://physics.stackexchange.com/questions/564362/can-you-create-white-light-by-combining-cyan-wavelengths-490-520nm-with-red-wa" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:151 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Can you create white light by combining cyan wavelengths (490-520nm) with red wavelengths (630-700nm)?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-superuser" title="Super User"></div><a href="https://superuser.com/questions/1566851/can-original-file-get-corrupted-during-copying" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:3 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Can original file get corrupted during copying?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-cooking" title="Seasoned Advice"></div><a href="https://cooking.stackexchange.com/questions/109493/where-does-the-green-part-of-the-scallion-start-and-the-white-part-end" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:49 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Where does the green part of the scallion start and the white part end?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-worldbuilding" title="Worldbuilding Stack Exchange"></div><a href="https://worldbuilding.stackexchange.com/questions/180099/parachutes-to-when-there-is-no-ground" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:579 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Parachutes to when there is no ground
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-blender" title="Blender Stack Exchange"></div><a href="https://blender.stackexchange.com/questions/185598/what-is-the-proper-way-to-make-this-robot-arm" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:502 }); posts_hot_network.click({ item_type:2, location:9 })">
                    What is the proper way to make this robot arm?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-academia" title="Academia Stack Exchange"></div><a href="https://academia.stackexchange.com/questions/151433/is-it-a-scientific-misconduct-to-change-a-variable-or-a-function-name-when-citin" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:415 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Is it a scientific misconduct to change a variable or a function name when citing a math paper?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-stats" title="Cross Validated"></div><a href="https://stats.stackexchange.com/questions/475837/how-can-the-square-of-an-asymptotically-normal-variable-also-be-asympotically-no" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:65 }); posts_hot_network.click({ item_type:2, location:9 })">
                    How can the square of an asymptotically normal variable also be asympotically normal?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-opensource" title="Open Source Stack Exchange"></div><a href="https://opensource.stackexchange.com/questions/10083/is-github-releases-section-safe-from-malicious-code-to-be-specific-does-the" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:619 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Is Github &quot;releases&quot; section safe from malicious code? To be specific, does the binary match the code in a restrictive way?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-literature" title="Literature Stack Exchange"></div><a href="https://literature.stackexchange.com/questions/14839/young-adult-fantasy-book-about-a-girl-with-gray-eyes-and-powers-related-to-metal" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:668 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Young adult fantasy book about a girl with gray eyes and powers related to metal
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-judaism" title="Mi Yodeya"></div><a href="https://judaism.stackexchange.com/questions/115198/may-one-memorize-large-swaths-of-tanach" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:248 }); posts_hot_network.click({ item_type:2, location:9 })">
                    May one memorize large swaths of Tanach?
                </a>

            </li>
            <li class="dno js-hidden">
                <div class="favicon favicon-mathematica" title="Mathematica Stack Exchange"></div><a href="https://mathematica.stackexchange.com/questions/225449/creating-a-list-with-thread" class="js-gps-track question-hyperlink mb0" data-gps-track="site.switch({ item_type:9, target_site:387 }); posts_hot_network.click({ item_type:2, location:9 })">
                    Creating a list with Thread
                </a>

            </li>
    </ul>

        <a href="#" 
           class="show-more js-show-more js-gps-track" 
           data-gps-track="posts_hot_network.click({ item_type:3, location:9 })">
            more hot questions
        </a>
</div>

                <div id="feed-link" class="js-feed-link">
        <a href="/feeds/tag?tagnames=laravel&#x2B;vue.js&amp;sort=votes" title="The 30 highest voted laravel vue.js questions">
            <svg aria-hidden="true" class="fc-orange-400 svg-icon iconRss" width="18" height="18" viewBox="0 0 18 18"><path d="M1 3c0-1.1.9-2 2-2h12a2 2 0 012 2v12a2 2 0 01-2 2H3a2 2 0 01-2-2V3zm14.5 12C15.5 8.1 9.9 2.5 3 2.5V5a10 10 0 0110 10h2.5zm-5 0A7.5 7.5 0 003 7.5V10a5 5 0 015 5h2.5zm-5 0A2.5 2.5 0 003 12.5V15h2.5z"/></svg>
            Highest voted laravel vue.js questions feed
        </a>
    </div>
    <aside class="s-modal js-feed-link-modal" tabindex="-1" role="dialog" aria-labelledby="feed-modal-title" aria-describedby="feed-modal-description" aria-hidden="true">
        <div class="s-modal--dialog js-modal-dialog wmx4" role="document"  data-controller="se-draggable">
            <h1 class="s-modal--header fw-bold js-first-tabbable" id="feed-modal-title" data-target="se-draggable.handle" tabindex="0">
                Subscribe to RSS
            </h1>
            <div class="grid gs4 gsy fd-column">
                <div class="grid--cell">
                    <label class="d-block s-label c-default" for="feed-url">
                        Highest voted laravel vue.js questions feed
                        <p class="s-description mt2" id="feed-modal-description">To subscribe to this RSS feed, copy and paste this URL into your RSS reader.</p>
                    </label>
                </div>
                <div class="grid ps-relative">
                    <input class="s-input" type="text" name="feed-url" id="feed-url" readonly="readonly" value="https://stackoverflow.com/feeds/tag?tagnames=laravel&#x2B;vue.js&amp;sort=votes" />
                    <svg aria-hidden="true" class="s-input-icon fc-orange-400 svg-icon iconRss" width="18" height="18" viewBox="0 0 18 18"><path d="M1 3c0-1.1.9-2 2-2h12a2 2 0 012 2v12a2 2 0 01-2 2H3a2 2 0 01-2-2V3zm14.5 12C15.5 8.1 9.9 2.5 3 2.5V5a10 10 0 0110 10h2.5zm-5 0A7.5 7.5 0 003 7.5V10a5 5 0 015 5h2.5zm-5 0A2.5 2.5 0 003 12.5V15h2.5z"/></svg>
                </div>
            </div>
            <a class="s-modal--close s-btn s-btn__muted js-modal-close js-last-tabbable" href="#" aria-label="Close">
                <svg aria-hidden="true" class="svg-icon iconClearSm" width="14" height="14" viewBox="0 0 14 14"><path d="M12 3.41L10.59 2 7 5.59 3.41 2 2 3.41 5.59 7 2 10.59 3.41 12 7 8.41 10.59 12 12 10.59 8.41 7 12 3.41z"/></svg>
            </a>
        </div>
    </aside>

    </div>

        </div>
    </div>
        
<script>;try{(function(a){function b(a){return'string'==typeof a?document.getElementById(a):a}function c(a){return a=b(a),!!a&&'none'===getComputedStyle(a).display}function d(a){return!c(a)}function e(a){return!!a}function f(a){return /^\s*$/.test(b(a).innerHTML)}function g(a){var b=a.style;b.height=b.maxHeight=b.minHeight='auto',b.display='none',[].forEach.call(a.children,g)}function h(a,b){var c;return function(){return a&&(c=a.call(b||this,arguments),a=null),c}}function i(a){var b=document.createElement('script');b.src=a,document.body.appendChild(b)}function j(a){return k([],a)}function k(a,b){return a.push=function(a){return b(),delete this.push,this.push(a)},a}function l(){try{return!new Function('return async()=>{};')}catch(a){return!0}}function m(){return'undefined'!=typeof googletag&&!!googletag.apiReady}function n(){m()||(googletag={cmd:j(A)})}function o(){var a=document.createElement('div');a.className='adsbox',a.id='clc-abd',a.style.position='absolute',a.style.pointerEvents='none',a.innerHTML='&nbsp;',document.body.appendChild(a)}function p(){return Object.keys(E.ids)}function r(a){var b=E.ids[a],c=E.slots[b];'function'==typeof c&&(c=c(a));return{path:'/'+B+'/'+D+'/'+b+'/'+C,sizes:c,zone:b}}function q(a){try{Array.isArray(clc.dfp.slotsRenderedEvents)||(clc.dfp.slotsRenderedEvents=[]),clc.dfp.slotsRenderedEvents.push(a);var b=a.slot.getSlotElementId(),c=[];b||c.push('id=0');var d=document.getElementById(b);if(!b||d?d.hasAttribute('data-clc-stalled')&&c.push('st=1'):c.push('el=0'),0!==c.length)return void F(c.join('&'));var e=r(b),f=e.zone;if(clc.collapse&&clc.collapse[f]&&a.isEmpty)return g(d),void d.setAttribute('data-clc-ready','true');if(-1!==x.dh.indexOf(a.lineItemId))g(d);else if(a.lineItemId&&(d.setAttribute('data-clc-prefilled','true'),'dfp-msb'==b)){var h=document.getElementById('hireme');g(h)}d.setAttribute('data-clc-ready','true')}catch(a){var i=document.querySelector('#dfp-tsb, #dfp-isb, #clc-tsb');i&&i.setAttribute('data-clc-ready','true'),F('e=1')}}function s(a){return!(clc.collapse&&void 0!==clc.collapse[a])||!!clc.collapse[a]}function t(a,b){'dfp-isb'===a&&b.setTargeting('Sidebar',['Inline']),'dfp-tsb'===a&&b.setTargeting('Sidebar',['Right']);var c=r(a),d=c.path,e=c.sizes,f=c.zone,g=googletag.defineSlot(d,e,a);if(s(f)){var h=!x.ll;g.setCollapseEmptyDiv(!0,h)}g.addService(b),!1}function u(b){var c=a.dfp&&a.dfp.targeting||{};'SystemDefault'===c.ProductVariant&&(window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches?c.ProductVariant='Dark':c.ProductVariant='Light'),Object.keys(c).forEach(function(a){b.setTargeting(a,c[a])})}function v(a){var g=a.map(b).filter(e);return{eligible:g.filter(f).filter(d),ineligible:g.filter(c)}}function w(b){void 0===b&&(b=p());var c=['dfp-mlb','dfp-smlb'];if(!m())return n(),void googletag.cmd.push(function(){return w(b)});var d=v(b),e=d.eligible,f=d.ineligible;if(f.forEach(g),0!==e.length){x.abd&&o(),googletag.destroySlots();var h=googletag.pubads();x.sf&&(h.setForceSafeFrame(!0),h.setSafeFrameConfig({allowOverlayExpansion:!0,allowPushExpansion:!0,sandbox:!0})),x.ll||h.enableSingleRequest(),a.sreEvent||(h.addEventListener('slotRenderEnded',q),a.sreEvent=!0),u(h);var i=e.filter(function(a){return!x.ll||0>c.indexOf(a.id)}),j=e.filter(function(a){return!!x.ll&&0<=c.indexOf(a.id)});i.forEach(function(a){t(a.id,h),a.setAttribute('data-dfp-zone','true')}),googletag.enableServices(),i.forEach(function(a){googletag.display(a.id)}),x.ll&&(h.enableLazyLoad({fetchMarginPercent:0,renderMarginPercent:0}),j.forEach(function(a){t(a.id,h),a.setAttribute('data-clc-prefilled','true')}),j.forEach(function(a){googletag.display(a.id)}))}}var x=function(a){for(var b=[],c=1;c<arguments.length;c++)b[c-1]=arguments[c];for(var d,e=0,f=b;e<f.length;e++)for(var g in d=f[e],d)a[g]=d[g];return a}({"lib":"https://cdn.sstatic.net/clc/clc.min.js?v=7dce99576e19","style":"https://cdn.sstatic.net/clc/styles/clc.min.css?v=8b21b47ef0c7","u":"https://clc.stackoverflow.com/markup.js","wa":true,"kt":2000,"tto":true,"h":"clc.stackoverflow.com","allowed":"^(((talent\\.)?stackoverflow)|(blog\\.codinghorror)|(serverfault|askubuntu)|([^\\.]+\\.stackexchange))\\.com$","wv":true,"al":false,"dh":[5171832659],"abd":true},a.options||{}),y=h(function(){var a=x.lib;l()&&(a=a.replace(/(\.min)?\.js(\?v=[0-9a-fA-F]+)?$/,'.ie$1.js$2')),i(a)}),z=a.cmd||[];Array.isArray(z)&&(0<z.length?y():k(z,y));var A=h(function(){i('https://www.googletagservices.com/tag/js/gpt.js')}),B='248424177',C=/^\/tags\//.test(location.pathname)||/^\/questions\/tagged\//.test(location.pathname)?'tag-pages':/^\/$/.test(location.pathname)||/^\/home/.test(location.pathname)?'home-page':'question-pages',D=location.hostname;var E={slots:{lb:[[728,90]],mlb:[[728,90]],smlb:[[728,90]],bmlb:[[728,90]],sb:function(a){return'dfp-tsb'===a?[[300,250],[300,600]]:[[300,250]]},"tag-sponsorship":[[730,135]],"mobile-below-question":[[320,50],[300,250]],msb:[[300,250],[300,600]]},ids:{"dfp-tlb":'lb',"dfp-mlb":'mlb',"dfp-smlb":'smlb',"dfp-bmlb":'bmlb',"dfp-tsb":'sb',"dfp-isb":'sb',"dfp-tag":'tag-sponsorship',"dfp-msb":'msb',"dfp-m-aq":'mobile-below-question',"clc-tlb":'lb',"clc-mlb":'mlb',"clc-tsb":'sb'}},F=function(a){new Image().src='https://'+x.h+'/stalled.gif?'+a};(function(){var b=x.al;b&&z.push(function(){return a.load()})})(),n(),a.dfp={load:w},a.options=x,a.cmd=z})(this.clc=this.clc||{})}catch(a){window.console.error(a)}</script>    <script>
        var clc = clc || {};
        clc.collapse = { sb: !0, 'tag-sponsorship': !0, lb:!0, mlb:!0, smlb:!0, bmlb:!0, 'mobile-below-question':!0};
        clc.options = clc.options || {};
        clc.options.sf = !0;
        clc.options.hb = !1;
        clc.options.ll = !0;
        clc.cmd = clc.cmd || [];
        clc.cmd.push(function () { window.clc_request='Aq-6uJxSI9gIAAAAAAAAAAACAAAAAQAAAAAQAAAAfGxhcmF2ZWx8dnVlLmpzfAD8q_YVdWi6-WF5'; clc.load(); });
        clc.dfp = clc.dfp || {};
        clc.dfp.targeting = {Registered:['false'],'so-tag':['laravel','vue.js'],'tag-reportable':['laravel','vue.js'],'tag-non-reportable':['laravel','vue.js']};
        var googletag = googletag || {};
        googletag.cmd = googletag.cmd || [];
        googletag.cmd.push(function () { clc.dfp.load(); });

            StackExchange.ready(function () { googletag.cmd.push(function () { StackExchange.ads.init(googletag, '/ads/report-ad', 'Report this ad') }) });
    </script>

            <footer id="footer" class="site-footer js-footer" role="contentinfo">
        <div class="site-footer--container">
                <div class="site-footer--logo">
                    
                    <a href="https://stackoverflow.com"><svg aria-hidden="true" class="native svg-icon iconLogoGlyphMd" width="32" height="37" viewBox="0 0 32 37"><path d="M26 33v-9h4v13H0V24h4v9h22z" fill="#BCBBBB"/><path d="M21.5 0l-2.7 2 9.9 13.3 2.7-2L21.5 0zM26 18.4L13.3 7.8l2.1-2.5 12.7 10.6-2.1 2.5zM9.1 15.2l15 7 1.4-3-15-7-1.4 3zm14 10.79l.68-2.95-16.1-3.35L7 23l16.1 2.99zM23 30H7v-3h16v3z" fill="#F48024"/></svg></a>
                </div>
            <nav class="site-footer--nav">
                    <div class="site-footer--col site-footer--col__visible js-footer-col" data-name="default">
                        <h5 class="-title"><a href="https://stackoverflow.com" class="js-gps-track" data-gps-track="footer.click({ location: 5, link: 15})">Stack Overflow</a></h5>
                        <ul class="-list js-primary-footer-links">
                            <li class="-item"><a href="/questions" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 16})">Questions</a></li>
                                <li class="-item"><a href="https://stackoverflow.com/jobs" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 17})">Jobs</a></li>
                                <li class="-item"><a href="https://stackoverflow.com/jobs/directory/developer-jobs" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 11})">Developer Jobs Directory</a></li>
                                     <li class="-item"><a href="https://stackoverflow.com/jobs/salary" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 28})">Salary Calculator</a></li>
                                <li class="-item"><a href="/help" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 3 })">Help</a></li>
                                <li class="-item"><a onclick='StackExchange.switchMobile("on")' class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 12 })">Mobile</a></li>
                        </ul>
                    </div>
                    <div class="site-footer--col site-footer--col__visible js-footer-col" data-name="default">
                        <h5 class="-title"><a href="https://stackoverflowbusiness.com" class="js-gps-track" data-gps-track="footer.click({ location: 5, link: 19 })">Products</a></h5>
                        <ul class="-list">
                            <li class="-item"><a href="https://stackoverflow.com/teams" class="js-gps-track -link" 
                                                 data-ga="[&quot;teams traffic&quot;,&quot;footer - site nav&quot;,&quot;stackoverflow.com/teams&quot;,null,{&quot;dimension4&quot;:&quot;teams&quot;}]"
                                                 data-gps-track="footer.click({ location: 5, link: 29 })">Teams</a></li>
                            <li class="-item"><a href="https://stackoverflow.com/talent" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 20 })">Talent</a></li>
                            <li class="-item"><a href="https://stackoverflow.com/advertising" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 21 })">Advertising</a></li>
                            <li class="-item"><a href="https://stackoverflow.com/enterprise" class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 22 })">Enterprise</a></li>
                        </ul>
                    </div>
                <div class="site-footer--col site-footer--col__visible js-footer-col" data-name="default">
                    <h5 class="-title"><a class="js-gps-track" data-gps-track="footer.click({ location: 5, link: 1 })" href="https://stackoverflow.com/company/about">Company</a></h5>
                    <ul class="-list">
                            <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 1 })" href="https://stackoverflow.com/company/about">About</a></li>
                        <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 27 })" href="https://stackoverflow.com/company/press">Press</a></li>
                            <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 9 })" href="https://stackoverflow.com/company/work-here">Work Here</a></li>
                        <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 7 })" href="https://stackoverflow.com/legal">Legal</a></li>
                        <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 8 })" href="https://stackoverflow.com/legal/privacy-policy">Privacy Policy</a></li>
                            <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link: 13 })" href="https://stackoverflow.com/company/contact">Contact Us</a></li>
                    </ul>
                </div>
                <div class="site-footer--col site-footer--categories-nav site-footer--col__visible">
                    <a href="#" class="site-footer--back js-footer-back"><svg aria-hidden="true" class="svg-icon iconArrowLeftAlt" width="18" height="18" viewBox="0 0 18 18"><path d="M10.58 16L12 14.59 6.4 9 12 3.41 10.57 2l-7 7 7 7z"/></svg></a>
                    <div>
                        <h5 class="-title"><a href="https://stackexchange.com" data-gps-track="footer.click({ location: 5, link: 30 })">Stack Exchange<br> Network</a></h5>
                        <ul class="-list">
                            <li class="-item"><a href="#" class="-link _expandable js-footer-category-trigger js-gps-track" data-gps-track="footer.click({ location: 5, link: 24 })" data-target="Technology">Technology</a></li>
                            <li class="-item"><a href="#" class="-link _expandable js-footer-category-trigger js-gps-track" data-gps-track="footer.click({ location: 5, link: 24 })" data-target="Life / Arts">Life / Arts</a></li>
                            <li class="-item"><a href="#" class="-link _expandable js-footer-category-trigger js-gps-track" data-gps-track="footer.click({ location: 5, link: 24 })" data-target="Culture / Recreation">Culture / Recreation</a></li>
                            <li class="-item"><a href="#" class="-link _expandable js-footer-category-trigger js-gps-track" data-gps-track="footer.click({ location: 5, link: 24 })" data-target="Science">Science</a></li>
                            <li class="-item"><a href="#" class="-link _expandable js-footer-category-trigger js-gps-track" data-gps-track="footer.click({ location: 5, link: 24 })" data-target="Other">Other</a></li>
                        </ul>
                    </div>
                </div>
                <div class="site-footer--categories">
                        <div class="site-footer--col site-footer--category js-footer-col" data-name="Technology">
        <ul class="-list">
                <li class="-item"><a href="https://stackoverflow.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional and enthusiast programmers">Stack Overflow</a></li>
                <li class="-item"><a href="https://serverfault.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="system and network administrators">Server Fault</a></li>
                <li class="-item"><a href="https://superuser.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="computer enthusiasts and power users">Super User</a></li>
                <li class="-item"><a href="https://webapps.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="power users of web applications">Web Applications</a></li>
                <li class="-item"><a href="https://askubuntu.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Ubuntu users and developers">Ask Ubuntu</a></li>
                <li class="-item"><a href="https://webmasters.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="pro webmasters">Webmasters</a></li>
                <li class="-item"><a href="https://gamedev.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional and independent game developers">Game Development</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://tex.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users of TeX, LaTeX, ConTeXt, and related typesetting systems">TeX - LaTeX</a></li>
                <li class="-item"><a href="https://softwareengineering.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professionals, academics, and students working within the systems development life cycle">Software Engineering</a></li>
                <li class="-item"><a href="https://unix.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users of Linux, FreeBSD and other Un*x-like operating systems">Unix &amp; Linux</a></li>
                <li class="-item"><a href="https://apple.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="power users of Apple hardware and software">Ask Different (Apple)</a></li>
                <li class="-item"><a href="https://wordpress.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="WordPress developers and administrators">WordPress Development</a></li>
                <li class="-item"><a href="https://gis.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="cartographers, geographers and GIS professionals">Geographic Information Systems</a></li>
                <li class="-item"><a href="https://electronics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="electronics and electrical engineering professionals, students, and enthusiasts">Electrical Engineering</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://android.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="enthusiasts and power users of the Android operating system">Android Enthusiasts</a></li>
                <li class="-item"><a href="https://security.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="information security professionals">Information Security</a></li>
                <li class="-item"><a href="https://dba.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="database professionals who wish to improve their database skills and learn from others in the community">Database Administrators</a></li>
                <li class="-item"><a href="https://drupal.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Drupal developers and administrators">Drupal Answers</a></li>
                <li class="-item"><a href="https://sharepoint.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="SharePoint enthusiasts">SharePoint</a></li>
                <li class="-item"><a href="https://ux.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="user experience researchers and experts">User Experience</a></li>
                <li class="-item"><a href="https://mathematica.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users of Wolfram Mathematica">Mathematica</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://salesforce.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Salesforce administrators, implementation experts, developers and anybody in-between">Salesforce</a></li>
                <li class="-item"><a href="https://expressionengine.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="administrators, end users, developers and designers for ExpressionEngine&#xAE; CMS">ExpressionEngine&#xAE; Answers</a></li>
                <li class="-item"><a href="https://pt.stackoverflow.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="programadores profissionais e entusiastas">Stack Overflow em Portugu&#xEA;s</a></li>
                <li class="-item"><a href="https://blender.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people who use Blender to create 3D graphics, animations, or games">Blender</a></li>
                <li class="-item"><a href="https://networkengineering.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="network engineers">Network Engineering</a></li>
                <li class="-item"><a href="https://crypto.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="software developers, mathematicians and others interested in cryptography">Cryptography</a></li>
                <li class="-item"><a href="https://codereview.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="peer programmer code reviews">Code Review</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://magento.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users of the Magento e-Commerce platform">Magento</a></li>
                <li class="-item"><a href="https://softwarerecs.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people seeking specific software recommendations">Software Recommendations</a></li>
                <li class="-item"><a href="https://dsp.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="practitioners of the art and science of signal, image and video processing">Signal Processing</a></li>
                <li class="-item"><a href="https://emacs.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="those using, extending or developing Emacs">Emacs</a></li>
                <li class="-item"><a href="https://raspberrypi.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users and developers of hardware and software for Raspberry Pi">Raspberry Pi</a></li>
                <li class="-item"><a href="https://ru.stackoverflow.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="&#x43F;&#x440;&#x43E;&#x433;&#x440;&#x430;&#x43C;&#x43C;&#x438;&#x441;&#x442;&#x43E;&#x432;">Stack Overflow &#x43D;&#x430; &#x440;&#x443;&#x441;&#x441;&#x43A;&#x43E;&#x43C;</a></li>
                <li class="-item"><a href="https://codegolf.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="programming puzzle enthusiasts and code golfers">Code Golf</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://es.stackoverflow.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="programadores y profesionales de la inform&#xE1;tica">Stack Overflow en espa&#xF1;ol</a></li>
                <li class="-item"><a href="https://ethereum.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="users of Ethereum, the decentralized application platform and smart contract enabled blockchain">Ethereum</a></li>
                <li class="-item"><a href="https://datascience.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Data science professionals, Machine Learning specialists, and those interested in learning more about the field">Data Science</a></li>
                <li class="-item"><a href="https://arduino.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="developers of open-source hardware and software that is compatible with Arduino">Arduino</a></li>
                <li class="-item"><a href="https://bitcoin.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Bitcoin crypto-currency enthusiasts">Bitcoin</a></li>
                <li class="-item"><a href="https://sqa.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="software quality control experts, automation engineers, and software testers">Software Quality Assurance &amp; Testing</a></li>
                <li class="-item"><a href="https://sound.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="sound engineers, producers, editors, and enthusiasts">Sound Design</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Technology"><ul class="-list">
                <li class="-item"><a href="https://windowsphone.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="enthusiasts and power users of Windows Phone OS">Windows Phone</a></li>
                <li class="-item">
                    <a href="https://stackexchange.com/sites#technology" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 26 })">
                        <strong>
                            more (28)
                        </strong>
                    </a>
                </li>
        </ul>
    </div>
    <div class="site-footer--col site-footer--category js-footer-col" data-name="Life / Arts">
        <ul class="-list">
                <li class="-item"><a href="https://photo.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional, enthusiast and amateur photographers">Photography</a></li>
                <li class="-item"><a href="https://scifi.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="science fiction and fantasy enthusiasts">Science Fiction &amp; Fantasy</a></li>
                <li class="-item"><a href="https://graphicdesign.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Graphic Design professionals, students, and enthusiasts">Graphic Design</a></li>
                <li class="-item"><a href="https://movies.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="movie and TV enthusiasts">Movies &amp; TV</a></li>
                <li class="-item"><a href="https://music.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="musicians, students, and enthusiasts">Music: Practice &amp; Theory</a></li>
                <li class="-item"><a href="https://worldbuilding.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="writers/artists using science, geography and culture to construct imaginary worlds and settings">Worldbuilding</a></li>
                <li class="-item"><a href="https://video.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="engineers, producers, editors, and enthusiasts spanning the fields of video, and media creation">Video Production</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Life / Arts"><ul class="-list">
                <li class="-item"><a href="https://cooking.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional and amateur chefs">Seasoned Advice (cooking)</a></li>
                <li class="-item"><a href="https://diy.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="contractors and serious DIYers">Home Improvement</a></li>
                <li class="-item"><a href="https://money.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people who want to be financially literate">Personal Finance &amp; Money</a></li>
                <li class="-item"><a href="https://academia.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="academics and those enrolled in higher education">Academia</a></li>
                <li class="-item"><a href="https://law.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="legal professionals, students, and others with experience or interest in law">Law</a></li>
                <li class="-item"><a href="https://fitness.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="physical fitness professionals, athletes, trainers, and those providing health-related needs">Physical Fitness</a></li>
                <li class="-item"><a href="https://gardening.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="gardeners and landscapers">Gardening &amp; Landscaping</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Life / Arts"><ul class="-list">
                <li class="-item"><a href="https://parenting.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="parents, grandparents, nannies and others with a parenting role">Parenting</a></li>
                <li class="-item">
                    <a href="https://stackexchange.com/sites#lifearts" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 26 })">
                        <strong>
                            more (10)
                        </strong>
                    </a>
                </li>
        </ul>
    </div>
    <div class="site-footer--col site-footer--category js-footer-col" data-name="Culture / Recreation">
        <ul class="-list">
                <li class="-item"><a href="https://english.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="linguists, etymologists, and serious English language enthusiasts">English Language &amp; Usage</a></li>
                <li class="-item"><a href="https://skeptics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="scientific skepticism">Skeptics</a></li>
                <li class="-item"><a href="https://judaism.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="those who base their lives on Jewish law and tradition and anyone interested in learning more">Mi Yodeya (Judaism)</a></li>
                <li class="-item"><a href="https://travel.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="road warriors and seasoned travelers">Travel</a></li>
                <li class="-item"><a href="https://christianity.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="committed Christians, experts in Christianity and those interested in learning more">Christianity</a></li>
                <li class="-item"><a href="https://ell.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="speakers of other languages learning English">English Language Learners</a></li>
                <li class="-item"><a href="https://japanese.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students, teachers, and linguists wanting to discuss the finer points of the Japanese language">Japanese Language</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Culture / Recreation"><ul class="-list">
                <li class="-item"><a href="https://chinese.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students, teachers, and linguists wanting to discuss the finer points of the Chinese language">Chinese Language</a></li>
                <li class="-item"><a href="https://french.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students, teachers, and linguists wanting to discuss the finer points of the French language">French Language</a></li>
                <li class="-item"><a href="https://german.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="speakers of German wanting to discuss the finer points of the language and translation">German Language</a></li>
                <li class="-item"><a href="https://hermeneutics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professors, theologians, and those interested in exegetical analysis of biblical texts">Biblical Hermeneutics</a></li>
                <li class="-item"><a href="https://history.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="historians and history buffs">History</a></li>
                <li class="-item"><a href="https://spanish.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="linguists, teachers, students and Spanish language enthusiasts in general wanting to discuss the finer points of the language">Spanish Language</a></li>
                <li class="-item"><a href="https://islam.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="Muslims, experts in Islam, and those interested in learning more about Islam">Islam</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Culture / Recreation"><ul class="-list">
                <li class="-item"><a href="https://rus.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="&#x43B;&#x438;&#x43D;&#x433;&#x432;&#x438;&#x441;&#x442;&#x43E;&#x432; &#x438; &#x44D;&#x43D;&#x442;&#x443;&#x437;&#x438;&#x430;&#x441;&#x442;&#x43E;&#x432; &#x440;&#x443;&#x441;&#x441;&#x43A;&#x43E;&#x433;&#x43E; &#x44F;&#x437;&#x44B;&#x43A;&#x430;">&#x420;&#x443;&#x441;&#x441;&#x43A;&#x438;&#x439; &#x44F;&#x437;&#x44B;&#x43A;</a></li>
                <li class="-item"><a href="https://russian.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students, teachers, and linguists wanting to discuss the finer points of the Russian language">Russian Language</a></li>
                <li class="-item"><a href="https://gaming.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="passionate videogamers on all platforms">Arqade (gaming)</a></li>
                <li class="-item"><a href="https://bicycles.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people who build and repair bicycles, people who train cycling, or commute on bicycles">Bicycles</a></li>
                <li class="-item"><a href="https://rpg.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="gamemasters and players of tabletop, paper-and-pencil role-playing games">Role-playing Games</a></li>
                <li class="-item"><a href="https://anime.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="anime and manga fans">Anime &amp; Manga</a></li>
                <li class="-item"><a href="https://puzzling.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="those who create, solve, and study puzzles">Puzzling</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Culture / Recreation"><ul class="-list">
                <li class="-item"><a href="https://mechanics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="mechanics and DIY enthusiast owners of cars, trucks, and motorcycles">Motor Vehicle Maintenance &amp; Repair</a></li>
                <li class="-item"><a href="https://boardgames.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people who like playing board games, designing board games or modifying the rules of existing board games">Board &amp; Card Games</a></li>
                <li class="-item"><a href="https://bricks.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="LEGO&#xAE; and building block enthusiasts">Bricks</a></li>
                <li class="-item"><a href="https://homebrew.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="dedicated home brewers and serious enthusiasts">Homebrewing</a></li>
                <li class="-item"><a href="https://martialarts.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students and teachers of all martial arts">Martial Arts</a></li>
                <li class="-item"><a href="https://outdoors.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people who love being outdoors enjoying nature and wilderness, and learning about the required skills and equipment">The Great Outdoors</a></li>
                <li class="-item"><a href="https://poker.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="serious players and enthusiasts of poker">Poker</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Culture / Recreation"><ul class="-list">
                <li class="-item"><a href="https://chess.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="serious players and enthusiasts of chess">Chess</a></li>
                <li class="-item"><a href="https://sports.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="participants in team and individual sport activities">Sports</a></li>
                <li class="-item">
                    <a href="https://stackexchange.com/sites#culturerecreation" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 26 })">
                        <strong>
                            more (16)
                        </strong>
                    </a>
                </li>
        </ul>
    </div>
    <div class="site-footer--col site-footer--category js-footer-col" data-name="Science">
        <ul class="-list">
                <li class="-item"><a href="https://mathoverflow.net" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional mathematicians">MathOverflow</a></li>
                <li class="-item"><a href="https://math.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people studying math at any level and professionals in related fields">Mathematics</a></li>
                <li class="-item"><a href="https://stats.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="people interested in statistics, machine learning, data analysis, data mining, and data visualization">Cross Validated (stats)</a></li>
                <li class="-item"><a href="https://cstheory.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="theoretical computer scientists and researchers in related fields">Theoretical Computer Science</a></li>
                <li class="-item"><a href="https://physics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="active researchers, academics and students of physics">Physics</a></li>
                <li class="-item"><a href="https://chemistry.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="scientists, academics, teachers, and students in the field of chemistry">Chemistry</a></li>
                <li class="-item"><a href="https://biology.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="biology researchers, academics, and students">Biology</a></li>
                    </ul></div><div class="site-footer--col site-footer--category js-footer-col" data-name="Science"><ul class="-list">
                <li class="-item"><a href="https://cs.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="students, researchers and practitioners of computer science">Computer Science</a></li>
                <li class="-item"><a href="https://philosophy.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="those interested in the study of the fundamental nature of knowledge, reality, and existence">Philosophy</a></li>
                <li class="-item"><a href="https://linguistics.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="professional linguists and others with an interest in linguistic research and theory">Linguistics</a></li>
                <li class="-item"><a href="https://psychology.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="practitioners, researchers, and students in cognitive science, psychology, neuroscience, and psychiatry">Psychology &amp; Neuroscience</a></li>
                <li class="-item"><a href="https://scicomp.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="scientists using computers to solve scientific problems">Computational Science</a></li>
                <li class="-item">
                    <a href="https://stackexchange.com/sites#science" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 26 })">
                        <strong>
                            more (10)
                        </strong>
                    </a>
                </li>
        </ul>
    </div>
    <div class="site-footer--col site-footer--category js-footer-col" data-name="Other">
        <ul class="-list">
                <li class="-item"><a href="https://meta.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="meta-discussion of the Stack Exchange family of Q&amp;A websites">Meta Stack Exchange</a></li>
                <li class="-item"><a href="https://stackapps.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="apps, scripts, and development with the Stack Exchange API">Stack Apps</a></li>
                <li class="-item"><a href="https://api.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="programmatic interaction with Stack Exchange sites">API</a></li>
                <li class="-item"><a href="https://data.stackexchange.com" class="-link js-gps-track" data-gps-track="footer.click({ location: 2, link: 25 })" title="querying Stack Exchange data using SQL">Data</a></li>
        </ul>
    </div>

                </div>
            </nav>
            <div class="site-footer--copyright fs-fine">
                <ul class="-list">
                    <li class="-item"><a class="js-gps-track -link" data-gps-track="footer.click({ location: 5, link:4 })" href="https://stackoverflow.blog?blb=1">Blog</a></li>
                    <li class="-item"><a href="https://www.facebook.com/officialstackoverflow/" class="-link js-gps-track" data-gps-track="footer.click({ location: 5, link: 31 })">Facebook</a></li>
                    <li class="-item"><a href="https://twitter.com/stackoverflow" class="-link js-gps-track" data-gps-track="footer.click({ location: 5, link: 32 })">Twitter</a></li>
                    <li class="-item"><a href="https://linkedin.com/company/stack-overflow" class="-link js-gps-track" data-gps-track="footer.click({ location: 5, link: 33 })">LinkedIn</a></li>
                    <li class="-item"><a href="https://www.instagram.com/thestackoverflow" class="-link js-gps-track" data-gps-track="footer.click({ location: 5, link: 36 })">Instagram</a></li>
                </ul>

                <p class="mt-auto mb24">
site design / logo &#169; 2020 Stack Exchange Inc; user contributions licensed under <a href="https://stackoverflow.com/help/licensing">cc by-sa</a>.                    <span id="svnrev">rev&nbsp;2020.7.7.37196</span>
                </p>
            </div>
        </div>

    </footer>

            <script>StackExchange.ready(function () { StackExchange.responsiveness.addSwitcher(); })</script>
    <noscript>
        <div id="noscript-warning">Stack Overflow works best with JavaScript enabled
            <img src="https://pixel.quantserve.com/pixel/p-c1rF4kxgLUzNc.gif" alt="" class="dno">
        </div>
    </noscript>

        <script>
(function(i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function() { (i[r].q = i[r].q || []).push(arguments) }, i[r].l = 1 * new Date(); a = s.createElement(o),
                m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m);
            })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

            StackExchange.ready(function () {

                StackExchange.ga.init({
                    sendTitles: true,
                    tracker: window.ga,
                    trackingCodes: [
                        'UA-108242619-1'
                    ],
                        checkDimension: 'dimension42'
                });



                    StackExchange.ga.setDimension('dimension2', '|laravel|vue.js|');

                    StackExchange.ga.setDimension('dimension3', 'Questions/ListByTag');


                StackExchange.ga.trackPageView();
            });
            /**/

            var _qevents = _qevents || [],
            _comscore = _comscore || [];
            (function() {
                var ssl = 'https:' == document.location.protocol,
                    s = document.getElementsByTagName('script')[0],
                    qc = document.createElement('script');
 qc.async = true;
                    qc.src = (ssl ? 'https://secure' : 'http://edge') + '.quantserve.com/quant.js';
                    s.parentNode.insertBefore(qc, s);
                    _qevents.push({ qacct: "p-c1rF4kxgLUzNc" });/**/
 var sc = document.createElement('script');
                    sc.async = true;
                    sc.src = (ssl ? 'https://sb' : 'http://b') + '.scorecardresearch.com/beacon.js';
                    s.parentNode.insertBefore(sc, s);
                    _comscore.push({ c1: "2", c2: "17440561" });            })();
            
</script>

    
    </body>
    </html>
